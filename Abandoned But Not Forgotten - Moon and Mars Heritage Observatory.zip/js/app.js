/* =====================================================================
   APP - "Abandoned But Not Forgotten"  (Moon + Mars edition)
   Three.js r128 (cdnjs). Modules: Store, i18n helpers, AssetHooks,
   Materials, Models, Engine (incl. 3D loader), Transit, Sim, Inspector, UI.
   ===================================================================== */
'use strict';
(function () {
  const D = window.ABNF_DATA, L = window.ABNF_I18N;
  const $ = (s, r = document) => r.querySelector(s);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const easeIO = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const nextFrame = () => new Promise(r => requestAnimationFrame(() => r()));
  const esc = s => String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));

  /* =================================================================
     PHASE 1 - STATE + I18N
     ================================================================= */
  function detectLang() {
    try { const s = localStorage.getItem('abnf-lang'); if (s && L.LANGS.includes(s)) return s; } catch (e) { /* storage unavailable */ }
    const n = (navigator.language || 'tr').toLowerCase();
    if (n.startsWith('tr')) return 'TR';
    if (n.startsWith('zh')) return 'ZH';
    if (n.startsWith('hi')) return 'HI';
    if (n.startsWith('es')) return 'ES';
    if (n.startsWith('fr')) return 'FR';
    if (n.startsWith('ru')) return 'RU';
    if (n.startsWith('en')) return 'EN';
    return 'TR';
  }
  const Store = (() => {
    let state = Object.freeze({
      activeLanguage: detectLang(), loadingProgress: 0, selectedCelestialBody: 'MOON', activeSpacecraftId: null,
      timelineYear: 2026, bibliographyModalOpen: false, dossierOpen: null, panelTab: 'overview', catFilter: 'all',
      search: '', simulation: null, timelinePlaying: false, booted: false
    });
    const subs = new Set();
    return {
      get: () => state,
      set(p) { const prev = state; state = Object.freeze({ ...state, ...p }); subs.forEach(f => f(state, prev)); },
      subscribe(f) { subs.add(f); return () => subs.delete(f); }
    };
  })();
  const changed = (s, p, k) => s[k] !== p[k];
  const lang = () => Store.get().activeLanguage;
  const t = k => (L.DICT[lang()] || L.DICT.EN)[k] ?? L.DICT.EN[k] ?? k;
  const craftName = c => c.name[lang()] || c.name.EN;
  const ctx = c => c.tx[lang()] || c.tx.EN;

  /* ---------- derived data ---------- */
  const BODIES = D.BODIES, CATS = D.CATEGORIES, CRAFT = D.CRAFT, DOSS = D.DOSSIERS;
  const counters = { MOON: 0, MARS: 0 };
  CRAFT.forEach(c => {
    c.launchYear = +c.launch.slice(0, 4); c.arriveYear = +c.arrive.slice(0, 4); c.endYear = +c.end.slice(0, 4);
    c.code = (c.body === 'MOON' ? 'L' : 'M') + '-' + String(++counters[c.body]).padStart(2, '0');
  });
  const BYID = Object.fromEntries(CRAFT.map(c => [c.id, c]));

  function fmtDate(s) {
    const p = String(s).split('-');
    if (p.length === 1) return p[0];
    const d = new Date(Date.UTC(+p[0], +p[1] - 1, +(p[2] || 1)));
    const o = p.length === 2 ? { year: 'numeric', month: 'long', timeZone: 'UTC' } : { year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC' };
    try { return new Intl.DateTimeFormat(L.LOCALE[lang()], o).format(d); } catch (e) { return s; }
  }
  const nf = {};
  function fmtNum(n, d = 0) {
    const k = lang() + d;
    if (!nf[k]) { try { nf[k] = new Intl.NumberFormat(L.LOCALE[lang()], { maximumFractionDigits: d, minimumFractionDigits: d }); } catch (e) { nf[k] = { format: x => x.toFixed(d) }; } }
    return nf[k].format(n);
  }
  const fmtCoord = (la, lo) => `${Math.abs(la).toFixed(2)}° ${la >= 0 ? 'N' : 'S'}, ${Math.abs(lo).toFixed(2)}° ${lo >= 0 ? 'E' : 'W'}`;
  const locStr = c => c.lat != null ? `${fmtCoord(c.lat, c.lon)} / ${c.site}` : c.site;
  function craftStatus(c, y) {
    if (y < c.launchYear) return { key: 'st_prelaunch', cls: 'pre' };
    if (y < c.arriveYear) return { key: 'st_transit', cls: 'pre' };
    if (y < c.endYear) return { key: 'st_operational', cls: 'op' };
    return { key: 'st_' + c.status, cls: c.status === 'lost' ? 'lost' : 'dead' };
  }

  function loadScript(src) {
    return new Promise((res, rej) => {
      const s = document.createElement('script'); s.src = src; s.async = true; s.crossOrigin = 'anonymous';
      s.onload = () => res(); s.onerror = () => rej(new Error('Failed to load ' + src));
      document.head.appendChild(s);
    });
  }

  /* =================================================================
     PHASE 3 - 3D MODEL REPOSITORIES + GLTF HOOKS
     ================================================================= */
  const ModelRepositories = [ /* all spacecraft models are built in code; no external model sources */ ];
  const AssetHooks = (() => {
    const registry = {}; let lp = null;
    const LOADER = 'https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js';
    const ensure = () => THREE.GLTFLoader ? Promise.resolve() : (lp = lp || loadScript(LOADER));
    async function parse(url) { await ensure(); return new Promise((res, rej) => new THREE.GLTFLoader().load(url, g => res(g.scene), undefined, rej)); }
    return {
      registry,
      register(id, spec) { registry[id] = spec; },
      async load(id) { const s = registry[id]; if (!s) throw new Error('No asset registered for ' + id); const o = await parse(s.url); Engine.replaceModel(id, o); return o; },
      async loadFromFile(id, file) { const u = URL.createObjectURL(file); try { const o = await parse(u); Engine.replaceModel(id, o); return o; } finally { setTimeout(() => URL.revokeObjectURL(u), 5000); } }
    };
  })();

  /* =================================================================
     SHADERS
     ================================================================= */
  const GLSL_NOISE = `
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);}
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){
  const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx);
  vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx; vec3 x2=x0-i2+C.yyy; vec3 x3=x0-D.yyy;
  i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=0.142857142857; vec3 ns=n_*D.wyz-D.xzx;
  vec4 j=p-49.0*floor(p*ns.z*ns.z);
  vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y);
  vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0));
  vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));
  p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));
}
float fbm(vec3 p){ float a=0.5, s=0.0; for(int i=0;i<5;i++){ s+=a*snoise(p); p*=2.03; a*=0.5; } return s; }
`;
  /* =================================================================
     MARS RELIEF - one height function, evaluated once at load: it displaces the
     Mars sphere's vertices and places landers exactly on that surface.
     Units: relief r in roughly [-1, 1]; surface radius = 1 + MARS_DISP * r.
     MARS_DISP = 0.006 of the radius ~ 20 km, so Olympus Mons, Hellas and
     Valles Marineris come out close to their real depths and heights.
     ================================================================= */
  const MARS_DISP = .0095; /* about 1.6x real relief, a common exaggeration in planetary visualisation */
  /* CPU port of the Ashima 3D simplex noise used in GLSL_NOISE */
  const Relief = (() => {
    /* float32 emulation so the hash matches the GPU bit for bit */
    const f = Math.fround, INV289 = f(1 / 289);
    const m289 = x => f(x - f(Math.floor(f(f(x) * INV289)) * 289));
    const perm = x => m289(f(f(f(f(x) * 34) + 1) * f(x)));
    const tis = r => 1.79284291400159 - 0.85373472095314 * r;
    const step = (e, x) => x < e ? 0 : 1;
    function snoise(vx, vy, vz) {
      const Cx = 1 / 6, Cy = 1 / 3;
      const s = (vx + vy + vz) * Cy;
      let ix = Math.floor(vx + s), iy = Math.floor(vy + s), iz = Math.floor(vz + s);
      const t = (ix + iy + iz) * Cx;
      const x0x = vx - ix + t, x0y = vy - iy + t, x0z = vz - iz + t;
      const gx = step(x0y, x0x), gy = step(x0z, x0y), gz = step(x0x, x0z);
      const lx = 1 - gx, ly = 1 - gy, lz = 1 - gz;
      const i1x = Math.min(gx, lz), i1y = Math.min(gy, lx), i1z = Math.min(gz, ly);
      const i2x = Math.max(gx, lz), i2y = Math.max(gy, lx), i2z = Math.max(gz, ly);
      const x1x = x0x - i1x + Cx, x1y = x0y - i1y + Cx, x1z = x0z - i1z + Cx;
      const x2x = x0x - i2x + Cy, x2y = x0y - i2y + Cy, x2z = x0z - i2z + Cy;
      const x3x = x0x - .5, x3y = x0y - .5, x3z = x0z - .5;
      ix = m289(ix); iy = m289(iy); iz = m289(iz);
      const kz = [0, i1z, i2z, 1], ky = [0, i1y, i2y, 1], kx = [0, i1x, i2x, 1], p = [0, 0, 0, 0];
      for (let j = 0; j < 4; j++) p[j] = perm(perm(perm(iz + kz[j]) + iy + ky[j]) + ix + kx[j]);
      const n_ = f(0.142857142857), nsx = f(n_ * 2), nsy = f(f(n_ * .5) - 1), nsz = n_;
      const out = [];
      const X = [x0x, x1x, x2x, x3x], Yv = [x0y, x1y, x2y, x3y], Z = [x0z, x1z, x2z, x3z];
      const xs = [], ys = [], hs = [];
      for (let k = 0; k < 4; k++) {
        const j = f(p[k] - 49 * Math.floor(f(f(p[k] * nsz) * nsz)));
        const x_ = Math.floor(f(j * nsz)), y_ = Math.floor(f(j - 7 * x_));
        const x = x_ * nsx + nsy, y = y_ * nsx + nsy;
        xs.push(x); ys.push(y); hs.push(1 - Math.abs(x) - Math.abs(y));
      }
      const b0 = [xs[0], xs[1], ys[0], ys[1]], b1 = [xs[2], xs[3], ys[2], ys[3]];
      const s0 = b0.map(v => Math.floor(v) * 2 + 1), s1 = b1.map(v => Math.floor(v) * 2 + 1);
      const sh = hs.map(h => -step(h, 0));
      const a0 = [b0[0] + s0[0] * sh[0], b0[2] + s0[2] * sh[0], b0[1] + s0[1] * sh[1], b0[3] + s0[3] * sh[1]];
      const a1 = [b1[0] + s1[0] * sh[2], b1[2] + s1[2] * sh[2], b1[1] + s1[1] * sh[3], b1[3] + s1[3] * sh[3]];
      const g = [[a0[0], a0[1], hs[0]], [a0[2], a0[3], hs[1]], [a1[0], a1[1], hs[2]], [a1[2], a1[3], hs[3]]];
      let sum = 0;
      for (let k = 0; k < 4; k++) {
        const gg = g[k], nrm = tis(gg[0] * gg[0] + gg[1] * gg[1] + gg[2] * gg[2]);
        let m = Math.max(.6 - (X[k] * X[k] + Yv[k] * Yv[k] + Z[k] * Z[k]), 0); m = m * m;
        sum += m * m * (gg[0] * nrm * X[k] + gg[1] * nrm * Yv[k] + gg[2] * nrm * Z[k]);
      }
      return 42 * sum;
    }
    const D2R = Math.PI / 180, R2D = 180 / Math.PI;
    const ss = (e0, e1, x) => { const t = Math.min(1, Math.max(0, (x - e0) / (e1 - e0))); return t * t * (3 - 2 * t); };
    const LL = (la, lo) => { la *= D2R; lo *= D2R; return [Math.cos(la) * Math.cos(lo), Math.sin(la), -Math.cos(la) * Math.sin(lo)]; };
    const ang = (p, c) => Math.acos(Math.min(1, Math.max(-1, p[0] * c[0] + p[1] * c[1] + p[2] * c[2]))) * R2D;
    const LLc = {}; const C = (la, lo) => LLc[la + ',' + lo] || (LLc[la + ',' + lo] = LL(la, lo));
    const blob = (p, la, lo, r) => ss(r, r * .45, ang(p, C(la, lo)));
    const vol = (p, la, lo, r, h) => { const x = ang(p, C(la, lo)) / r; if (x > 1.2) return 0; return Math.pow(Math.max(1 - x, 0), 1.4) * h - ss(.2, .06, x) * h * .35; };
    const sn = (p, k, o = 0) => snoise(p[0] * k + o, p[1] * k + o, p[2] * k + o);
    function mars(p) {
      let r = (sn(p, 2.1) * .5 + sn(p, 4.3) * .25 + sn(p, 8.7) * .12) * .35;
      const south = ss(.12, -.28, p[1] + .12 * sn(p, 2.0));
      r += south * .35 - .15;
      r += blob(p, 2, -110, 26) * .45;
      r += vol(p, 18.65, -133.8, 3.4, 1) + vol(p, 11.8, -104.5, 1.9, .6) + vol(p, 1.5, -112.8, 1.9, .55) + vol(p, -8.3, -120.1, 2, .6) + vol(p, 25, 147, 1.5, .35);
      r -= blob(p, -42.4, 70.5, 16) * .75; r -= blob(p, -49.7, -43, 8) * .45; r -= blob(p, 12, 87, 7) * .3;
      const la = Math.asin(Math.min(1, Math.max(-1, p[1]))) * R2D, lo = Math.atan2(-p[2], p[0]) * R2D, t = (lo + 98) / 58;
      if (t > 0 && t < 1) { const lc = -7 - 6 * Math.sin(t * 3.14159), w = 1 + 1.6 * Math.sin(t * 3.14159); r -= ss(w, w * .25, Math.abs(la - lc)) * ss(0, .06, t) * ss(1, .9, t) * .55; }
      return r;
    }
    /* surface radius (in body radii) under a unit direction in the body's local frame */
    const surface = (body, dir) => body === 'MARS' ? 1 + MARS_DISP * mars([dir.x, dir.y, dir.z]) : 1;
    return { snoise, mars, surface };
  })();
  // GÖREV 3 - Mars kabartması yüklemede bir kez CPU'da hesaplanıp köşe noktalarına yazılır; her karede GPU maliyeti sıfırdır.
  // İniş araçları aynı fonksiyonla yüzeye yerleştirilir (GÖREV 1.3: yüzey yüksekliği ile temas noktası birebir eşit).
  /* relief is baked into the sphere's vertices once at load (Relief.mars on the CPU); the shader only passes it on */
  const PLANET_VS = `attribute float aRel; varying vec3 vObj; varying vec3 vWorld; varying vec3 vWN; varying float vRel;
void main(){ vObj=position; vRel=aRel; vec4 w=modelMatrix*vec4(position,1.0); vWorld=w.xyz; vWN=normalize(mat3(modelMatrix)*normal); gl_Position=projectionMatrix*viewMatrix*w; }`;
  const PLANET_FS = `uniform int uType; uniform vec3 uSun; uniform float uTime; uniform vec3 uAtmo; uniform mat3 uRot; uniform sampler2D uMoonCol; uniform sampler2D uMoonH; uniform float uMoonOn; uniform sampler2D uMarsCol; uniform sampler2D uMarsN; uniform float uMarsOn;
varying vec3 vObj; varying vec3 vWorld; varying vec3 vWN; varying float vRel;
${GLSL_NOISE}
float craters(vec3 p, float f, float pw){ return pow(1.0-abs(snoise(p*f)), pw); }
/* Object space matches latLonVec(): x=cos(lat)cos(lon), y=sin(lat), z=-cos(lat)sin(lon); lon positive east */
vec3 LL(float la,float lo){ la=radians(la); lo=radians(lo); return vec3(cos(la)*cos(lo), sin(la), -cos(la)*sin(lo)); }
float angD(vec3 p, vec3 c){ return degrees(acos(clamp(dot(p,c),-1.0,1.0))); }
float blob(vec3 p,float la,float lo,float r,float en){ float d=angD(p,LL(la,lo)); return smoothstep(r*(1.0+en),r*(0.55+en),d); }
float craterAt(vec3 p,float la,float lo,float r,float depth){
  float x=angD(p,LL(la,lo))/r; if(x>2.6) return 0.0;
  return ((x<1.0)?(x*x-1.0)*0.5:0.0)*depth + exp(-pow((x-1.0)*3.5,2.0))*0.35*depth;
}
float rays(vec3 p,float la,float lo,float len,float seed){
  vec3 c=LL(la,lo); float d=angD(p,c); if(d>len) return 0.0;
  vec3 up=abs(c.y)>0.9?vec3(1.0,0.0,0.0):vec3(0.0,1.0,0.0);
  vec3 a=normalize(cross(up,c)); vec3 b=cross(c,a); vec3 q=p-c*dot(p,c);
  float th=atan(dot(q,b),dot(q,a));
  float r=snoise(vec3(cos(th)*6.0,sin(th)*6.0,seed))*0.55+snoise(vec3(cos(th)*21.0,sin(th)*21.0,seed+3.0))*0.45;
  float s=pow(max(r,0.0),1.3)*smoothstep(len,len*0.06,d)*(0.7+0.3*snoise(p*28.0+seed));
  float halo=smoothstep(len*0.11,len*0.03,d);
  return max(s,halo);
}
/* Real lunar maria (centre lat, lon, approx radius in degrees) */
vec3 warp(vec3 p,float k){ return normalize(p+k*vec3(snoise(p*2.7+1.3),snoise(p*2.7+7.1),snoise(p*2.7+4.4))+k*0.45*vec3(snoise(p*7.0+2.0),snoise(p*7.0+9.0),snoise(p*7.0+5.0))); }
float mariaM(vec3 p0){
  vec3 p=warp(p0,0.11);
  float en=snoise(p0*6.0)*0.25+snoise(p0*15.0)*0.12;
  float m=0.0;
  m=max(m,blob(p,18.0,-57.0,24.0,en));   /* Oceanus Procellarum */
  m=max(m,blob(p,2.0,-43.0,14.0,en));    /* Procellarum south */
  m=max(m,blob(p,33.0,-16.0,17.0,en));   /* Mare Imbrium */
  m=max(m,blob(p,28.0,17.5,9.5,en));     /* Mare Serenitatis */
  m=max(m,blob(p,8.5,31.0,11.5,en));     /* Mare Tranquillitatis */
  m=max(m,blob(p,17.0,59.0,7.5,en));     /* Mare Crisium */
  m=max(m,blob(p,-8.0,51.0,9.0,en));     /* Mare Fecunditatis */
  m=max(m,blob(p,-15.0,35.0,5.5,en));    /* Mare Nectaris */
  m=max(m,blob(p,-21.0,-17.0,9.5,en));   /* Mare Nubium */
  m=max(m,blob(p,-24.0,-39.0,5.0,en));   /* Mare Humorum */
  m=max(m,blob(p,-10.0,-23.0,5.0,en));   /* Mare Cognitum */
  m=max(m,blob(p,7.0,-31.0,7.0,en));     /* Mare Insularum */
  m=max(m,blob(p,13.0,4.0,4.0,en));      /* Mare Vaporum */
  m=max(m,blob(p,2.0,1.0,3.0,en));       /* Sinus Medii */
  m=max(m,blob(p,56.0,-25.0,5.0,en)); m=max(m,blob(p,57.0,0.0,5.0,en)); m=max(m,blob(p,56.0,22.0,5.0,en)); m=max(m,blob(p,55.0,42.0,4.5,en)); /* Mare Frigoris */
  m=max(m,blob(p,27.0,148.0,4.0,en)*0.8);  /* Mare Moscoviense (far side) */
  m=max(m,blob(p,-19.0,-93.0,4.0,en)*0.8); /* Mare Orientale */
  return m*(0.86+0.14*snoise(p0*9.0));
}
float volcano(vec3 p,float la,float lo,float r,float hgt){
  float x=angD(p,LL(la,lo))/r; if(x>1.2) return 0.0;
  return pow(max(1.0-x,0.0),1.4)*hgt - smoothstep(0.2,0.06,x)*hgt*0.35;
}
vec3 hash3(vec3 p){ p=vec3(dot(p,vec3(127.1,311.7,74.7)),dot(p,vec3(269.5,183.3,246.1)),dot(p,vec3(113.5,271.9,124.6))); return fract(sin(p)*43758.5453); }
float gFresh;
/* Cellular crater field: circular bowls with raised rims and an ejecta apron; a few young bright craters */
vec2 craterField(vec3 p,float f,float density){
  vec3 q=p*f; vec3 i=floor(q); vec3 fr=fract(q); float h=0.0; float br=0.0;
  for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) for(int z=-1;z<=1;z++){
    vec3 o=vec3(float(x),float(y),float(z)); vec3 rnd=hash3(i+o);
    if(rnd.z>density) continue;
    vec3 c=o+0.1+rnd*0.8;
    float r=0.16+0.34*fract(rnd.x*7.13);
    float d=length(fr-c)/r;
    if(d<2.4){
      float age=fract(rnd.y*13.7);
      float bowl=(d<1.0)?(d*d-1.0)*0.75:0.0;
      float rim=exp(-pow((d-1.0)*4.2,2.0))*0.45;
      float ej=(d>1.0)?exp(-(d-1.0)*2.6)*0.07:0.0;
      float peak=(r>0.38)?exp(-d*d*40.0)*0.25:0.0;
      h+=(bowl+rim+ej+peak)*r*(0.35+0.65*age);
      if(age>0.88) br=max(br,smoothstep(2.3,0.9,d)*(age-0.88)*8.0);
    }
  }
  return vec2(h,br);
}
float heightF(vec3 p, float m){
  if(uType==1){
    vec2 c1=craterField(p,7.0,0.55);
    vec2 c2=craterField(p+11.3,21.0,0.6);
    gFresh=max(c1.y,c2.y*0.8)*(1.0-0.5*m);
    float base=fbm(p*2.4)*0.28;
    return base*(1.0-0.6*m) + c1.x*1.1*(1.0-0.8*m) + c2.x*0.55*(1.0-0.7*m) + snoise(p*60.0)*0.012 - m*0.2
      + craterAt(p,-43.3,-11.2,0.75,1.0) + craterAt(p,9.6,-20.1,0.8,1.0) + craterAt(p,23.7,-47.4,0.35,0.8) + craterAt(p,8.1,-38.0,0.28,0.7);
  }
  float south=smoothstep(0.12,-0.28,p.y+0.12*snoise(p*2.0));            /* cratered southern highlands vs smooth northern lowlands */
  vec2 mc1=craterField(p+2.7,8.0,0.5); vec2 mc2=craterField(p+6.1,23.0,0.45);
  float h=fbm(p*2.2)*0.4 + south*0.16 + mc1.x*0.95*(0.25+0.75*south) + mc2.x*0.45*(0.3+0.7*south);
  h+=blob(p,2.0,-110.0,26.0,0.0)*0.22;                                   /* Tharsis bulge */
  h+=volcano(p,18.65,-133.8,3.4,0.95)+volcano(p,11.8,-104.5,1.9,0.55)+volcano(p,1.5,-112.8,1.9,0.5)+volcano(p,-8.3,-120.1,2.0,0.55)+volcano(p,25.0,147.0,1.5,0.35);
  h-=blob(p,-42.4,70.5,16.0,0.0)*0.45;                                   /* Hellas basin */
  h-=blob(p,-49.7,-43.0,8.0,0.0)*0.28;                                   /* Argyre basin */
  float la=degrees(asin(clamp(p.y,-1.0,1.0))); float lo=degrees(atan(-p.z,p.x));
  float t=(lo+98.0)/58.0;                                                /* Valles Marineris, ~98W to 40W */
  if(t>0.0 && t<1.0){
    float lc=-7.0-6.0*sin(t*3.14159);
    float w=1.0+1.6*sin(t*3.14159);
    float c=smoothstep(w,w*0.25,abs(la-lc+0.7*snoise(p*18.0)))*smoothstep(0.0,0.06,t)*smoothstep(1.0,0.9,t);
    h-=c*0.42;
  }
  return h;
}

/* NASA SVS CGI Moon Kit: LROC WAC colour mosaic + LOLA elevation (equirectangular, lon 0 at centre, east positive) */
vec2 moonUV(vec3 p){
  float u=atan(-p.z,p.x)/6.2831853+0.5; float v=asin(clamp(p.y,-1.0,1.0))/3.14159265+0.5;
  float u2=fract(u+0.5)-0.5;                       /* seam-free mip selection across the 180 deg meridian */
  return vec2(fwidth(u)<=fwidth(u2)+1e-6?u:u2, v);
}
float moonH(vec2 uv){ return texture2D(uMoonH,uv).r; }
vec4 moonShade(vec3 p){
  vec2 uv=moonUV(p);
  float lat=asin(clamp(p.y,-1.0,1.0)); float cl=max(cos(lat),0.05);
  vec2 tx=vec2(1.0/1024.0,1.0/512.0);
  float hE=moonH(uv+vec2(tx.x,0.0)), hW=moonH(uv-vec2(tx.x,0.0)), hN=moonH(uv+vec2(0.0,tx.y)), hS=moonH(uv-vec2(0.0,tx.y));
  /* slope per radian: LOLA 8-bit spans ~20 km of relief on a 1737 km radius, exaggerated for legibility */
  float k=0.05;
  float dE=(hE-hW)/(2.0*tx.x*6.2831853*cl)*k, dN=(hN-hS)/(2.0*tx.y*3.14159265)*k;
  vec3 tE=vec3(p.z,0.0,-p.x); tE=dot(tE,tE)>1e-8?normalize(tE):vec3(0.0,0.0,-1.0); vec3 tN=cross(p,tE);
  vec3 n=normalize(p-tE*dE-tN*dN);
  /* fine regolith grain for close-ups */
  n=normalize(n+0.035*vec3(snoise(p*240.0),snoise(p*240.0+7.0),snoise(p*240.0+13.0)));
  return vec4(n,0.0);
}
void main(){
  vec3 p=normalize(vObj);
  if(uType==1 && uMoonOn>0.5){
    vec2 uv=moonUV(p);
    vec3 alb=pow(texture2D(uMoonCol,uv).rgb,vec3(2.2));
    vec3 Nw=normalize(uRot*moonShade(p).xyz);
    vec3 Vw=normalize(cameraPosition-vWorld);
    float mu0=dot(Nw,uSun), mu=max(dot(normalize(vWN),Vw),0.02);
    float i0=max(mu0,0.0);
    /* lunar-Lambert photometry (Lommel-Seeliger + Lambert): flat full-Moon disc, razor-sharp terminator, no atmosphere */
    float f=mix(i0, 2.0*i0/(i0+mu), 0.62);
    float opp=exp(-acos(clamp(dot(Vw,uSun),-1.0,1.0))*18.0)*0.12*i0;          /* opposition surge of the regolith */
    vec3 lin=alb*(f*1.9+opp) + alb*vec3(0.55,0.62,0.78)*0.0035;              /* faint earthshine on the night side */
    gl_FragColor=vec4(pow(lin,vec3(1.0/2.2)),1.0); return;
  }
  if(uType==2 && uMarsOn>0.5){
    /* NASA Mars global colour mosaic (Viking/MGS based, 0-360E map) + its relief normal map; geometry relief stays baked */
    vec2 uv=moonUV(p); uv.x+=0.5;
    vec3 alb=pow(texture2D(uMarsCol,uv).rgb,vec3(2.2));
    vec2 nt=(texture2D(uMarsN,uv).rg-vec2(0.5))*2.0*7.0;
    vec3 tE=vec3(p.z,0.0,-p.x); tE=dot(tE,tE)>1e-8?normalize(tE):vec3(0.0,0.0,-1.0); vec3 tN=cross(p,tE);
    vec3 n=normalize(p+tE*nt.x+tN*nt.y);
    vec3 Nw=normalize(uRot*n), Vw=normalize(cameraPosition-vWorld);
    float dif=dot(Nw,uSun), i0=max(dif,0.0), mu=max(dot(normalize(vWN),Vw),0.02);
    float f=i0*pow(max(i0*mu,1e-4),0.12);                              /* Minnaert-darkened Lambert: dusty, slightly limb-darkened */
    vec3 lin=alb*f*2.05 + alb*vec3(0.9,0.55,0.35)*0.006*smoothstep(-0.35,0.0,dif); /* faint twilight scattering past the terminator */
    vec3 col=pow(lin,vec3(1.0/2.2));
    float fres=pow(1.0-max(dot(normalize(vWN),Vw),0.0),2.6);
    col+=uAtmo*fres*0.45*smoothstep(-0.25,0.4,dif);
    gl_FragColor=vec4(col,1.0); return;
  }
  float m=(uType==1)?mariaM(p):0.0;
  gFresh=0.0;
  float h=heightF(p,m);
  float fresh=gFresh;
  vec3 up=abs(p.y)>0.98?vec3(1.0,0.0,0.0):vec3(0.0,1.0,0.0);
  vec3 t1=normalize(cross(up,p)); vec3 t2=cross(p,t1);
  float e=0.0022;
  vec2 gr=vec2(heightF(normalize(p+t1*e),m)-h, heightF(normalize(p+t2*e),m)-h)/e;
  vec3 N=normalize(uRot*normalize(p-(t1*gr.x+t2*gr.y)*(uType==1?0.03:0.024)));
  vec3 V=normalize(cameraPosition-vWorld);
  float dif=dot(N,uSun);
  float fres=pow(1.0-max(dot(normalize(vWN),V),0.0),2.6);
  vec3 lit;
  if(uType==1){
    /* Neutral grey Moon: bright anorthosite highlands, dark basaltic maria */
    vec3 col=mix(vec3(0.60,0.59,0.57),vec3(0.25,0.25,0.27),m*0.93);
    col=mix(col,col*vec3(0.94,0.98,1.05),blob(p,8.5,31.0,11.0,0.0)*0.5);  /* titanium-rich, bluish Tranquillitatis */
    col=mix(col,col*vec3(1.05,1.0,0.94),blob(p,28.0,17.5,9.0,0.0)*0.5);    /* browner Serenitatis */
    col*=0.82+0.30*clamp(h,-0.6,1.0);
    col*=0.92+0.05*snoise(p*45.0)+0.04*snoise(p*9.0);
    col=mix(col,vec3(0.86,0.86,0.84),clamp(fresh,0.0,1.0)*0.6);
    float r=rays(p,-43.3,-11.2,34.0,1.0)*1.0 + rays(p,9.6,-20.1,17.0,5.0)*0.75 + rays(p,8.1,-38.0,10.0,9.0)*0.6 + rays(p,23.7,-47.4,7.0,13.0)*0.9;
    col=mix(col,vec3(0.95,0.95,0.93),clamp(r*1.1,0.0,0.9));
    col*=1.0-0.16*blob(p,-53.0,169.0,34.0,0.0);                                /* South Pole-Aitken basin, far side */
    lit=col*max(dif,0.0)*1.55+col*0.014;
    float opp=pow(max(dot(N,V),0.0),24.0)*max(dif,0.0)*0.08;
    lit+=opp;
  } else {
    /* Rust-coloured Mars with its real dark albedo regions */
    vec3 p0=p; p=warp(p0,0.09);
    float en=snoise(p0*5.0)*0.28+snoise(p0*14.0)*0.12;
    float dk=0.0;
    dk=max(dk,blob(p,8.0,69.0,9.0,en)); dk=max(dk,blob(p,18.0,66.0,6.0,en)); /* Syrtis Major */
    dk=max(dk,blob(p,47.0,-25.0,14.0,en)*0.85);                              /* Acidalia Planitia */
    dk=max(dk,blob(p,-24.0,-40.0,13.0,en)*0.8);                              /* Mare Erythraeum */
    dk=max(dk,blob(p,-2.0,-2.0,6.0,en)); dk=max(dk,blob(p,-8.0,18.0,7.0,en)); dk=max(dk,blob(p,-9.0,38.0,7.0,en)); /* Sinus Meridiani, Sinus Sabaeus */
    dk=max(dk,blob(p,-18.0,100.0,11.0,en)*0.85);                             /* Mare Tyrrhenum */
    dk=max(dk,blob(p,-25.0,140.0,13.0,en)*0.85);                             /* Mare Cimmerium */
    dk=max(dk,blob(p,-32.0,-155.0,12.0,en)*0.8);                             /* Mare Sirenum */
    dk=max(dk,blob(p,-26.0,-86.0,4.5,en)*0.7);                               /* Solis Lacus */
    dk=max(dk,blob(p,45.0,110.0,14.0,en)*0.45);                              /* Utopia Planitia */
    dk*=0.7+0.3*(fbm(p0*8.0+5.0)*0.5+0.5)*1.4;
    dk=clamp(dk,0.0,1.0);
    vec3 col=mix(vec3(0.80,0.47,0.26),vec3(0.31,0.19,0.13),dk*0.95);
    col=mix(col,vec3(0.86,0.64,0.47),blob(p,-42.4,70.5,15.0,en)*0.75);      /* bright, frost-dusted Hellas */
    col=mix(col,vec3(0.84,0.60,0.43),blob(p,-49.7,-43.0,8.0,en)*0.5);       /* Argyre */
    col=mix(col,vec3(0.87,0.53,0.31),blob(p,5.0,-112.0,22.0,en)*0.35);      /* dusty Tharsis */
    col=mix(col,vec3(0.88,0.56,0.33),blob(p,20.0,-160.0,18.0,en)*0.3);      /* dusty Amazonis */
    p=p0;
    col*=0.82+0.36*h;
    col*=0.93+0.07*snoise(p*30.0);
    /* colour by elevation: dark basaltic northern lowlands, bright dusty summits (Tharsis, Olympus Mons) */
    col=mix(col,col*vec3(0.74,0.72,0.76),smoothstep(-0.12,-0.5,vRel)*smoothstep(-0.1,0.25,p.y)*0.55);
    col=mix(col,vec3(0.90,0.64,0.44),smoothstep(0.45,1.0,vRel)*0.5);
    float la=degrees(asin(clamp(p.y,-1.0,1.0)));
    float ncap=smoothstep(78.0,82.5,la+3.0*snoise(p*6.0)+1.5*snoise(p*17.0));
    float scap=blob(p,-87.0,-45.0,5.5,en*0.5);                               /* south residual cap is offset from the pole */
    col=mix(col,vec3(0.95,0.93,0.90),max(ncap,scap));
    lit=col*max(dif,0.0)*1.5+col*0.018;
    lit+=uAtmo*fres*0.45*smoothstep(-0.25,0.4,dif);
  }
  gl_FragColor=vec4(lit,1.0);
}`;
  const ATMO_VS = `varying vec3 vN; varying vec3 vW; void main(){ vN=normalize(mat3(modelMatrix)*normal); vec4 w=modelMatrix*vec4(position,1.0); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }`;
  const ATMO_FS = `uniform vec3 uColor; uniform vec3 uSun; uniform float uStrength; varying vec3 vN; varying vec3 vW;
void main(){ vec3 V=normalize(cameraPosition-vW); vec3 N=normalize(vN); float i=pow(clamp(-dot(N,V)*4.6,0.0,1.0),2.6); float s=smoothstep(-0.3,0.45,dot(N,uSun)); float fw=pow(max(dot(-V,uSun),0.0),6.0); gl_FragColor=vec4(uColor*i*uStrength*(0.08+0.92*s)+vec3(1.0,0.6,0.35)*i*fw*0.6,1.0); }`;
  const SKY_VS = `varying vec3 vD; void main(){ vD=normalize(position); gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`;
  const SKY_FS = `uniform vec3 uTint; uniform vec3 uGlow; varying vec3 vD;
${GLSL_NOISE}
void main(){ vec3 d=normalize(vD);
  float band=pow(1.0-abs(d.y*0.9+0.2*d.x),3.0);
  float neb=smoothstep(0.0,0.9,fbm(d*2.2+3.0)*0.5+0.5)*band;
  vec3 c=vec3(0.006,0.008,0.014)+uTint*(0.35*band+0.9*neb*neb)+uTint*0.5*pow(max(dot(d,uGlow),0.0),5.0);
  gl_FragColor=vec4(c,1.0); }`;

  /* =================================================================
     MATERIALS
     ================================================================= */
  const CRAFT_VS = `varying vec3 vN; varying vec3 vW; varying vec3 vP; varying vec2 vUv;
void main(){ vUv=uv; vP=position; vec4 w=modelMatrix*vec4(position,1.0); vW=w.xyz; vN=normalize(mat3(modelMatrix)*normal); gl_Position=projectionMatrix*viewMatrix*w; }`;
  const CRAFT_FS = `uniform vec3 uColor; uniform float uKind; uniform float uSpec; uniform float uShine; uniform vec3 uKey; uniform sampler2D uMap; uniform float uHasMap;
varying vec3 vN; varying vec3 vW; varying vec3 vP; varying vec2 vUv;
float h3(vec3 p){ return fract(sin(dot(p,vec3(12.9898,78.233,37.719)))*43758.5453); }
void main(){
  vec3 N=normalize(vN); vec3 V=normalize(cameraPosition-vW); if(dot(N,V)<0.0) N=-N;
  vec3 c=uColor; if(uHasMap>0.5) c*=texture2D(uMap,vUv).rgb;
  if(uKind>0.5 && uKind<1.5){
    float r=h3(floor(vP*14.0)+3.1); float r2=h3(floor(vP*5.0)+7.7);
    c*=0.90+0.08*r+0.07*r2;
  } else if(uKind>1.5 && uKind<2.5){
    vec2 g=fract(vUv*vec2(8.0,8.0)); float line=step(0.9,max(g.x,g.y)); float bus=step(0.94,fract(vUv.y*32.0))*(1.0-line);
    vec3 cell=uColor*(0.85+0.3*h3(floor(vec3(vUv*8.0,1.0))));
    c=mix(cell,vec3(0.66,0.70,0.76),max(line,bus*0.45));
  } else if(uKind>2.5 && uKind<3.5){
    float st=step(0.5,fract(vUv.y*6.5)); c=mix(vec3(0.72,0.12,0.16),vec3(0.96,0.95,0.92),st);
    if(vUv.x<0.42 && vUv.y>0.46){ c=vec3(0.16,0.18,0.42); vec2 sp=fract(vUv*vec2(14.0,12.0)); if(length(sp-0.5)<0.2) c=vec3(0.96); }
  }
  vec3 L=normalize(uKey);
  float key=max(dot(N,L),0.0); float head=max(dot(N,V),0.0); float hemi=0.5+0.5*N.y;
  vec3 col=c*(0.32+0.16*hemi+0.55*key+0.40*head);
  /* procedural reflection environment: dark space above, warm ground below, a bright sun disc and a soft horizon;
     metallic surfaces (foil, aluminium, glass) mirror it, tinted by their own colour */
  vec3 Rv=reflect(-V,N);
  vec3 env=mix(vec3(0.30,0.22,0.16),vec3(0.05,0.07,0.11),smoothstep(-0.25,0.35,Rv.y));
  env+=vec3(0.55,0.50,0.46)*exp(-abs(Rv.y)*7.0);
  env+=vec3(1.0,0.96,0.88)*pow(max(dot(Rv,L),0.0),90.0)*3.0;
  float refl=clamp(uSpec*0.85,0.0,0.7);
  col=mix(col,col*0.45+env*mix(vec3(1.0),c*1.4,0.7),refl);
  col+=uSpec*pow(max(dot(reflect(-L,N),V),0.0),uShine)*vec3(1.0,0.97,0.9);
  gl_FragColor=vec4(col,1.0);
}`;
  let MAT = null, TEX = null, Y = null, CRAFT_SM = null, WHITE_TEX = null;
  function canvasTex(w, h, draw, srgb = true) {
    const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
    const tx = new THREE.CanvasTexture(c); if (srgb) tx.encoding = THREE.sRGBEncoding; tx.anisotropy = 4; return tx;
  }
  function buildMaterials() {
    Y = new THREE.Vector3(0, 1, 0);
    TEX = {};
    TEX.foil = canvasTex(512, 512, (g, w, h) => {
      g.fillStyle = '#9a9a9a'; g.fillRect(0, 0, w, h);
      for (let i = 0; i < 1600; i++) {
        const x = Math.random() * w, y = Math.random() * h, s = 8 + Math.random() * 44, v = 115 + Math.random() * 140 | 0;
        g.fillStyle = `rgb(${v},${v},${v})`; g.beginPath(); g.moveTo(x, y);
        for (let k = 0; k < 3 + (Math.random() * 3 | 0); k++) g.lineTo(x + (Math.random() - .5) * s, y + (Math.random() - .5) * s);
        g.closePath(); g.fill();
      }
      g.globalAlpha = .16; g.strokeStyle = '#fff';
      for (let i = 0; i < 180; i++) { g.beginPath(); g.moveTo(Math.random() * w, Math.random() * h); g.lineTo(Math.random() * w, Math.random() * h); g.stroke(); }
    });
    TEX.foil.wrapS = TEX.foil.wrapT = THREE.RepeatWrapping; TEX.foil.repeat.set(2, 2);
    TEX.foilR = TEX.foil.clone(); TEX.foilR.encoding = THREE.LinearEncoding; TEX.foilR.needsUpdate = true;
    TEX.solar = canvasTex(256, 256, (g, w) => {
      g.fillStyle = '#a3adbd'; g.fillRect(0, 0, w, w);
      const n = 8, s = w / n;
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
        const v = Math.random() * 14;
        g.fillStyle = `rgb(${12 + v},${24 + v},${66 + v * 2})`; g.fillRect(i * s + 1.5, j * s + 1.5, s - 3, s - 3);
        g.fillStyle = 'rgba(160,180,215,.22)'; g.fillRect(i * s + 1.5, j * s + s / 2, s - 3, 1);
      }
    });
    TEX.solar.wrapS = TEX.solar.wrapT = THREE.RepeatWrapping;
    TEX.flag = canvasTex(256, 160, (g, w, h) => {
      for (let i = 0; i < 13; i++) { g.fillStyle = i % 2 ? '#f4f1ea' : '#b22234'; g.fillRect(0, i * h / 13, w, h / 13 + 1); }
      g.fillStyle = '#3c3b6e'; g.fillRect(0, 0, w * .4, h * 7 / 13);
      g.fillStyle = '#f4f1ea'; for (let r = 0; r < 5; r++) for (let c = 0; c < 6; c++) { g.beginPath(); g.arc(8 + c * 15.5, 8 + r * 15, 2.2, 0, 6.3); g.fill(); }
    });
    TEX.ring = canvasTex(128, 128, g => {
      g.strokeStyle = '#fff'; g.lineWidth = 5; g.beginPath(); g.arc(64, 64, 42, 0, 6.2832); g.stroke();
      g.lineWidth = 4; [[64, 4, 64, 16], [64, 112, 64, 124], [4, 64, 16, 64], [112, 64, 124, 64]].forEach(([a, b, c, d]) => { g.beginPath(); g.moveTo(a, b); g.lineTo(c, d); g.stroke(); });
      g.fillStyle = '#fff'; g.beginPath(); g.arc(64, 64, 7, 0, 6.2832); g.fill();
    }, false);
    TEX.glow = canvasTex(128, 128, g => {
      const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
      gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(.22, 'rgba(255,255,255,.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
    }, false);
    // Uydu malzemeleri: ışık, folyo, güneş hücresi ve yansıma tek bir hafif shader'da hesaplanır. Gölge haritası (ShadowMap) ve
    // PMREM ortam haritası kullanılmaz; bu, hem bazı GPU'lardaki siyah görünme hatasını hem de gölge maliyetini ortadan kaldırır (GÖREV 3.3).
    /* Spacecraft materials use the same self-contained shader approach as the planets: lighting, foil crinkle,
       solar cells and flags are computed in the shader, so nothing depends on scene lights, reflection
       environments or PBR features that render black on some GPUs. */
    const CRAFT_KEY = new THREE.Vector3(.62, .72, .45).normalize();
    WHITE_TEX = new THREE.DataTexture(new Uint8Array([255, 255, 255, 255]), 1, 1, THREE.RGBAFormat); WHITE_TEX.needsUpdate = true;
    CRAFT_SM = (hex, kind = 0, spec = .12, shine = 20, decal = false, map = null) => new THREE.ShaderMaterial({
      uniforms: { uColor: { value: new THREE.Color(hex) }, uKind: { value: kind }, uSpec: { value: spec }, uShine: { value: shine }, uKey: { value: CRAFT_KEY }, uMap: { value: map || WHITE_TEX }, uHasMap: { value: map ? 1 : 0 } },
      vertexShader: CRAFT_VS, fragmentShader: CRAFT_FS, side: THREE.DoubleSide,
      // GÖREV 2.2 - polygonOffset: dikiş, bayrak gibi yüzey ayrıntıları derinlikte kameraya doğru kaydırılır; altındaki panelle titreşmez.
      /* surface details (seams, flags, tape) are pulled towards the camera in depth so they never fight with the panel under them */
      polygonOffset: decal, polygonOffsetFactor: decal ? -1 : 0, polygonOffsetUnits: decal ? -2 : 0
    });
    const SM = CRAFT_SM;
    MAT = {
      foil: SM(0xd9a443, 1, .55, 30), kapton: SM(0xd2781c, 1, .5, 30), foilSilver: SM(0xc9ced6, 1, .6, 34), foilBlack: SM(0x45474e, 1, .35, 26), ringFoil: SM(0xd9a443, 1, .55, 30),
      white: SM(0xe9e7e0, 0, .08, 12), cream: SM(0xe6dcc2, 0, .06, 10), alu: SM(0xc3c9d0, 0, .45, 40), polish: SM(0xe4e8ec, 0, .7, 60),
      dark: SM(0x3d424a, 0, .15, 18), anod: SM(0x6d7279, 0, .25, 24), tire: SM(0x45474c, 0, .05, 8), black: SM(0x232428, 0, .12, 16),
      solar: SM(0x1a2a66, 2, .55, 50), solarFacet: SM(0x1a2a66, 2, .55, 50), dish: SM(0xf1efe8, 0, .1, 14), flag: SM(0xffffff, 3, .04, 8, true),
      bag: SM(0xd4ccbb, 0, .05, 8), glass: SM(0x1f2c3c, 0, .9, 80), copper: SM(0xc07a3e, 0, .45, 34), red: SM(0xc22a20, 0, .08, 12),
      blue: SM(0x2d55a0, 0, .1, 14), yellow: SM(0xf0c52c, 0, .08, 12), seam: SM(0x6a5230, 0, .1, 12, true), carbon: SM(0x34393a, 0, .2, 20)
    };
  }
  function makeEnv(renderer) {
    const es = new THREE.Scene();
    es.add(new THREE.Mesh(new THREE.SphereGeometry(50, 32, 16), new THREE.ShaderMaterial({
      side: THREE.BackSide,
      vertexShader: 'varying vec3 vP; void main(){ vP=normalize(position); gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'varying vec3 vP; void main(){ float y=vP.y; vec3 c=mix(vec3(0.10,0.11,0.13),vec3(0.38,0.46,0.58),smoothstep(-0.3,0.7,y)); c+=vec3(0.45,0.32,0.2)*smoothstep(0.2,-0.6,y)*0.5; gl_FragColor=vec4(c,1.0); }'
    })));
    const panel = (c, s, x, y, z) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(s[0], s[1]), new THREE.MeshBasicMaterial({ color: new THREE.Color(c[0], c[1], c[2]), side: THREE.DoubleSide })); m.position.set(x, y, z); m.lookAt(0, 0, 0); es.add(m); };
    panel([9, 8.4, 7.6], [18, 12], 30, 20, 25); panel([3, 3.6, 4.4], [30, 12], -35, 5, -10); panel([4, 4, 4], [14, 30], 0, 35, -30); panel([2.6, 2.4, 2.2], [24, 14], 10, -10, -40); panel([3.2, 3.2, 3.4], [16, 16], -20, 8, 38);
    const pm = new THREE.PMREMGenerator(renderer); const tex = pm.fromScene(es, .035).texture; pm.dispose(); return tex;
  }

  /* =================================================================
     PROCEDURAL SPACECRAFT MODELS (reference-based, approximate)
     ================================================================= */
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  const mesh = (g, m) => new THREE.Mesh(g, m);
  const box = (w, h, d, m) => mesh(new THREE.BoxGeometry(w, h, d), m);
  const cyl = (rt, rb, h, seg, m, open = false) => mesh(new THREE.CylinderGeometry(rt, rb, h, seg, 1, open), m);
  const sph = (r, m, ws = 32, hs = 18) => mesh(new THREE.SphereGeometry(r, ws, hs), m);
  const at = (o, x, y, z, rx = 0, ry = 0, rz = 0) => { o.position.set(x, y, z); o.rotation.set(rx, ry, rz); return o; };
  const orient = (o, dir) => { o.quaternion.setFromUnitVectors(Y, dir.clone().normalize()); return o; };
  const rod = (a, b, r, m) => { const d = b.clone().sub(a); const o = cyl(r, r, d.length(), 8, m); o.position.copy(a).addScaledVector(d, .5); return orient(o, d); };
  const grp = (...o) => { const g = new THREE.Group(); o.forEach(c => g.add(c)); return g; };
  function dish(r, depth, m) { const pts = []; for (let i = 0; i <= 18; i++) { const x = i / 18 * r; pts.push(new THREE.Vector2(Math.max(x, .0001), depth * (x / r) ** 2)); } return mesh(new THREE.LatheGeometry(pts, 48), m); }
  /* dish antenna with rim, feed and three struts; opens toward +Y */
  function dishAnt(r, depth, m = MAT.dish) {
    const g = grp(dish(r, depth, m));
    g.add(at(mesh(new THREE.TorusGeometry(r, r * .025, 6, 40), MAT.alu), 0, depth, 0, Math.PI / 2, 0, 0));
    const feed = V(0, depth + r * .55, 0); g.add(at(cyl(r * .07, r * .05, r * .12, 12, MAT.dark), feed.x, feed.y, feed.z));
    for (let i = 0; i < 3; i++) { const a = i / 3 * Math.PI * 2; g.add(rod(V(Math.cos(a) * r * .92, depth * .92, Math.sin(a) * r * .92), feed, r * .012, MAT.alu)); }
    return g;
  }
  function solarPanel(w, h, m) { const g = new THREE.Group(); g.add(box(w, .012, h, m || MAT.solar)); const nx = Math.max(2, Math.round(w / .09)), nz = Math.max(2, Math.round(h / .09)); for (let i = 1; i < nx; i++) g.add(at(box(.004, .014, h, MAT.alu), -w / 2 + i * w / nx, 0, 0)); for (let j = 1; j < nz; j++) g.add(at(box(w, .014, .003, MAT.blue), 0, 0, -h / 2 + j * h / nz)); g.add(at(box(w * .98, .006, h * .98, MAT.white), 0, -.008, 0)); [[0, h / 2], [0, -h / 2]].forEach(([x, z]) => g.add(at(box(w + .02, .02, .015, MAT.alu), x, 0, z))); [[w / 2, 0], [-w / 2, 0]].forEach(([x, z]) => g.add(at(box(.015, .02, h + .02, MAT.alu), x, 0, z))); return g; }
  /* solar wing of n panels along +X starting at x0, with yoke */
  function wing(n, w, h, gap, x0, m) { const g = new THREE.Group(); for (let i = 0; i < n; i++) g.add(at(solarPanel(w, h, m), x0 + w / 2 + i * (w + gap), 0, 0)); g.add(rod(V(0, 0, h * .3), V(x0, 0, 0), .012, MAT.alu)); g.add(rod(V(0, 0, -h * .3), V(x0, 0, 0), .012, MAT.alu)); g.add(at(cyl(.025, .025, .05, 12, MAT.anod), 0, 0, 0, 0, 0, Math.PI / 2)); return g; }
  function nozzle(rt, rb, h, m = MAT.dark) { const g = grp(cyl(rt, rb, h, 24, m, true)); g.add(at(mesh(new THREE.TorusGeometry(rb, rb * .04, 6, 24), MAT.anod), 0, -h / 2, 0, Math.PI / 2, 0, 0)); g.add(at(cyl(rt * 1.3, rt * 1.3, h * .18, 16, MAT.anod), 0, h / 2 + h * .06, 0)); return g; }
  function thrusterQuad(s = .04) { const g = grp(box(s, s, s, MAT.anod)); [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0]].forEach(d => { const c = cyl(s * .12, s * .3, s * .6, 10, MAT.dark, true); c.position.set(d[0] * s * .75, d[1] * s * .75, 0); orient(c, V(-d[0], -d[1], 0)); g.add(c); }); return g; }
  function whip(a, b) { const g = grp(rod(a, b, .005, MAT.alu)); g.add(at(sph(.012, MAT.alu, 8, 6), b.x, b.y, b.z)); return g; }
  function wheel(r, w, spokes = 6, tireMat = MAT.tire) {
    const g = new THREE.Group();
    g.add(cyl(r, r, w, 26, tireMat)); g.add(cyl(r * .45, r * .45, w * 1.08, 14, MAT.alu));
    for (let k = -1; k <= 1; k += 2) g.add(at(mesh(new THREE.TorusGeometry(r * .99, r * .05, 6, 26), MAT.alu), 0, k * w * .48, 0, Math.PI / 2, 0, 0));
    for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; g.add(at(box(r * .1, w * 1.02, r * .06, MAT.anod), Math.cos(a) * r * .98, 0, Math.sin(a) * r * .98, 0, -a, 0)); }
    for (let i = 0; i < spokes; i++) { const a = i / spokes * Math.PI * 2; g.add(at(box(.008, w * .9, r * 1.6, MAT.alu), 0, 0, 0, 0, a, 0)); }
    g.rotation.z = Math.PI / 2; const o = new THREE.Group(); o.add(g); return o;
  }
  function leg(g, ang, rTop, yTop, rFoot, yFoot, pad = .075, m = MAT.alu) {
    const a = V(Math.cos(ang) * rTop, yTop, Math.sin(ang) * rTop), b = V(Math.cos(ang) * rFoot, yFoot, Math.sin(ang) * rFoot);
    g.add(rod(a, b, .02, m)); g.add(rod(a, a.clone().lerp(b, .45), .028, MAT.anod));
    const s1 = V(Math.cos(ang + .35) * rTop * .9, yTop - .1, Math.sin(ang + .35) * rTop * .9), s2 = V(Math.cos(ang - .35) * rTop * .9, yTop - .1, Math.sin(ang - .35) * rTop * .9);
    const mid = a.clone().lerp(b, .62); g.add(rod(s1, mid, .01, MAT.alu)); g.add(rod(s2, mid, .01, MAT.alu));
    g.add(at(cyl(pad, pad * 1.15, .03, 20, MAT.alu), b.x, b.y - .005, b.z)); g.add(at(cyl(pad * .3, pad * .3, .04, 10, MAT.anod), b.x, b.y + .02, b.z));
  }
  function rocker6(g, w, l, y, r) {
    [-1, 1].forEach(s => {
      const x = s * w / 2, pivot = V(s * w * .42, y, -l * .05);
      [-l / 2, 0, l / 2].forEach(z => g.add(at(wheel(r, r * .85, 6), x, r, z)));
      g.add(rod(pivot, V(x, r * 1.9, -l / 2), .013, MAT.alu)); g.add(rod(V(x, r * 1.9, -l / 2), V(x, r, -l / 2), .012, MAT.alu));
      const bog = V(x, r * 1.8, l * .25); g.add(rod(pivot, bog, .013, MAT.alu));
      g.add(rod(bog, V(x, r, 0), .012, MAT.alu)); g.add(rod(bog, V(x, r * 1.4, l / 2), .012, MAT.alu)); g.add(rod(V(x, r * 1.4, l / 2), V(x, r, l / 2), .012, MAT.alu));
      g.add(at(cyl(.025, .025, .04, 12, MAT.anod), pivot.x, pivot.y, pivot.z, 0, 0, Math.PI / 2));
    });
  }
  function mast(g, base, h, headW = .14) {
    g.add(rod(base, base.clone().add(V(0, h, 0)), .014, MAT.white));
    const head = grp(box(headW, headW * .42, headW * .4, MAT.white)); [-1, 1].forEach(s => head.add(at(cyl(.016, .016, .02, 12, MAT.glass), s * headW * .3, 0, headW * .21, Math.PI / 2, 0, 0)));
    head.add(at(box(headW * .3, headW * .3, headW * .3, MAT.anod), 0, headW * .32, 0)); g.add(at(head, base.x, base.y + h + headW * .2, base.z)); return head;
  }
  function retro(w, n, m = MAT.alu) { const g = grp(box(w, .03, w * .8, m)); for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) g.add(at(cyl(w / n * .35, w / n * .35, .012, 10, MAT.glass), -w / 2 + (i + .5) * w / n, .02, -w * .4 + (j + .5) * w * .8 / n)); return g; }

  /* MLI blanket box: quilted faces with seams and tape edges so insulation reads as fabric */
  function quilt(w, h, d, m, seamM = MAT.seam, n = 3) {
    const g = grp(box(w, h, d, m));
    for (let i = 1; i < n; i++) { const x = -w / 2 + i * w / n, z = -d / 2 + i * d / n;
      g.add(at(box(.006, h + .004, d + .004, seamM), x, 0, 0)); g.add(at(box(w + .004, h + .004, .006, seamM), 0, 0, z)); g.add(at(box(w + .004, .006, d + .004, seamM), 0, -h / 2 + i * h / n, 0)); }
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => g.add(at(box(.012, h + .006, .012, MAT.cream), a * w / 2, 0, b * d / 2)));
    return g;
  }
  function cable(pts, r = .005, m = MAT.black) { const c = new THREE.CatmullRomCurve3(pts); return mesh(new THREE.TubeGeometry(c, 16, r, 5, false), m); }
  function bolts(g, cx, cy, cz, w, d, n = 4) { for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2 + Math.PI / 4; g.add(at(cyl(.008, .008, .008, 6, MAT.anod), cx + Math.cos(a) * w / 2, cy, cz + Math.sin(a) * d / 2)); } }
  function flagPlate(w, h, colors, axis = 'h') { const g = new THREE.Group(); colors.forEach((c, i) => { const k = colors.length; g.add(axis === 'h' ? at(box(w, h / k, .004, c), 0, h / 2 - (i + .5) * h / k, 0) : at(box(w / k, h, .004, c), -w / 2 + (i + .5) * w / k, 0, 0)); }); return g; }
  const Models = {
    /* Luna 2: polished 1.2 m sphere, four whip antennas, magnetometer boom, sensor belt */
    luna2() {
      const g = new THREE.Group(); g.add(sph(.28, MAT.polish, 40, 24));
      g.add(at(mesh(new THREE.TorusGeometry(.285, .012, 8, 48), MAT.anod), 0, 0, 0, Math.PI / 2, 0, 0));
      for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; g.add(at(box(.05, .04, .03, [MAT.kapton, MAT.anod, MAT.copper, MAT.black][i % 4], ), Math.cos(a) * .29, 0, Math.sin(a) * .29, 0, -a, 0)); }
      g.add(at(mesh(new THREE.TorusGeometry(.2, .008, 6, 40), MAT.red), 0, .19, 0, Math.PI / 2, 0, 0)); g.add(at(mesh(new THREE.TorusGeometry(.2, .008, 6, 40), MAT.red), 0, -.19, 0, Math.PI / 2, 0, 0));
      for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; g.add(at(mesh(new THREE.IcosahedronGeometry(.03, 0), MAT.copper), Math.cos(a) * .12, -.25, Math.sin(a) * .12)); }
      [[.5, .7, .3, .95], [-.5, .7, .3, .95], [.3, .7, -.6, .62], [-.3, .7, -.6, .62]].forEach(d => { const v = V(d[0], d[1], d[2]).normalize(); g.add(at(cyl(.014, .014, .03, 10, MAT.anod), v.x * .275, v.y * .275, v.z * .275)); g.add(whip(v.clone().multiplyScalar(.27), v.clone().multiplyScalar(d[3]))); });
      g.add(rod(V(0, .27, 0), V(0, .66, 0), .012, MAT.alu)); g.add(at(cyl(.035, .035, .08, 14, MAT.dark), 0, .68, 0)); g.add(at(sph(.035, MAT.dark, 12, 8), 0, .72, 0));
      g.add(at(cyl(.09, .14, .1, 20, MAT.alu), 0, -.31, 0)); g.add(at(cyl(.06, .06, .05, 16, MAT.dark), 0, -.38, 0));
      [-1, 1].forEach(s => g.add(at(sph(.06, MAT.polish, 16, 10), s * .2, -.14, .14)));
      return g;
    },
    /* Ranger 7: hexagonal bus, two solar panels, tall camera shroud, high-gain dish, omni antenna */
    ranger() {
      const g = new THREE.Group();
      g.add(cyl(.4, .4, .1, 6, MAT.alu)); g.add(at(cyl(.36, .36, .02, 6, MAT.dark), 0, .06, 0));
      for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2 + Math.PI / 6; g.add(at(i % 2 ? quilt(.26, .14, .08, MAT.kapton) : box(.26, .14, .08, MAT.white), Math.sin(a) * .32, -.1, Math.cos(a) * .32, 0, a, 0)); g.add(at(box(.2, .1, .01, i % 2 ? MAT.black : MAT.foilSilver), Math.sin(a) * .365, -.1, Math.cos(a) * .365, 0, a, 0)); }
      const cam = grp(cyl(.12, .27, .58, 6, MAT.polish)); for (let k = 0; k < 4; k++) cam.add(at(cyl(.27 - k * .045 + .005, .27 - k * .045 + .005, .012, 6, k % 2 ? MAT.kapton : MAT.anod), 0, -.25 + k * .13, 0)); cam.add(at(cyl(.08, .12, .1, 6, MAT.anod), 0, .34, 0)); cam.add(at(cyl(.05, .05, .06, 12, MAT.glass), 0, .41, 0));
      for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; cam.add(at(cyl(.025, .025, .05, 10, MAT.glass), Math.sin(a) * .2, -.1, Math.cos(a) * .2, Math.PI / 2 - .2, a, 0)); }
      g.add(at(cam, 0, .36, 0)); g.add(whip(V(0, .82, 0), V(0, 1.12, 0)));
      [-1, 1].forEach(s => { g.add(at(solarPanel(.66, .34), s * .76, -.02, 0)); g.add(rod(V(s * .35, -.02, .1), V(s * .44, -.02, .16), .01, MAT.alu)); g.add(rod(V(s * .35, -.02, -.1), V(s * .44, -.02, -.16), .01, MAT.alu)); });
      g.add(rod(V(0, -.06, .3), V(0, -.36, .52), .014, MAT.alu)); g.add(at(dishAnt(.24, .07), 0, -.38, .55, -Math.PI / 2.2, 0, 0));
      g.add(at(nozzle(.04, .07, .12), 0, -.14, 0));
      return g;
    },
    /* Luna 9: sealed sphere on the surface with four opened petals, camera turret and four whip antennas */
    luna9() {
      const g = new THREE.Group(); g.add(at(sph(.25, MAT.polish, 32, 18), 0, .22, 0));
      g.add(at(mesh(new THREE.TorusGeometry(.25, .012, 8, 40), MAT.anod), 0, .22, 0, Math.PI / 2, 0, 0));
      for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; const p = grp(box(.36, .012, .3, MAT.cream)); p.add(at(box(.3, .004, .24, MAT.foilSilver), 0, .008, 0)); p.add(at(box(.36, .012, .02, MAT.alu), 0, .01, .15)); p.add(at(box(.02, .012, .3, MAT.alu), .17, .01, 0)); p.add(at(box(.02, .012, .3, MAT.alu), -.17, .01, 0)); g.add(at(p, Math.sin(a) * .36, .05, Math.cos(a) * .36, 0, a, 0)); g.add(rod(V(Math.sin(a) * .2, .14, Math.cos(a) * .2), V(Math.sin(a) * .26, .06, Math.cos(a) * .26), .008, MAT.alu)); }
      for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4; const v = V(Math.cos(a), 1.1, Math.sin(a)).normalize(); g.add(whip(v.clone().multiplyScalar(.22).add(V(0, .22, 0)), v.clone().multiplyScalar(.82).add(V(0, .22, 0)))); }
      const cam = grp(cyl(.05, .06, .16, 16, MAT.anod)); cam.add(at(cyl(.045, .045, .05, 16, MAT.glass), 0, .1, 0)); cam.add(at(cyl(.0, .05, .05, 16, MAT.polish), 0, .15, 0));
      g.add(at(cam, 0, .52, 0)); [0, 1, 2, 3].forEach(i => { const a = i * Math.PI / 2; g.add(at(box(.03, .03, .05, MAT.dark), Math.cos(a) * .06, .5, Math.sin(a) * .06)); });
      g.add(at(cyl(.12, .14, .04, 20, MAT.anod), 0, .02, 0));
      return g;
    },
    /* Surveyor 3: triangular frame, three legs, mast with solar panel and planar antenna, compartments, TV camera, sampler arm */
    surveyor() {
      const g = new THREE.Group(), tri = [0, 1, 2].map(i => i / 3 * Math.PI * 2 + Math.PI / 6);
      const P = tri.map(a => V(Math.cos(a) * .32, .36, Math.sin(a) * .32));
      for (let i = 0; i < 3; i++) { g.add(rod(P[i], P[(i + 1) % 3], .016, MAT.alu)); g.add(rod(P[i], V(0, .72, 0), .012, MAT.alu)); g.add(rod(P[i], P[(i + 1) % 3].clone().lerp(V(0, .72, 0), .5), .008, MAT.alu)); }
      tri.forEach(a => leg(g, a, .32, .36, .78, 0, .1));
      g.add(rod(V(0, .36, 0), V(0, 1.25, 0), .02, MAT.alu));
      const sp = solarPanel(.52, .46); g.add(at(sp, 0, 1.22, -.16, -.55, 0, 0));
      const pa = grp(box(.5, .02, .5, MAT.white)); for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) pa.add(at(box(.1, .006, .1, MAT.foilSilver), -.18 + i * .12, .012, -.18 + j * .12)); g.add(at(pa, 0, 1.27, .2, .65, 0, 0));
      [[.26, -.06, .3], [-.24, -.12, .26]].forEach(([x, z, s], k) => { g.add(at(quilt(s, .22, .22, MAT.cream, MAT.seam, 2), x, .5, z)); g.add(at(box(s * .95, .02, .21, MAT.foilSilver), x, .62, z)); g.add(at(box(s * .9, .012, .2, MAT.dark), x, .5, z + .111)); });
      const cam = grp(cyl(.055, .055, .32, 18, MAT.anod)); cam.add(at(cyl(.07, .07, .08, 18, MAT.white), 0, .18, 0)); cam.add(at(box(.1, .02, .14, MAT.polish), 0, .24, .04, .7, 0, 0));
      g.add(at(cam, .08, .64, .34, .25, 0, 0));
      tri.forEach((a, i) => { const v = nozzle(.025, .045, .1); g.add(at(v, Math.cos(a + Math.PI / 3) * .2, .27, Math.sin(a + Math.PI / 3) * .2)); });
      g.add(at(nozzle(.07, .12, .16, MAT.black), 0, .24, 0)); g.add(at(sph(.065, MAT.kapton, 18, 12), .1, .44, -.04)); g.add(at(sph(.065, MAT.kapton, 18, 12), -.1, .44, -.04)); g.add(cable([V(.26, .4, -.06), V(.15, .34, .1), V(0, .38, .2), V(.08, .52, .3)]));
      [-1, 1].forEach(s => g.add(whip(V(s * .3, .6, -.15), V(s * .62, .72, -.35))));
      g.add(rod(V(-.1, .42, .3), V(-.25, .3, .62), .012, MAT.alu)); g.add(rod(V(-.25, .3, .62), V(-.3, .08, .7), .01, MAT.alu)); g.add(at(box(.07, .05, .09, MAT.alu), -.3, .06, .72));
      return g;
    },
    /* Apollo Lunar Module descent stage (left behind) with surface hardware per mission */
    lm(variant) {
      const g = new THREE.Group();
      const body = new THREE.Group();
      const ds = cyl(.5, .5, .38, 8, MAT.kapton); ds.rotation.y = Math.PI / 8; body.add(ds);
      for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; const big = i % 2 === 0; const p = quilt(big ? .4 : .36, .34, .02, (i === 0 || i === 4) ? MAT.black : (big ? MAT.kapton : (i % 4 === 1 ? MAT.foilSilver : MAT.kapton)), MAT.seam, 3); p.position.set(Math.sin(a) * .475, 0, Math.cos(a) * .475); p.rotation.y = a; body.add(p); if (big) body.add(at(box(.08, .06, .01, MAT.cream), Math.sin(a) * .49 + Math.cos(a) * .1, .1, Math.cos(a) * .49 - Math.sin(a) * .1, 0, a, 0)); }
      body.add(at(box(.86, .02, .86, MAT.black), 0, -.21, 0, 0, Math.PI / 4, 0));
      body.add(at(box(.86, .03, .86, MAT.foilSilver), 0, .2, 0, 0, Math.PI / 4, 0)); body.add(at(box(.86, .03, .86, MAT.foilBlack), 0, -.2, 0, 0, Math.PI / 4, 0));
      body.add(at(box(.18, .1, .3, MAT.foilSilver), 0, .27, 0)); body.add(at(cyl(.06, .06, .08, 16, MAT.anod), .25, .25, .1));
      g.add(at(body, 0, .6, 0));
      for (let i = 0; i < 4; i++) {
        const a = i * Math.PI / 2, d = V(Math.sin(a), 0, Math.cos(a));
        const top = d.clone().multiplyScalar(.5).add(V(0, .72, 0)), foot = d.clone().multiplyScalar(1.05).add(V(0, .06, 0));
        g.add(rod(top, top.clone().lerp(foot, .55), .034, MAT.kapton)); g.add(rod(top.clone().lerp(foot, .55), foot, .024, MAT.alu));
        const side = V(-d.z, 0, d.x);
        [1, -1].forEach(s => g.add(rod(d.clone().multiplyScalar(.48).addScaledVector(side, s * .22).add(V(0, .44, 0)), d.clone().multiplyScalar(.86).add(V(0, .24, 0)), .013, MAT.alu)));
        g.add(rod(d.clone().multiplyScalar(.5).add(V(0, .42, 0)), d.clone().multiplyScalar(.86).add(V(0, .24, 0)), .015, MAT.kapton));
        g.add(at(cyl(.14, .16, .045, 24, MAT.kapton), foot.x, .025, foot.z)); g.add(at(cyl(.12, .12, .01, 24, MAT.foilSilver), foot.x, .05, foot.z));
        if (i !== 0) g.add(rod(foot.clone().add(V(0, .03, 0)), foot.clone().add(V(0, -.04, 0)).addScaledVector(d, .02).add(V(0, .0, 0)), .004, MAT.alu));
        if (i === 0) {
          for (let k = 0; k < 8; k++) { const p = top.clone().lerp(foot, .12 + k * .1); g.add(at(box(.2, .012, .025, MAT.alu), p.x, p.y, p.z + .03, 0, a + Math.PI / 2 - Math.PI / 2, 0)); }
          g.add(at(box(.3, .02, .2, MAT.foilSilver), top.x, top.y + .01, top.z - .06)); [-1, 1].forEach(s => g.add(rod(V(s * .14, .74, top.z - .02), V(s * .16, .55, foot.z - .1), .01, MAT.alu)));
        }
      }
      g.add(at(nozzle(.13, .26, .26, MAT.black), 0, .3, 0)); g.add(at(mesh(new THREE.TorusGeometry(.26, .02, 6, 30), MAT.copper), 0, .17, 0, Math.PI / 2, 0, 0));
      g.add(at(box(.3, .24, .05, MAT.foilSilver), -.5, .58, .22, 0, -Math.PI / 4, 0));
      Models.lmExtras(g, variant);
      return g;
    },
    /* surface hardware left by each Apollo crew (flag, experiments, LRV) - also used with the NASA LM model */
    lmExtras(g, variant) {
      if (variant === 'a11') {
        const flag = grp(rod(V(0, 0, 0), V(0, .82, 0), .007, MAT.alu), at(rod(V(0, .8, 0), V(.34, .8, 0), .005, MAT.alu), 0, 0, 0), at(box(.34, .21, .004, MAT.flag), .17, .69, 0)); g.add(at(flag, .85, 0, .6));
        const seis = grp(cyl(.06, .08, .14, 14, MAT.foil)); seis.position.y = .07; [-1, 1].forEach(s => seis.add(at(solarPanel(.26, .16), s * .2, .04, 0))); seis.add(whip(V(0, .07, 0), V(0, .2, 0))); g.add(at(seis, -.95, 0, .3));
        const lrrr = grp(retro(.3, 6)); lrrr.add(at(box(.08, .1, .08, MAT.alu), 0, -.06, 0)); g.add(at(lrrr, -.7, .12, .8, -.4, .3, 0));
        const tv = grp(); [0, 1, 2].forEach(k => { const a = k / 3 * Math.PI * 2; tv.add(rod(V(0, .34, 0), V(Math.cos(a) * .1, 0, Math.sin(a) * .1), .005, MAT.alu)); }); tv.add(at(box(.08, .06, .12, MAT.alu), 0, .37, 0)); g.add(at(tv, .3, 0, 1.25));
      }
      if (variant === 'a17') {
        const lrv = new THREE.Group();
        lrv.add(at(box(.82, .035, .4, MAT.alu), 0, .17, 0)); lrv.add(at(box(.8, .015, .36, MAT.dark), 0, .19, 0));
        [[-.32, -1], [-.32, 1], [.32, -1], [.32, 1]].forEach(([x, s]) => { lrv.add(at(wheel(.1, .07, 8, MAT.alu), x, .1, s * .26)); lrv.add(at(cyl(.12, .12, .1, 16, MAT.foil, true), x, .14, s * .26, Math.PI / 2, 0, 0)); lrv.add(at(box(.26, .012, .1, MAT.dark), x, .23, s * .26)); });
        [-.08, .12].forEach(x => { lrv.add(at(box(.13, .02, .15, MAT.anod), x, .22, 0)); lrv.add(at(box(.02, .12, .15, MAT.anod), x - .065, .28, 0)); });
        lrv.add(at(box(.08, .12, .18, MAT.foilSilver), .3, .27, 0)); lrv.add(rod(V(.34, .3, 0), V(.34, .62, 0), .008, MAT.alu)); lrv.add(at(dishAnt(.17, .04, MAT.dish), .34, .64, 0));
        lrv.add(rod(V(.3, .3, .1), V(.3, .5, .1), .006, MAT.alu)); lrv.add(at(box(.06, .05, .06, MAT.dark), .3, .52, .1));
        g.add(at(lrv, 1.15, 0, -.6, 0, .6, 0));
        const als = grp(box(.26, .14, .2, MAT.foilSilver)); als.add(at(box(.28, .02, .22, MAT.white), 0, .08, 0)); als.add(rod(V(0, .08, 0), V(.04, .34, 0), .006, MAT.alu)); als.add(at(cyl(.02, .02, .14, 10, MAT.white), .04, .4, 0, .4, 0, 0)); g.add(at(als, -.95, .07, -.65));
        const flag = grp(rod(V(0, 0, 0), V(0, .82, 0), .007, MAT.alu), at(box(.34, .21, .004, MAT.flag), .17, .69, 0)); g.add(at(flag, .7, 0, .85));
      }
      return g;
    },
    /* Lunokhod 1: convex-bottomed tub, hinged solar lid, eight wire wheels, cameras, helical antenna, reflector, isotope heater */
    lunokhod() {
      const g = new THREE.Group();
      const pts = []; for (let i = 0; i <= 14; i++) { const a = i / 14; pts.push(new THREE.Vector2(.2 + .34 * Math.sin(a * Math.PI / 2), .2 + a * .28)); }
      const tub = mesh(new THREE.LatheGeometry(pts, 48), MAT.foilSilver); g.add(tub); for (let k = 0; k < 4; k++) g.add(at(mesh(new THREE.TorusGeometry(.26 + k * .075, .006, 5, 48), MAT.seam), 0, .24 + k * .065, 0, Math.PI / 2, 0, 0));
      g.add(at(cyl(.2, .2, .02, 32, MAT.foilSilver), 0, .2, 0));
      g.add(at(mesh(new THREE.TorusGeometry(.54, .02, 8, 48), MAT.anod), 0, .48, 0, Math.PI / 2, 0, 0)); g.add(at(cyl(.54, .54, .015, 48, MAT.black), 0, .48, 0)); for (let k = 0; k < 10; k++) g.add(at(box(.9, .006, .02, MAT.foilSilver), 0, .49, -.4 + k * .09));
      for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; g.add(at(box(.06, .26, .01, MAT.anod), Math.cos(a) * .44, .34, Math.sin(a) * .44, 0, -a + Math.PI / 2, -.35)); }
      const lid = new THREE.Group(); lid.add(at(cyl(.52, .52, .025, 48, MAT.white), 0, 0, .52)); lid.add(at(cyl(.5, .5, .012, 48, MAT.solar), 0, -.018, .52)); lid.add(at(mesh(new THREE.TorusGeometry(.525, .012, 6, 48), MAT.alu), 0, 0, .52, Math.PI / 2, 0, 0));
      lid.position.set(0, .49, -.52); lid.rotation.x = -1.1; g.add(lid); g.add(at(cyl(.03, .03, .2, 12, MAT.anod), 0, .49, -.52, 0, 0, Math.PI / 2));
      [-.45, -.15, .15, .45].forEach(z => [-1, 1].forEach(s => { g.add(at(wheel(.13, .08, 8, MAT.anod), s * .56, .13, z)); g.add(rod(V(s * .36, .24, z), V(s * .52, .13, z), .016, MAT.alu)); g.add(at(cyl(.035, .035, .06, 12, MAT.dark), s * .48, .14, z, 0, 0, Math.PI / 2)); }));
      g.add(at(box(.24, .1, .06, MAT.anod), 0, .4, .55)); g.add(at(flagPlate(.12, .08, [MAT.red, MAT.red]), .3, .36, .5, 0, .5, 0)); [-.1, .1].forEach(x => g.add(at(cyl(.035, .035, .08, 14, MAT.glass), x, .4, .6, Math.PI / 2, 0, 0)));
      g.add(at(retro(.2, 4), 0, .5, .5, -.6, 0, 0));
      g.add(rod(V(.22, .48, .25), V(.22, .82, .32), .008, MAT.alu)); const hel = grp(cyl(.0, .07, .16, 16, MAT.alu)); for (let k = 0; k < 6; k++) hel.add(at(mesh(new THREE.TorusGeometry(.06 - k * .009, .005, 4, 16), MAT.anod), 0, -.06 + k * .025, 0, Math.PI / 2, 0, 0)); g.add(at(hel, .22, .9, .33, .5, 0, 0));
      g.add(whip(V(-.28, .48, .2), V(-.32, 1.0, .22))); g.add(whip(V(-.28, .48, -.2), V(-.36, .9, -.3)));
      g.add(at(cyl(.08, .08, .18, 18, MAT.black), 0, .32, -.48, Math.PI / 2, 0, 0)); for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; g.add(at(box(.012, .06, .18, MAT.alu), Math.cos(a) * .09, .32 + Math.sin(a) * .09, -.48, 0, 0, a)); } g.add(rod(V(0, .32, -.38), V(0, .32, -.34), .03, MAT.anod)); g.add(at(cyl(.06, .06, .02, 18, MAT.dark), 0, .32, -.58, Math.PI / 2, 0, 0));
      g.add(at(wheel(.06, .03, 6, MAT.alu), 0, .06, -.6)); g.add(rod(V(0, .22, -.25), V(0, .06, -.6), .01, MAT.alu));
      return g;
    },
    /* Lunar Prospector: solar-cell drum, three 2.5 m booms with instruments, helical antenna mast */
    prospector() {
      const g = new THREE.Group(); g.add(cyl(.33, .33, .44, 32, MAT.solar));
      for (let i = 0; i < 16; i++) { const a = i / 16 * Math.PI * 2; g.add(at(box(.008, .44, .006, MAT.alu), Math.cos(a) * .334, 0, Math.sin(a) * .334, 0, -a, 0)); }
      [.235, -.235].forEach(y => { g.add(at(cyl(.34, .34, .03, 32, MAT.white), 0, y, 0)); g.add(at(mesh(new THREE.TorusGeometry(.34, .01, 6, 32), MAT.alu), 0, y, 0, Math.PI / 2, 0, 0)); });
      const inst = [grp(sph(.06, MAT.anod, 16, 10), at(box(.1, .06, .06, MAT.foil), 0, -.06, 0)), grp(cyl(.07, .07, .16, 16, MAT.white), at(cyl(.075, .075, .02, 16, MAT.foil), 0, .08, 0)), grp(box(.12, .12, .12, MAT.foil), at(box(.13, .02, .13, MAT.white), 0, .07, 0))];
      for (let i = 0; i < 3; i++) { const a = i / 3 * Math.PI * 2, d = V(Math.cos(a), 0, Math.sin(a)); g.add(rod(d.clone().multiplyScalar(.33), d.clone().multiplyScalar(1.25), .012, MAT.alu)); g.add(rod(d.clone().multiplyScalar(.33).add(V(0, .08, 0)), d.clone().multiplyScalar(.7), .006, MAT.alu)); g.add(at(inst[i], d.x * 1.3, 0, d.z * 1.3)); }
      g.add(at(cyl(.12, .12, .02, 20, MAT.kapton), 0, .26, 0)); g.add(at(cyl(.12, .12, .02, 20, MAT.kapton), 0, -.26, 0)); g.add(rod(V(0, .25, 0), V(0, .52, 0), .014, MAT.alu)); const hel = grp(cyl(.035, .035, .2, 12, MAT.white)); for (let k = 0; k < 6; k++) hel.add(at(mesh(new THREE.TorusGeometry(.04, .005, 4, 14), MAT.alu), 0, -.08 + k * .032, 0, Math.PI / 2, 0, 0)); g.add(at(hel, 0, .62, 0));
      [0, 1, 2].forEach(i => { const a = i / 3 * Math.PI * 2 + 1; g.add(at(thrusterQuad(.035), Math.cos(a) * .3, -.27, Math.sin(a) * .3)); });
      return g;
    },
    /* SMART-1: 1 m cube, two 3-panel solar wings, electric (Hall-effect) thruster, camera and antennas */
    smart1() {
      const g = new THREE.Group(); g.add(quilt(.44, .42, .42, MAT.kapton)); g.add(at(box(.46, .02, .44, MAT.black), 0, .22, 0)); g.add(at(box(.3, .3, .01, MAT.foilSilver), 0, 0, .216)); g.add(at(box(.3, .3, .01, MAT.foilSilver), 0, 0, -.216)); g.add(at(flagPlate(.12, .08, [MAT.blue, MAT.blue]), -.12, .1, .222)); for (let k = 0; k < 5; k++) { const a = k / 5 * Math.PI * 2; g.add(at(sph(.006, MAT.yellow, 6, 4), -.12 + Math.cos(a) * .03, .1 + Math.sin(a) * .025, .226)); }
      [-1, 1].forEach(s => { const w = wing(3, .5, .4, .03, .12, MAT.solar); if (s < 0) w.rotation.y = Math.PI; g.add(at(w, s * .22, 0, 0, 0, s < 0 ? Math.PI : 0, 0)); });
      const pps = grp(cyl(.07, .07, .05, 24, MAT.anod)); pps.add(at(mesh(new THREE.TorusGeometry(.05, .012, 6, 24), MAT.dark), 0, -.03, 0, Math.PI / 2, 0, 0)); pps.add(at(cyl(.02, .02, .03, 12, MAT.dark), 0, -.035, 0)); g.add(at(pps, 0, -.25, 0)); g.add(at(cyl(.09, .09, .04, 20, MAT.foilSilver), 0, -.22, 0));
      g.add(at(cyl(.04, .04, .1, 16, MAT.anod), .12, .27, .12)); g.add(at(cyl(.03, .03, .01, 16, MAT.glass), .12, .32, .12));
      g.add(at(dishAnt(.07, .02), -.12, .24, -.12)); [[.18, .18], [-.18, .18]].forEach(([x, z]) => g.add(at(cyl(.02, .03, .06, 12, MAT.white), x, .25, z)));
      return g;
    },
    /* LCROSS Shepherding Spacecraft: ESPA ring with six instrument and avionics panels, solar array, antennas */
    lcross() {
      const g = new THREE.Group(); g.add(cyl(.46, .46, .32, 48, MAT.ringFoil, true)); g.add(cyl(.44, .44, .32, 48, MAT.anod, true));
      [.16, -.16].forEach(y => g.add(at(mesh(new THREE.TorusGeometry(.46, .015, 6, 48), MAT.alu), 0, y, 0, Math.PI / 2, 0, 0)));
      for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; const b = grp(i % 2 ? quilt(.2, .26, .14, MAT.kapton) : box(.2, .26, .14, MAT.white)); b.add(at(box(.16, .06, .01, MAT.black), 0, -.09, .075)); b.add(at(box(.18, .2, .01, MAT.foilSilver), 0, 0, .075)); if (i % 2 === 0) b.add(at(cyl(.035, .035, .05, 12, MAT.dark), 0, .02, .1, Math.PI / 2, 0, 0)); b.position.set(Math.cos(a) * .56, 0, Math.sin(a) * .56); b.lookAt(Math.cos(a) * 2, 0, Math.sin(a) * 2); g.add(b); }
      const sa = solarPanel(.6, .4); g.add(at(sa, 0, .3, -.16, .3, 0, 0));
      g.add(at(dishAnt(.1, .03), .42, -.22, .35, Math.PI, 0, 0)); g.add(whip(V(-.4, .16, .3), V(-.5, .4, .4)));
      g.add(at(cyl(.15, .15, .06, 24, MAT.anod), 0, .19, 0)); for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; g.add(at(thrusterQuad(.03), Math.cos(a) * .4, -.2, Math.sin(a) * .4)); }
      return g;
    },
    /* Centaur upper stage with LCROSS attached (used by the 3D loader) */
    centaur() {
      const g = new THREE.Group(); g.add(cyl(.27, .27, 1.5, 40, MAT.foilSilver));
      [-.5, 0, .5].forEach(y => g.add(at(cyl(.275, .275, .03, 40, MAT.anod, true), 0, y, 0)));
      for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; g.add(at(cyl(.02, .02, 1.4, 8, MAT.anod), Math.cos(a) * .275, 0, Math.sin(a) * .275)); }
      g.add(at(nozzle(.09, .22, .32), 0, -.92, 0)); g.add(at(cyl(.27, .12, .14, 40, MAT.anod), 0, -.8, 0));
      const top = Models.lcross(); top.scale.setScalar(.6); top.position.y = .88; g.add(top); return g;
    },
    /* GRAIL Ebb and Flow: twin washing-machine sized probes with fixed solar arrays */
    grail() {
      const g = new THREE.Group();
      const probe = () => { const p = grp(quilt(.36, .3, .28, MAT.kapton)); p.add(at(box(.2, .12, .01, MAT.black), 0, -.06, -.145)); p.add(at(box(.37, .02, .29, MAT.foilSilver), 0, .16, 0)); p.add(at(box(.3, .24, .01, MAT.white), 0, 0, .145));
        [-1, 1].forEach(s => { p.add(at(solarPanel(.34, .28), s * .36, .02, 0)); p.add(rod(V(s * .18, .02, 0), V(s * .2, .02, 0), .02, MAT.alu)); });
        p.add(at(cyl(.035, .035, .05, 12, MAT.dark), 0, .19, .06)); p.add(at(dishAnt(.05, .015), 0, 0, .16, Math.PI / 2, 0, 0)); p.add(at(cyl(.025, .025, .04, 12, MAT.glass), .1, .06, .15, Math.PI / 2, 0, 0)); p.add(at(nozzle(.025, .04, .06), 0, -.18, 0)); return p; };
      g.add(at(probe(), -.55, 0, 0, 0, .25, 0)); g.add(at(probe(), .55, .25, 0, 0, -.25 + Math.PI, 0)); return g;
    },
    /* Beresheet: four spherical tanks, hexagonal top deck with solar cells, four legs, main engine */
    beresheet() {
      const g = new THREE.Group();
      [[-.13, -.13], [.13, -.13], [-.13, .13], [.13, .13]].forEach(([x, z]) => g.add(at(sph(.14, MAT.alu, 24, 14), x, .46, z)));
      g.add(at(cyl(.42, .42, .1, 6, MAT.foilBlack), 0, .66, 0)); g.add(at(cyl(.39, .39, .01, 6, MAT.solar), 0, .715, 0));
      for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2 + Math.PI / 6; g.add(at(box(.36, .09, .01, MAT.solar), Math.sin(a) * .36, .66, Math.cos(a) * .36, 0, a, 0)); }
      g.add(at(cyl(.3, .3, .02, 6, MAT.alu), 0, .3, 0));
      for (let i = 0; i < 4; i++) leg(g, i * Math.PI / 2 + Math.PI / 4, .3, .4, .64, .02, .07);
      g.add(at(nozzle(.05, .09, .14), 0, .2, 0)); for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; g.add(at(thrusterQuad(.03), Math.cos(a) * .32, .62, Math.sin(a) * .32)); }
      g.add(at(cyl(.05, .05, .06, 12, MAT.dark), .2, .75, .1)); g.add(at(box(.12, .06, .08, MAT.white), -.15, .75, -.1)); g.add(at(flagPlate(.16, .11, [MAT.blue, MAT.white, MAT.white, MAT.white, MAT.blue]), 0, .66, .38)); g.add(at(sph(.012, MAT.blue, 6, 4), 0, .66, .385)); for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4; g.add(cable([V(Math.cos(a) * .1, .52, Math.sin(a) * .1), V(Math.cos(a) * .2, .42, Math.sin(a) * .2), V(0, .3, 0)], .006, MAT.copper)); }
      return g;
    },
    /* Chang'e 3 lander with Yutu rover beside it */
    yutu() {
      const g = new THREE.Group();
      const lander = new THREE.Group(); lander.add(at(quilt(.62, .36, .62, MAT.kapton), 0, .5, 0)); lander.add(at(flagPlate(.15, .1, [MAT.red]), .1, .55, .315)); lander.add(at(sph(.012, MAT.yellow, 6, 4), .06, .58, .32)); lander.add(at(box(.64, .02, .64, MAT.foilSilver), 0, .69, 0));
      [-1, 1].forEach(s => lander.add(at(solarPanel(.55, .5), s * .64, .78, 0, 0, 0, s * .45)));
      for (let i = 0; i < 4; i++) leg(lander, i * Math.PI / 2 + Math.PI / 4, .4, .4, .76, .02, .09);
      lander.add(rod(V(.2, .7, .2), V(.2, 1.0, .2), .012, MAT.alu)); lander.add(at(dishAnt(.13, .04), .2, 1.02, .2, -.4, 0, 0));
      lander.add(at(nozzle(.06, .11, .16), 0, .25, 0)); [-1, 1].forEach(s => lander.add(rod(V(.31, .52, s * .14), V(.72, .02, s * .14), .01, MAT.alu)));
      lander.add(at(cyl(.04, .04, .08, 12, MAT.anod), -.2, .74, .2)); lander.add(at(box(.1, .06, .06, MAT.white), -.2, .8, .2));
      g.add(lander);
      const r = new THREE.Group(); r.add(at(quilt(.38, .15, .5, MAT.kapton), 0, .22, 0)); r.add(at(flagPlate(.08, .05, [MAT.red]), .19, .24, 0, 0, Math.PI / 2, 0)); r.add(at(box(.39, .02, .51, MAT.foilSilver), 0, .3, 0));
      [-1, 1].forEach(s => r.add(at(solarPanel(.3, .44), s * .34, .32, 0, 0, 0, s * .3)));
      mast(r, V(0, .3, .16), .22, .16); r.add(at(dishAnt(.06, .02), -.1, .36, -.15, -.3, 0, 0));
      r.add(rod(V(.1, .2, .26), V(.12, .12, .36), .01, MAT.alu)); r.add(at(box(.05, .05, .05, MAT.anod), .12, .1, .38));
      rocker6(r, .44, .38, .18, .065); g.add(at(r, 1.35, 0, .95, 0, -.5, 0)); return g;
    },
    /* Mars 3 lander: spherical lander with petals, antennas and the PrOP-M tethered skid rover */
    mars3() {
      const g = new THREE.Group(); g.add(at(sph(.3, MAT.polish, 32, 18), 0, .3, 0)); g.add(at(mesh(new THREE.TorusGeometry(.3, .014, 8, 40), MAT.anod), 0, .3, 0, Math.PI / 2, 0, 0));
      for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; const p = grp(box(.32, .015, .44, MAT.alu)); p.add(at(box(.3, .006, .4, MAT.foilSilver), 0, .01, 0)); g.add(at(p, Math.sin(a) * .46, .04, Math.cos(a) * .46, 0, a, 0)); g.add(rod(V(Math.sin(a) * .26, .18, Math.cos(a) * .26), V(Math.sin(a) * .3, .05, Math.cos(a) * .3), .008, MAT.alu)); }
      for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4; g.add(whip(V(Math.cos(a) * .25, .4, Math.sin(a) * .25), V(Math.cos(a) * .58, .92, Math.sin(a) * .58))); }
      [-1, 1].forEach(s => { const c = grp(cyl(.04, .04, .1, 14, MAT.anod)); c.add(at(cyl(.03, .03, .02, 14, MAT.glass), 0, .06, 0)); g.add(at(c, s * .12, .62, 0)); });
      const prop = grp(box(.16, .06, .22, MAT.copper)); [-1, 1].forEach(s => prop.add(at(box(.02, .03, .26, MAT.dark), s * .09, -.03, 0))); g.add(at(prop, .9, .04, .2)); g.add(rod(V(.3, .1, .1), V(.8, .05, .2), .003, MAT.dark));
      return g;
    },
    /* Mariner 9: octagonal bus, four solar panels, high-gain dish, scan platform, large engine */
    mariner9() {
      const g = new THREE.Group(); g.add(cyl(.4, .4, .32, 8, MAT.foilBlack)); for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2 + Math.PI / 8; g.add(at(i % 2 ? quilt(.28, .26, .02, MAT.kapton, MAT.seam, 2) : box(.28, .26, .01, MAT.foilSilver), Math.sin(a) * .375, 0, Math.cos(a) * .375, 0, a, 0)); if (i % 2 === 0) for (let k = 0; k < 5; k++) g.add(at(box(.24, .012, .012, MAT.black), Math.sin(a) * .385, -.1 + k * .05, Math.cos(a) * .385, 0, a, 0)); }
      for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; const p = grp(solarPanel(.9, .34)); p.add(rod(V(-.45, 0, 0), V(-.6, 0, 0), .012, MAT.alu)); g.add(at(p, Math.cos(a) * 1.0, .06, Math.sin(a) * 1.0, 0, -a, 0)); }
      g.add(at(dishAnt(.32, .08), 0, .18, 0)); g.add(rod(V(.2, .16, .2), V(.28, .74, .28), .008, MAT.alu)); g.add(at(cyl(.06, .06, .22, 12, MAT.white), .29, .84, .29));
      const scan = grp(box(.26, .14, .22, MAT.anod)); [-.07, 0, .07].forEach(x => scan.add(at(cyl(.025, .025, .06, 12, MAT.glass), x, -.09, .05))); g.add(at(scan, 0, -.26, .16));
      g.add(at(nozzle(.06, .16, .22), 0, -.3, -.12)); g.add(at(sph(.13, MAT.alu, 18, 12), .2, -.22, -.15)); g.add(at(sph(.13, MAT.alu, 18, 12), -.2, -.22, -.15));
      return g;
    },
    /* Viking Lander: hexagonal body, three legs, RTGs, S-band dish, meteorology boom, cameras, sampler arm */
    viking() {
      const g = new THREE.Group(); g.add(at(cyl(.44, .44, .18, 6, MAT.cream), 0, .34, 0)); for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2 + Math.PI / 6; g.add(at(box(.36, .1, .01, i % 2 ? MAT.kapton : MAT.foilSilver), Math.sin(a) * .385, .34, Math.cos(a) * .385, 0, a, 0)); }
      g.add(at(flagPlate(.12, .07, [MAT.red, MAT.white, MAT.red, MAT.white, MAT.red]), -.05, .34, .4)); g.add(at(box(.05, .035, .006, MAT.blue), -.085, .357, .405)); g.add(at(cyl(.45, .45, .02, 6, MAT.anod), 0, .44, 0));
      for (let i = 0; i < 3; i++) leg(g, i / 3 * Math.PI * 2 + Math.PI / 6, .4, .28, .66, 0, .09);
      [-1, 1].forEach(s => { const rtg = grp(box(.12, .14, .26, MAT.dark)); for (let k = -3; k <= 3; k++) rtg.add(at(box(.15, .1, .006, MAT.dark), 0, 0, k * .035)); rtg.add(at(box(.13, .02, .27, MAT.white), 0, .08, 0)); g.add(at(rtg, s * .24, .52, -.12)); });
      g.add(rod(V(-.26, .44, .12), V(-.26, .82, .12), .016, MAT.alu)); g.add(at(dishAnt(.2, .05), -.26, .84, .12, -.7, 0, 0));
      [-1, 1].forEach(s => { const c = grp(cyl(.045, .045, .2, 14, MAT.anod)); c.add(at(cyl(.05, .05, .04, 14, MAT.white), 0, .12, 0)); c.add(at(box(.03, .04, .01, MAT.glass), 0, .05, .045)); g.add(at(c, .22, .55, s * .17)); });
      g.add(rod(V(.34, .44, -.15), V(.4, .76, -.3), .008, MAT.alu)); g.add(at(box(.07, .04, .12, MAT.alu), .4, .78, -.3)); g.add(at(cyl(.008, .008, .1, 6, MAT.alu), .44, .78, -.3, 0, 0, Math.PI / 2));
      g.add(at(box(.035, .035, .52, MAT.alu), .05, .3, .5, .18, 0, 0)); g.add(at(box(.09, .07, .09, MAT.anod), .05, .25, .76)); g.add(at(box(.08, .04, .04, MAT.alu), .05, .2, .8));
      g.add(at(box(.1, .06, .06, MAT.white), -.1, .47, .2)); g.add(at(cyl(.04, .04, .04, 12, MAT.anod), 0, .47, -.3));
      [0, 1, 2].forEach(i => { const a = i / 3 * Math.PI * 2 + Math.PI / 2; g.add(at(nozzle(.025, .05, .08), Math.cos(a) * .3, .22, Math.sin(a) * .3)); });
      return g;
    },
    /* Mars Pathfinder: tetrahedral lander with opened petals, deflated airbags, camera mast, and Sojourner */
    pathfinder() {
      const g = new THREE.Group();
      g.add(at(cyl(.3, .3, .12, 3, MAT.white), 0, .1, 0, 0, Math.PI / 6, 0)); g.add(at(cyl(.22, .22, .02, 3, MAT.kapton), 0, .17, 0, 0, Math.PI / 6, 0));
      for (let i = 0; i < 3; i++) { const a = i / 3 * Math.PI * 2 + Math.PI / 3; const p = grp(cyl(.32, .32, .02, 3, MAT.solar)); p.add(at(cyl(.33, .33, .01, 3, MAT.white), 0, -.012, 0)); p.position.set(Math.cos(a) * .5, .04, Math.sin(a) * .5); p.rotation.y = -a + Math.PI / 6; g.add(p); g.add(rod(V(Math.cos(a) * .2, .1, Math.sin(a) * .2), V(Math.cos(a) * .3, .05, Math.sin(a) * .3), .01, MAT.alu)); }
      /* deflated, retracted airbags bunched in the three gaps between the petals */
      for (let k = 0; k < 3; k++) { const a0 = k / 3 * Math.PI * 2; [[-.16, .62, .08], [0, .7, .1], [.16, .62, .08], [-.08, .86, .07], [.08, .86, .07]].forEach(([da, d, r], j) => g.add(at(mesh(new THREE.IcosahedronGeometry(r, 1), (j + k) % 2 ? MAT.cream : MAT.bag), Math.cos(a0 + da) * d, r * .7, Math.sin(a0 + da) * d, j * .7, k, j * .3))); }
      g.add(rod(V(0, .16, 0), V(0, .72, 0), .016, MAT.alu)); const imp = grp(box(.16, .09, .09, MAT.white)); [-1, 1].forEach(s => imp.add(at(cyl(.022, .022, .03, 12, MAT.glass), s * .045, 0, .05, Math.PI / 2, 0, 0))); g.add(at(imp, 0, .77, 0));
      g.add(rod(V(.1, .16, .05), V(.12, .4, .05), .01, MAT.alu)); g.add(at(dishAnt(.07, .02), .12, .42, .05, -.3, 0, 0)); g.add(rod(V(-.1, .16, -.05), V(-.16, .5, -.08), .008, MAT.alu)); g.add(at(box(.04, .06, .04, MAT.white), -.16, .53, -.08));
      const soj = new THREE.Group(); soj.add(at(box(.26, .07, .18, MAT.white), 0, .14, 0)); soj.add(at(box(.3, .012, .22, MAT.solar), 0, .19, 0)); soj.add(whip(V(.08, .19, -.06), V(.08, .34, -.06))); soj.add(at(box(.06, .04, .03, MAT.anod), .14, .14, 0)); rocker6(soj, .3, .22, .13, .04);
      g.add(at(soj, .95, 0, -.3, 0, .8, 0)); g.add(rod(V(.5, .05, -.15), V(.78, .02, -.25), .015, MAT.alu));
      return g;
    },
    /* Mars Climate Orbiter: box bus, single three-panel solar wing, high-gain dish, main engine */
    mco() {
      const g = new THREE.Group(); g.add(quilt(.5, .52, .62, MAT.kapton)); g.add(at(box(.3, .3, .01, MAT.black), 0, .05, -.316)); g.add(at(box(.52, .02, .64, MAT.foilSilver), 0, .27, 0)); g.add(at(box(.4, .4, .01, MAT.white), 0, 0, .315));
      g.add(at(wing(3, .38, .7, .03, .22, MAT.solar), .25, 0, 0));
      g.add(rod(V(-.1, .27, .1), V(-.1, .44, .1), .015, MAT.alu)); g.add(at(dishAnt(.22, .06), -.1, .46, .1, -.4, 0, 0));
      g.add(at(nozzle(.06, .13, .18), 0, -.36, 0)); for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4; g.add(at(thrusterQuad(.035), Math.cos(a) * .3, -.27, Math.sin(a) * .34)); }
      g.add(at(box(.12, .1, .12, MAT.white), -.15, .32, -.18)); g.add(at(cyl(.04, .04, .1, 12, MAT.anod), .15, .32, -.18));
      return g;
    },
    /* Mars Polar Lander: hexagonal deck, three legs, two solar wings, MVACS mast, robotic arm, sampler */
    mpl() {
      const g = new THREE.Group(); g.add(at(cyl(.42, .42, .16, 6, MAT.kapton), 0, .28, 0)); for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2 + Math.PI / 6; g.add(at(box(.36, .12, .008, i % 2 ? MAT.black : MAT.foilSilver), Math.sin(a) * .37, .28, Math.cos(a) * .37, 0, a, 0)); } g.add(at(cyl(.43, .43, .02, 6, MAT.white), 0, .37, 0));
      for (let i = 0; i < 3; i++) leg(g, i / 3 * Math.PI * 2 + .5, .36, .22, .62, -.06, .07);
      [-1, 1].forEach(s => { const p = grp(solarPanel(.5, .34)); p.add(at(solarPanel(.24, .34), s * .37, 0, 0)); g.add(at(p, s * .7, .38, 0, 0, 0, s * .12)); });
      g.add(rod(V(.12, .37, .1), V(.12, .76, .1), .016, MAT.alu)); const ssi = grp(box(.14, .08, .08, MAT.white)); [-1, 1].forEach(s => ssi.add(at(cyl(.02, .02, .03, 12, MAT.glass), s * .04, 0, .05, Math.PI / 2, 0, 0))); g.add(at(ssi, .12, .8, .1));
      g.add(rod(V(-.15, .38, -.1), V(-.4, .52, -.25), .012, MAT.alu)); g.add(at(box(.05, .04, .05, MAT.white), -.42, .54, -.26));
      g.add(rod(V(.2, .37, .2), V(.42, .52, .45), .016, MAT.alu)); g.add(rod(V(.42, .52, .45), V(.52, .1, .62), .013, MAT.alu)); g.add(at(box(.07, .05, .08, MAT.alu), .52, .08, .64));
      g.add(at(dishAnt(.09, .025), -.12, .4, .18, -.6, 0, 0)); [-1, 1].forEach(s => g.add(at(cyl(.05, .05, .1, 14, MAT.anod), s * .2, .3, -.32)));
      return g;
    },
    /* Mars Global Surveyor: box bus, two 2-panel solar wings, articulated high-gain antenna, MOC camera */
    mgs() {
      const g = new THREE.Group(); g.add(quilt(.46, .58, .46, MAT.kapton)); g.add(at(box(.3, .4, .01, MAT.black), 0, 0, -.236)); g.add(at(box(.48, .02, .48, MAT.foilSilver), 0, .3, 0));
      [-1, 1].forEach(s => { const w = wing(2, .42, .56, .03, .12, MAT.solar); g.add(at(w, s * .23, .05, 0, 0, s < 0 ? Math.PI : 0, 0)); g.add(at(box(.1, .2, .01, MAT.white), s * .55 + s * .45, .05, .3)); });
      g.add(rod(V(0, .3, .1), V(0, .95, .32), .016, MAT.alu)); g.add(at(dishAnt(.26, .07), 0, .97, .34, -.6, 0, 0));
      const moc = grp(cyl(.07, .07, .32, 18, MAT.white)); moc.add(at(cyl(.07, .07, .02, 18, MAT.glass), 0, -.17, 0)); g.add(at(moc, .12, -.36, .1));
      g.add(at(cyl(.05, .05, .14, 14, MAT.anod), -.12, -.33, .1)); g.add(at(box(.1, .1, .1, MAT.white), -.12, -.33, -.14)); g.add(at(nozzle(.05, .1, .14), 0, .34, -.12, Math.PI, 0, 0));
      return g;
    },
    /* Beagle 2: clam-shell lander with only some of its solar petals unfolded, blocking the antenna (as seen by HiRISE) */
    beagle2() {
      const g = new THREE.Group(); g.add(at(cyl(.4, .42, .14, 48, MAT.anod), 0, .07, 0)); g.add(at(mesh(new THREE.TorusGeometry(.41, .015, 6, 48), MAT.alu), 0, .14, 0, Math.PI / 2, 0, 0));
      const petalP = () => { const p = grp(cyl(.26, .26, .02, 5, MAT.solar)); p.add(at(cyl(.265, .265, .008, 5, MAT.white), 0, -.012, 0)); return p; };
      for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; const open = i < 2; const p = petalP(); if (open) p.position.set(Math.cos(a) * .62, .02, Math.sin(a) * .62); else { p.position.set(Math.cos(a) * .2, .22 + i * .03, Math.sin(a) * .2); p.rotation.set(Math.sin(a) * .5, 0, -Math.cos(a) * .5); } g.add(p); }
      const lid = grp(cyl(.38, .38, .03, 48, MAT.kapton)); lid.add(at(mesh(new THREE.TorusGeometry(.38, .012, 6, 48), MAT.copper), 0, 0, 0, Math.PI / 2, 0, 0)); lid.add(at(cyl(.3, .3, .01, 48, MAT.solar), 0, .02, 0)); g.add(at(lid, 0, .3, -.3, -1.2, 0, 0));
      g.add(rod(V(.1, .14, .1), V(.3, .34, .25), .01, MAT.alu)); g.add(at(box(.08, .06, .08, MAT.white), .32, .36, .27));
      return g;
    },
    /* Spirit / Opportunity (MER): deck with solar wings, Pancam mast, high-gain dish, rocker-bogie, robotic arm */
    mer() {
      const g = new THREE.Group(); g.add(at(quilt(.5, .2, .4, MAT.kapton, MAT.seam, 3), 0, .28, 0)); g.add(at(box(.3, .12, .01, MAT.cream), 0, .28, .203)); g.add(at(flagPlate(.07, .045, [MAT.red, MAT.white, MAT.red, MAT.white, MAT.red]), .17, .3, .205)); g.add(at(box(.03, .022, .004, MAT.blue), .155, .31, .208)); g.add(at(cyl(.025, .025, .02, 14, MAT.yellow), -.18, .3, .205, Math.PI / 2, 0, 0)); g.add(at(box(.46, .02, .36, MAT.foilSilver), 0, .17, 0));
      g.add(at(box(.6, .014, .5, MAT.solar), 0, .4, 0));
      [-1, 1].forEach(s => { g.add(at(box(.3, .014, .42, MAT.solar), s * .46, .405, .02, 0, 0, s * .05)); g.add(at(box(.28, .014, .22, MAT.solar), s * .3, .406, -.36, .05, 0, 0)); g.add(at(box(.2, .014, .2, MAT.solar), s * .32, .405, .37)); });
      mast(g, V(.18, .41, .16), .44, .2);
      g.add(rod(V(-.14, .41, .12), V(-.14, .5, .12), .014, MAT.alu)); g.add(at(dishAnt(.1, .025), -.14, .52, .12, -.5, 0, 0));
      g.add(whip(V(-.2, .41, -.12), V(-.2, .7, -.12))); g.add(at(cyl(.02, .02, .08, 10, MAT.white), -.06, .45, -.14));
      rocker6(g, .7, .6, .22, .09);
      g.add(rod(V(0, .22, .22), V(.08, .16, .4), .015, MAT.alu)); g.add(rod(V(.08, .16, .4), V(.02, .1, .5), .012, MAT.alu));
      const idd = grp(box(.08, .08, .08, MAT.anod)); [[.06, 0, 0], [-.06, 0, 0], [0, .06, 0], [0, -.06, 0]].forEach(p => idd.add(at(cyl(.02, .02, .04, 10, MAT.alu), p[0], p[1], p[2]))); g.add(at(idd, .02, .1, .54));
      [-1, 1].forEach(s => g.add(at(cyl(.02, .02, .03, 10, MAT.glass), s * .12, .22, .21, Math.PI / 2, 0, 0)));
      return g;
    },
    /* Phoenix: decagonal deck, two round ten-sided solar arrays, SSI camera mast, MET mast, robotic arm with scoop, TEGA ovens */
    phoenix() {
      const g = new THREE.Group(); g.add(at(cyl(.38, .38, .14, 10, MAT.cream), 0, .4, 0)); for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2 + Math.PI / 10; g.add(at(box(.22, .1, .008, i % 3 ? MAT.foilSilver : MAT.kapton), Math.sin(a) * .365, .4, Math.cos(a) * .365, 0, a, 0)); } g.add(at(cyl(.39, .39, .02, 10, MAT.foilSilver), 0, .48, 0));
      [-1, 1].forEach(s => { const a = grp(cyl(.38, .38, .016, 10, MAT.solar)); a.add(at(mesh(new THREE.TorusGeometry(.37, .008, 5, 10), MAT.alu), 0, .01, 0, Math.PI / 2, 0, 0)); for (let k = 0; k < 10; k++) { const t = k / 10 * Math.PI * 2; a.add(at(box(.38, .02, .008, MAT.alu), Math.cos(t) * .19, .005, Math.sin(t) * .19, 0, -t, 0)); } a.add(at(cyl(.385, .385, .008, 10, MAT.white), 0, -.012, 0)); g.add(at(a, s * .82, .47, 0)); g.add(rod(V(s * .38, .46, 0), V(s * .45, .46, 0), .02, MAT.alu)); });
      for (let i = 0; i < 3; i++) leg(g, i / 3 * Math.PI * 2 + .3, .34, .34, .56, 0, .07);
      g.add(rod(V(-.1, .48, .2), V(-.1, .95, .2), .016, MAT.alu)); const ssi = grp(box(.12, .08, .08, MAT.white)); [-1, 1].forEach(s => ssi.add(at(cyl(.02, .02, .03, 12, MAT.glass), s * .035, 0, .05, Math.PI / 2, 0, 0))); g.add(at(ssi, -.1, .99, .2));
      g.add(rod(V(.15, .48, -.15), V(.15, .9, -.15), .008, MAT.alu)); g.add(at(box(.06, .05, .05, MAT.anod), .15, .92, -.15)); g.add(at(cyl(.01, .01, .1, 8, MAT.alu), .15, .97, -.15));
      g.add(rod(V(.2, .45, .25), V(.48, .62, .55), .018, MAT.alu)); g.add(rod(V(.48, .62, .55), V(.58, .1, .76), .015, MAT.alu)); g.add(at(box(.07, .05, .1, MAT.alu), .58, .07, .8));
      for (let k = 0; k < 4; k++) g.add(at(box(.06, .05, .06, k % 2 ? MAT.foil : MAT.anod), -.2 + k * .07, .52, -.18));
      g.add(at(cyl(.06, .06, .08, 16, MAT.white), .2, .52, .05));
      return g;
    },
    /* InSight: Phoenix-derived lander plus SEIS dome with wind and thermal shield, HP3 mole, robotic arm, cameras */
    insight() {
      const g = Models.phoenix();
      const seis = new THREE.Group(); seis.add(mesh(new THREE.SphereGeometry(.17, 28, 12, 0, Math.PI * 2, 0, Math.PI / 2), MAT.white)); seis.add(at(cyl(.21, .23, .03, 28, MAT.anod), 0, .01, 0));
      for (let k = 0; k < 10; k++) { const a = k / 10 * Math.PI * 2; seis.add(at(box(.045, .015, .1, k % 2 ? MAT.copper : MAT.kapton), Math.cos(a) * .2, .015, Math.sin(a) * .2, 0, -a, 0)); }
      g.add(at(seis, -.32, 0, .8));
      const hp3 = grp(quilt(.14, .1, .12, MAT.kapton, MAT.seam, 2)); hp3.add(at(box(.15, .02, .13, MAT.white), 0, .06, 0)); [-1, 1].forEach(s => hp3.add(rod(V(s * .06, -.05, .05), V(s * .07, -.06, .1), .006, MAT.alu))); g.add(at(hp3, .35, .06, .82));
      g.add(rod(V(-.32, .2, .8), V(-.2, .45, .6), .004, MAT.dark)); g.add(rod(V(.35, .1, .82), V(.25, .45, .55), .004, MAT.dark));
      g.add(at(cyl(.03, .03, .05, 12, MAT.glass), -.25, .5, .38, Math.PI / 2, 0, 0)); g.add(at(box(.08, .05, .03, MAT.dark), .25, .5, .38));
      return g;
    },
    /* Ingenuity: fuselage box, landing legs, mast with coaxial counter-rotating rotors, solar panel on top */
    ingenuity() {
      const g = new THREE.Group(); const fus = grp(quilt(.2, .17, .18, MAT.kapton, MAT.seam, 2)); fus.add(at(box(.21, .02, .19, MAT.white), 0, .09, 0)); fus.add(at(cyl(.02, .02, .02, 12, MAT.glass), 0, -.09, .05)); fus.add(at(cyl(.015, .015, .02, 12, MAT.glass), .06, -.04, .09, Math.PI / 2, 0, 0)); g.add(at(fus, 0, .32, 0));
      for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4; g.add(rod(V(Math.cos(a) * .08, .26, Math.sin(a) * .08), V(Math.cos(a) * .34, 0, Math.sin(a) * .34), .008, MAT.alu)); g.add(at(cyl(.025, .025, .012, 10, MAT.alu), Math.cos(a) * .34, .005, Math.sin(a) * .34)); }
      g.add(at(cyl(.025, .025, .44, 12, MAT.anod), 0, .62, 0)); g.add(at(cyl(.06, .06, .08, 16, MAT.dark), 0, .48, 0));
      const rotors = [];
      [.56, .7].forEach((y, k) => { const r = new THREE.Group(); [1, -1].forEach(s => { const blade = grp(box(.6, .008, .08, MAT.carbon)); blade.add(at(box(.6, .009, .02, MAT.cream), 0, 0, .03)); blade.add(at(box(.06, .01, .081, MAT.yellow), .27, 0, 0)); r.add(at(blade, s * .32, 0, 0, s * .08, 0, 0)); }); r.add(at(cyl(.045, .045, .04, 14, MAT.anod), 0, 0, 0)); r.position.y = y; r.rotation.y = k * .8; g.add(r); rotors.push(r); });
      const sp = grp(box(.36, .012, .2, MAT.solar)); sp.add(at(box(.37, .006, .21, MAT.alu), 0, -.008, 0)); g.add(at(sp, 0, .86, 0));
      g.userData.rotors = rotors; return g;
    }
  };
  // GÖREV 3.2 - Geometri/materyal paylaşımı: her uydunun yüzlerce parçası, malzeme başına tek bir BufferGeometry'de birleştirilir
  // (dönen pervaneler hariç). 27 araç ~270 çizim çağrısına iner; poligon detayı hiç azalmaz. Malzemeler tüm araçlarda ortaktır.
  /* Bake each model into one mesh per material (rotating parts stay separate) to keep draw calls low. */
  function mergeStatic(root) {
    if (!THREE.BufferGeometry || !THREE.BufferAttribute) return root;
    try {
      root.updateMatrixWorld(true);
      const keep = new Set((root.userData.rotors || []));
      const buckets = new Map();
      root.traverse(o => {
        if (!o.isMesh) return; let p = o.parent; while (p && p !== root) { if (keep.has(p)) return; p = p.parent; }
        const g = (o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone()); g.applyMatrix4(o.matrixWorld);
        if (!buckets.has(o.material)) buckets.set(o.material, []); buckets.get(o.material).push(g);
      });
      const out = new THREE.Group(); out.userData = root.userData;
      buckets.forEach((gs, m) => {
        let n = 0; gs.forEach(g => n += g.attributes.position.count);
        const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3), uv = new Float32Array(n * 2); let o3 = 0, o2 = 0;
        gs.forEach(g => { const c = g.attributes.position.count; pos.set(g.attributes.position.array, o3); if (g.attributes.normal) nor.set(g.attributes.normal.array, o3); if (g.attributes.uv) uv.set(g.attributes.uv.array, o2); o3 += c * 3; o2 += c * 2; g.dispose(); });
        const bg = new THREE.BufferGeometry(); bg.setAttribute('position', new THREE.BufferAttribute(pos, 3)); bg.setAttribute('normal', new THREE.BufferAttribute(nor, 3)); bg.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
        out.add(new THREE.Mesh(bg, m));
      });
      keep.forEach(r => out.add(r));
      return out;
    } catch (e) { return root; }
  }
  function normalizeModel(obj, size = 1) {
    const b = new THREE.Box3().setFromObject(obj), sz = b.getSize(V(0, 0, 0)), c = b.getCenter(V(0, 0, 0));
    const k = size / Math.max(sz.x, sz.y, sz.z, 1e-6);
    obj.scale.multiplyScalar(k); obj.position.sub(c.multiplyScalar(k));
    obj.position.y += sz.y * k / 2; // rest on the ground plane
    const w = new THREE.Group(); w.add(obj); w.userData = obj.userData; return w;
  }
  const buildModel = (kind, variant) => normalizeModel(mergeStatic((Models[kind] || Models.luna2)(variant)), 1);


  /* =================================================================
     NASA 3D MODELS - official models from NASA 3D Resources (github.com/nasa/NASA-3D-Resources),
     pre-converted offline (Draco/webp decoded) into a compact quantised format in models/*.bin.
     (TR) NASA'nın resmi 3D modelleri: site önce kendi modelleriyle açılır, NASA modelleri arka planda
     sırayla yüklenip yerlerini alır; malzemeler yine bizim shader'ımızla çizilir (siyah görünmez).
     ================================================================= */
  const NasaModels = (() => {
    const MAP = { apollo11: ['lm', 'a11'], apollo17: ['lm', 'a17'], viking1: ['viking'], viking2: ['viking'], spirit: ['mer'], opportunity: ['mer'], insight: ['insight'], ingenuity: ['ingenuity'], mgs: ['mgs'] };
    const cache = {};
    async function parse(key) {
      if (cache[key]) return cache[key];
      const buf = await (await fetch('models/' + key + '.mdl.png')).arrayBuffer(), dv = new DataView(buf);
      if (dv.getUint32(0, true) !== 0x4d424241) throw new Error('bad model ' + key);
      const hl = dv.getUint32(4, true), H = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 8, hl))), base = 8 + hl;
      const tl = new THREE.TextureLoader();
      const mats = H.mats.map(m => { let map = null; if (m.tex !== null && m.tex !== undefined) { map = tl.load('models/' + key + '_' + m.tex + '.jpg'); map.flipY = false; map.wrapS = map.wrapT = THREE.RepeatWrapping; }
        const c = new THREE.Color(m.c[0], m.c[1], m.c[2]); return CRAFT_SM(c.getHex(), m.foil ? 1 : 0, m.spec, 26, false, map); });
      const parts = H.parts.map(pt => {
        const q = new Uint16Array(buf, base + pt.p, pt.v * 3), nn = new Int8Array(buf, base + pt.n, pt.v * 4), pos = new Float32Array(pt.v * 3), nor = new Float32Array(pt.v * 3);
        for (let i = 0; i < pt.v; i++) { for (let k = 0; k < 3; k++) { pos[i * 3 + k] = H.min[k] + q[i * 3 + k] / 65535 * H.scale; nor[i * 3 + k] = nn[i * 4 + k] / 127; } }
        const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
        g.setAttribute('uv', new THREE.BufferAttribute(pt.uv ? new Float32Array(buf.slice(base + pt.u, base + pt.u + pt.v * 8)) : new Float32Array(pt.v * 2), 2));
        g.setIndex(new THREE.BufferAttribute(pt.x32 ? new Uint32Array(buf, base + pt.x, pt.i) : new Uint16Array(buf, base + pt.x, pt.i), 1));
        g.computeBoundingBox(); g.computeBoundingSphere();
        return { g, m: mats[pt.m], rotor: pt.rotor };
      });
      return (cache[key] = { parts, src: H.src });
    }
    function instance(data) {
      const root = new THREE.Group(), rot = {};
      data.parts.forEach(p => {
        const m = new THREE.Mesh(p.g, p.m);
        if (p.rotor >= 0) { if (!rot[p.rotor]) { const c = p.g.boundingBox.getCenter(new THREE.Vector3()); const pv = new THREE.Group(); pv.position.set(c.x, 0, c.z); pv.userData.off = c; rot[p.rotor] = pv; root.add(pv); } const pv = rot[p.rotor]; m.position.set(-pv.userData.off.x, 0, -pv.userData.off.z); pv.add(m); }
        else root.add(m);
      });
      const rotors = Object.keys(rot).map(k => rot[k]); if (rotors.length) root.userData.rotors = rotors;
      return root;
    }
    /* Apollo: NASA descent stage scaled to the procedural LM footprint, plus each crew's surface hardware */
    function build(id) {
      const [key, variant] = MAP[id], data = cache[key]; let obj = instance(data);
      if (key === 'lm') {
        const g = new THREE.Group(), b = new THREE.Box3().setFromObject(obj), sz = b.getSize(new THREE.Vector3()), k = 2.3 / Math.max(sz.x, sz.z);
        obj.scale.setScalar(k); obj.position.set(-(b.min.x + b.max.x) / 2 * k, -b.min.y * k, -(b.min.z + b.max.z) / 2 * k); g.add(obj);
        g.add(mergeStatic(Models.lmExtras(new THREE.Group(), variant))); obj = g;
      }
      return normalizeModel(obj, 1);
    }
    async function loadAll() {
      for (const id of Object.keys(MAP)) {
        try {
          await parse(MAP[id][0]); const r = Engine.crafts[id]; if (!r) continue;
          const w = build(id); r.holder.remove(r.model); r.model = w; r.holder.add(w); r.fromFile = true; r.makeModel = () => build(id); r.modelSrc = cache[MAP[id][0]].src;
          if (Store.get().activeSpacecraftId === id) Inspector.show(id);
        } catch (e) { console.warn('NASA model not loaded for', id, e); }
        await new Promise(res => setTimeout(res, 30));
      }
    }
    return { loadAll, has: id => !!MAP[id] };
  })();

  /* =================================================================
     PHASE 3 - ENGINE
     ================================================================= */
  const Engine = (() => {
    let __perfHook = null;
    let renderer, scene, camera, clock, raycaster, sunDir, stars, sky, sunSprite, keyLight;
    let tmp, tmp2, projV, elapsed = 0, orbitTime = 0, ready = false;
    const bodies = {}, crafts = {}, markers = [];
    const cam = { target: null, radius: 6, theta: .6, phi: 1.2, anim: null, follow: null, minR: 1.1, maxR: 30, body: 'MOON', upFrom: null };
    const SUN_DEFAULT = [1, .32, .55];
    const THEME = { MOON: [[.10, .17, .30], [.55, .62, .70]], MARS: [[.30, .10, .05], [1.0, .62, .45]] };
    let skyTint = null, skyTarget = null;

    const bodyCenter = k => bodies[k].center;

    function initRenderer() {
      tmp = V(0, 0, 0); tmp2 = V(0, 0, 0); projV = V(0, 0, 0); cam.target = V(0, 0, 0);
      renderer = new THREE.WebGLRenderer({ canvas: $('#stage'), antialias: true, powerPreference: 'high-performance' });
      renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2)); renderer.setSize(innerWidth, innerHeight, false);
      renderer.outputEncoding = THREE.sRGBEncoding; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
      scene = new THREE.Scene(); camera = new THREE.PerspectiveCamera(42, innerWidth / innerHeight, .002, 9000);
      clock = new THREE.Clock(); raycaster = new THREE.Raycaster();
      sunDir = V(...SUN_DEFAULT).normalize();
      keyLight = new THREE.DirectionalLight(0xfff4e6, 2.6); keyLight.position.copy(sunDir).multiplyScalar(100); scene.add(keyLight); scene.add(keyLight.target);
      scene.add(new THREE.AmbientLight(0x2a3a4e, .35));
      scene.add(new THREE.HemisphereLight(0xcfe0ff, 0x5a4636, .75));
      const head = new THREE.PointLight(0xfff6ea, 1.25, 0, 0); camera.add(head); scene.add(camera);
      skyTint = new THREE.Vector3(...THEME.MOON[0]); skyTarget = skyTint.clone();
      let rzT = 0; addEventListener('resize', () => { cancelAnimationFrame(rzT); rzT = requestAnimationFrame(() => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight, false); }); });
      /* (TR) adaptif çözünürlük: yavaş cihazlarda kare hızı düşerse piksel oranı kademeli azaltılır, toparlanınca geri alınır */
      const PR_MAX = Math.min(devicePixelRatio || 1, 2); let prCur = PR_MAX, fAcc = 0, fN = 0;
      __perfHook = dt => { fAcc += dt; fN++; if (fAcc < 2) return; const fps = fN / fAcc; fAcc = 0; fN = 0;
        let nx = prCur; if (fps < 45 && prCur > 1) nx = Math.max(1, prCur - .25); else if (fps > 58 && prCur < PR_MAX) nx = Math.min(PR_MAX, prCur + .25);
        if (nx !== prCur) { prCur = nx; renderer.setPixelRatio(nx); renderer.setSize(innerWidth, innerHeight, false); } };
    }
    function buildSky() {
      sky = mesh(new THREE.SphereGeometry(4000, 48, 24), new THREE.ShaderMaterial({ vertexShader: SKY_VS, fragmentShader: SKY_FS, side: THREE.BackSide, depthWrite: false, uniforms: { uTint: { value: skyTint }, uGlow: { value: V(-.4, .1, -.9).normalize() } } }));
      sky.renderOrder = -3; scene.add(sky);
      const N = 6000, pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
      for (let i = 0; i < N; i++) {
        const v = V(Math.random() * 2 - 1, Math.random() * 2 - 1, Math.random() * 2 - 1).normalize().multiplyScalar(3500);
        pos.set([v.x, v.y, v.z], i * 3); const tn = Math.random(), b = .3 + Math.random() ** 3 * .95;
        col.set(tn < .15 ? [b, b * .85, b * .7] : tn < .3 ? [b * .8, b * .9, b] : [b, b, b], i * 3);
      }
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(col, 3));
      stars = new THREE.Points(g, new THREE.PointsMaterial({ size: 1.6, sizeAttenuation: false, vertexColors: true, depthWrite: false, toneMapped: false }));
      stars.renderOrder = -2; scene.add(stars);
      sunSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX.glow, color: 0xfff1d6, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
      sunSprite.scale.setScalar(220); scene.add(sunSprite);
    }
    function buildBodies() {
      for (const [key, B] of Object.entries(BODIES)) {
        const group = new THREE.Group(); group.position.set(...B.pos); scene.add(group);
        const mat = new THREE.ShaderMaterial({ vertexShader: PLANET_VS, fragmentShader: PLANET_FS, uniforms: { uType: { value: B.type }, uSun: { value: sunDir }, uTime: { value: 0 }, uAtmo: { value: V(...B.atmo) }, uRot: { value: new THREE.Matrix3() }, uMoonCol: { value: null }, uMoonH: { value: null }, uMoonOn: { value: 0 }, uMarsCol: { value: null }, uMarsN: { value: null }, uMarsOn: { value: 0 } }, extensions: { derivatives: true } });
        if (B.type === 2) { /* (TR) NASA Mars küresel renk mozaiği + kabartma (normal) haritası; yüklenene kadar mevcut Mars görünür */
          const tl = new THREE.TextureLoader(), an = Math.min(8, renderer.capabilities.getMaxAnisotropy()); let n = 0;
          const done = () => { if (++n === 2) mat.uniforms.uMarsOn.value = 1; };
          mat.uniforms.uMarsCol.value = tl.load('textures/mars_color_4k.jpg', t => { t.anisotropy = an; t.wrapS = THREE.RepeatWrapping; t.needsUpdate = true; done(); });
          mat.uniforms.uMarsN.value = tl.load('textures/mars_normal_2k.jpg', t => { t.wrapS = THREE.RepeatWrapping; t.needsUpdate = true; done(); });
        }
        if (B.type === 1) { /* (TR) NASA SVS CGI Moon Kit dokuları (LRO/LROC renk + LOLA yükseklik); yüklenene kadar mevcut Ay görünür */
          const tl = new THREE.TextureLoader(), an = Math.min(8, renderer.capabilities.getMaxAnisotropy()); let n = 0;
          const done = () => { if (++n === 2) mat.uniforms.uMoonOn.value = 1; };
          mat.uniforms.uMoonCol.value = tl.load('textures/moon_lroc_color_4k.jpg', t => { t.anisotropy = an; t.wrapS = THREE.RepeatWrapping; t.needsUpdate = true; done(); });
          mat.uniforms.uMoonH.value = tl.load('textures/moon_lola_height_1k.jpg', t => { t.wrapS = THREE.RepeatWrapping; t.needsUpdate = true; done(); });
        }
        const sg = B.type === 2 ? new THREE.SphereGeometry(1, 288, 192) : new THREE.SphereGeometry(1, 192, 128);
        { const P = sg.attributes.position, rel = new Float32Array(P.count), d = new THREE.Vector3();
          for (let i = 0; i < P.count; i++) { d.fromBufferAttribute(P, i).normalize(); if (B.type === 2) { rel[i] = Relief.mars([d.x, d.y, d.z]); d.multiplyScalar(1 + MARS_DISP * rel[i]); P.setXYZ(i, d.x, d.y, d.z); } }
          sg.setAttribute('aRel', new THREE.BufferAttribute(rel, 1)); sg.computeBoundingSphere(); }
        const m = mesh(sg, mat); m.rotation.z = B.tilt; group.add(m);
        let atmo = null;
        if (B.type === 2) {
          atmo = mesh(new THREE.SphereGeometry(1.026, 128, 80), new THREE.ShaderMaterial({ vertexShader: ATMO_VS, fragmentShader: ATMO_FS, side: THREE.BackSide, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, uniforms: { uColor: { value: V(1.0, .46, .24) }, uSun: { value: sunDir }, uStrength: { value: 1.0 } } }));
          group.add(atmo);
        }
        bodies[key] = { key, B, group, mesh: m, mat, atmo, center: group.position.clone(), spin: true };
        m.updateMatrixWorld(); mat.uniforms.uRot.value.setFromMatrix4(m.matrixWorld);
      }
    }
    const latLonVec = (la, lo, r = 1) => { const a = THREE.MathUtils.degToRad(la), o = THREE.MathUtils.degToRad(lo); return V(Math.cos(a) * Math.cos(o) * r, Math.sin(a) * r, -Math.cos(a) * Math.sin(o) * r); };
    function keplerE(M, e) { let E = M; for (let i = 0; i < 10; i++) E -= (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E)); return E; }
    function makeOrbit(o, B) {
      const rp = 1 + o.rp / B.radiusKm, ra = 1 + o.ra / B.radiusKm, a = (rp + ra) / 2, e = (ra - rp) / (ra + rp), d = THREE.MathUtils.degToRad;
      const mtx = new THREE.Matrix4().makeRotationY(d(o.raan)).multiply(new THREE.Matrix4().makeRotationX(d(o.inc))).multiply(new THREE.Matrix4().makeRotationY(d(o.argp)));
      const periodMin = 2 * Math.PI * Math.sqrt((a * B.radiusKm) ** 3 / B.gm) / 60;
      return { a, e, mtx, displaySec: clamp(periodMin * .3, 30, 240), M0: o.M0 || 0, normal: V(0, 1, 0).applyMatrix4(new THREE.Matrix4().extractRotation(mtx)).normalize() };
    }
    function orbitPos(o, ts, out) { const M = o.M0 + 2 * Math.PI * ts / o.displaySec, E = keplerE(M % (2 * Math.PI), o.e); out.set(o.a * (Math.cos(E) - o.e), 0, -o.a * Math.sqrt(1 - o.e * o.e) * Math.sin(E)); return out.applyMatrix4(o.mtx); }

    function buildCrafts() {
      for (const c of CRAFT) {
        const body = bodies[c.body], holder = new THREE.Group();
        const model = buildModel(c.model, c.variant); holder.add(model);
        const rec = { c, holder, model, body, worldPos: V(0, 0, 0), local: V(0, 0, 0), override: false, hidden: false };
        if (c.lat != null) {
          rec.normal = latLonVec(c.lat, c.lon).normalize(); rec.surf = Relief.surface(c.body, rec.normal);
          holder.scale.setScalar(.024);
          body.mesh.add(holder);
          holder.position.copy(rec.normal).multiplyScalar(rec.surf + .0006);
          holder.quaternion.setFromUnitVectors(Y, rec.normal);
          if (c.status === 'impact' || c.status === 'lost') {
            const cr = mesh(new THREE.RingGeometry(.02, .027, 48), new THREE.MeshBasicMaterial({ color: c.status === 'lost' ? 0xff6a55 : 0xffd27a, transparent: true, opacity: .85, side: THREE.DoubleSide, depthWrite: false, toneMapped: false }));
            cr.position.copy(rec.normal).multiplyScalar(rec.surf + .0025); cr.quaternion.setFromUnitVectors(V(0, 0, 1), rec.normal); body.mesh.add(cr); rec.crater = cr;
          }
        } else if (c.orbit) {
          rec.orbit = makeOrbit(c.orbit, body.B);
          const pts = []; const o = rec.orbit;
          for (let i = 0; i <= 360; i++) { const E = i / 360 * Math.PI * 2; pts.push(V(o.a * (Math.cos(E) - o.e), 0, -o.a * Math.sqrt(1 - o.e * o.e) * Math.sin(E)).applyMatrix4(o.mtx)); }
          rec.line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0xff9461, transparent: true, opacity: .32 }));
          body.group.add(rec.line); holder.scale.setScalar(.05); body.group.add(holder);
        } else if (c.approach) {
          const rp = 1 + c.approach.peri / body.B.radiusKm, e = 1.35, p = rp * (1 + e), rMax = 7;
          const nuMax = Math.acos(clamp((p / rMax - 1) / e, -1, 1));
          const rot = new THREE.Matrix4().makeRotationY(2.3).multiply(new THREE.Matrix4().makeRotationX(.45));
          const pts = []; for (let i = 0; i <= 160; i++) { const nu = -nuMax + i / 160 * nuMax * 1.08; const r = p / (1 + e * Math.cos(nu)); pts.push(V(r * Math.cos(nu), 0, r * Math.sin(nu)).applyMatrix4(rot)); }
          rec.path = pts;
          rec.line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineDashedMaterial({ color: 0xff6a55, transparent: true, opacity: .7, dashSize: .08, gapSize: .06 }));
          rec.line.computeLineDistances(); body.group.add(rec.line);
          holder.position.copy(pts[132]); rec.local.copy(holder.position); holder.scale.setScalar(.05); body.group.add(holder);
        }
        // GÖREV 2.4 - Kamera minimum mesafesi: modelin sınır küresi (bounding sphere) bir kez hesaplanır,
        // kamera bu kürenin 2.6 katından fazla yaklaşamaz; böylece kamera hiçbir zaman uydunun içine girmez.
        { const bb = new THREE.Box3().setFromObject(model), sz = bb.getSize(V(0, 0, 0)); rec.boundR = .5 * sz.length() * holder.scale.x; if (!isFinite(rec.boundR) || rec.boundR <= 0) rec.boundR = .02; }
        const marker = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX.ring, color: 0x7fd6ff, transparent: true, depthWrite: false, sizeAttenuation: false, toneMapped: false }));
        marker.scale.setScalar(.026); marker.userData.craftId = c.id; marker.renderOrder = 5; scene.add(marker); markers.push(marker); rec.marker = marker;
        crafts[c.id] = rec;
      }
    }

    /* ---------- labels ---------- */
    const labelEls = {};
    function buildLabels() {
      const layer = $('#labels');
      for (const c of CRAFT) {
        const b = document.createElement('button'); b.className = 'lbl' + (c.status === 'lost' ? ' lost' : ''); b.innerHTML = `<i></i><span class="code">${c.code}</span><span class="nm"></span>`;
        b.addEventListener('click', e => { e.stopPropagation(); UI.selectCraft(c.id); });
        layer.appendChild(b); labelEls[c.id] = b;
      }
      refreshLabels();
    }
    function refreshLabels() { for (const c of CRAFT) labelEls[c.id].querySelector('.nm').textContent = craftName(c); }
    function occluded(p, center, R) {
      tmp.subVectors(p, camera.position); const Ld = tmp.length(); tmp.divideScalar(Ld);
      tmp2.subVectors(camera.position, center); const b = tmp2.dot(tmp), cc = tmp2.lengthSq() - R * R, disc = b * b - cc;
      if (disc <= 0) return false; const t0 = -b - Math.sqrt(disc); return t0 > 0 && t0 < Ld - .002;
    }
    function project(p) { projV.copy(p).project(camera); return { x: (projV.x * .5 + .5) * innerWidth, y: (-projV.y * .5 + .5) * innerHeight, ok: projV.z < 1 && projV.z > -1 }; }
    function updateLabels() {
      if (!labelEls[CRAFT[0].id]) return;
      const S = Store.get(), hide = !S.booted || (cam.anim && cam.anim.arc > 5);
      for (const c of CRAFT) {
        const r = crafts[c.id], el = labelEls[c.id];
        let show = !hide && c.body === cam.body && S.timelineYear >= c.arriveYear && !r.override;
        if (show) { const pr = project(r.worldPos); show = pr.ok && !occluded(r.worldPos, r.body.center, .995); if (show) el.style.transform = `translate(${pr.x + 12}px,${pr.y - 11}px)`; }
        if (!show) el.style.transform = 'translate(-9999px,0)';
        el.classList.toggle('sel', S.activeSpacecraftId === c.id);
      }
    }

    /* ---------- camera rig ---------- */
    function placeCamera() {
      const sp = Math.sin(cam.phi);
      camera.position.set(cam.target.x + cam.radius * sp * Math.sin(cam.theta), cam.target.y + cam.radius * Math.cos(cam.phi), cam.target.z + cam.radius * sp * Math.cos(cam.theta));
      const bc = bodyCenter(cam.body); tmp.subVectors(camera.position, bc); const d = tmp.length();
      const floorR = cam.body === 'MARS' ? 1.02 : 1.012; if (d < floorR) camera.position.copy(bc).addScaledVector(tmp.normalize(), floorR);
      camera.lookAt(cam.target);
      // GÖREV 2.1 - Dinamik near düzlemi: near, kameranın hedefe ve yüzeye uzaklığına göre her karede ayarlanır (0.0008 - 0.5).
      // Derinlik hassasiyeti her yakınlıkta en iyi seviyede kalır; z-fighting ve titreme oluşmaz.
      /* depth precision: keep the near plane as far out as the scene allows (prevents z-fighting / flicker on small craft) */
      const nr = clamp(Math.min(cam.radius * .05, (Math.max(d, floorR) - 1.014) * .5), .0008, .5);
      if (Math.abs(nr - camera.near) > camera.near * .08) { camera.near = nr; camera.updateProjectionMatrix(); }
    }
    const anglesFromDir = d => ({ theta: Math.atan2(d.x, d.z), phi: Math.acos(clamp(d.y, -.999, .999)) });
    function flyTo({ target, follow = null, radius, theta, phi, duration = 1.8, arc = 0, body, minR, maxR }) {
      let th = theta ?? cam.theta; const dth = ((th - cam.theta + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI; th = cam.theta + dth;
      cam.anim = { t: 0, duration, from: { target: cam.target.clone(), radius: cam.radius, theta: cam.theta, phi: cam.phi }, to: { target: target ? target.clone() : null, radius, theta: th, phi: phi ?? cam.phi }, follow, arc };
      cam.follow = null; if (body) cam.body = body; if (minR != null) cam.minR = minR; if (maxR != null) cam.maxR = maxR;
    }
    function updateCamera(dt) {
      if (cam.anim) {
        const A = cam.anim; A.t += dt / A.duration; const e = easeIO(clamp(A.t, 0, 1));
        const tgt = A.follow ? A.follow() : A.to.target;
        cam.target.lerpVectors(A.from.target, tgt, e);
        cam.radius = lerp(A.from.radius, A.to.radius, e) + Math.sin(Math.PI * e) * A.arc;
        cam.theta = lerp(A.from.theta, A.to.theta, e); cam.phi = lerp(A.from.phi, A.to.phi, e);
        if (cam.upFrom) { camera.up.copy(cam.upFrom).lerp(Y, e).normalize(); }
        if (A.t >= 1) { cam.follow = A.follow; cam.anim = null; if (cam.upFrom) { camera.up.copy(Y); cam.upFrom = null; } }
      } else if (cam.follow) cam.target.copy(cam.follow());
      placeCamera();
    }
    function focusBody(key, opts = {}) {
      const B = BODIES[key], far = cam.body !== key;
      flyTo({ target: bodyCenter(key), radius: B.view, duration: far ? 2.8 : 1.4, arc: far ? 320 : 0, body: key, minR: B.min, maxR: B.max, phi: 1.15, theta: key === 'MARS' ? -.5 : .55, ...opts });
    }
    function focusCraft(id) {
      const r = crafts[id]; if (!r) return;
      const c = r.c, far = cam.body !== c.body; let theta, phi, radius;
      if (c.lat != null) { tmp2.copy(r.normal).applyQuaternion(r.body.mesh.quaternion); const a = anglesFromDir(tmp2.clone().multiplyScalar(1.0).addScaledVector(sunDir, .7).normalize()); theta = a.theta; phi = a.phi; radius = .3; }
      else { tmp2.copy(r.local).normalize(); const a = anglesFromDir(tmp2); theta = a.theta + .5; phi = clamp(a.phi - .25, .2, 2.9); radius = .5; }
      flyTo({ follow: () => r.worldPos, radius: Math.max(radius, (r.boundR || .02) * 3.2), theta, phi, duration: far ? 2.9 : 1.8, arc: far ? 320 : .6, body: c.body, minR: Math.max(.03, (r.boundR || .02) * 2.6), maxR: BODIES[c.body].max });
    }
    function lookAtEvent(dirLocal, body, radius, target) {
      const a = anglesFromDir(dirLocal.clone().normalize());
      flyTo({ target: target || bodyCenter(body), radius, theta: a.theta + .7, phi: clamp(a.phi - .2, .25, 2.9), duration: 1.4, body, minR: .05, maxR: BODIES[body].max });
    }

    /* ---------- per-frame ---------- */
    function updateBodies(dt) {
      for (const b of Object.values(bodies)) {
        if (b.spin && !LD.active) b.mesh.rotation.y += b.B.spin * dt;
        b.mat.uniforms.uTime.value = elapsed; b.mesh.updateMatrixWorld(); b.mat.uniforms.uRot.value.setFromMatrix4(b.mesh.matrixWorld);
      }
    }
    function updateCrafts(dt) {
      const S = Store.get(), y = S.timelineYear, sel = S.activeSpacecraftId, booted = S.booted;
      for (const r of Object.values(crafts)) {
        const c = r.c, vis = booted && y >= c.arriveYear;
        if (!r.override) {
          if (r.orbit) { orbitPos(r.orbit, orbitTime, r.local); r.holder.position.copy(r.local); r.holder.lookAt(r.body.center); }
          else if (c.lat != null) { r.holder.position.copy(r.normal).multiplyScalar(r.surf + .0006); r.holder.quaternion.setFromUnitVectors(Y, r.normal); }
        }
        r.holder.visible = vis && !r.hidden;
        if (r.line) r.line.visible = vis;
        if (r.crater) r.crater.visible = booted && y >= c.endYear;
        r.holder.getWorldPosition(r.worldPos);
        r.marker.position.copy(r.worldPos); r.marker.visible = vis && !r.override;
        const isSel = sel === c.id;
        r.marker.material.color.setHex(isSel ? 0xffd27a : (c.status === 'lost' ? 0xff6a55 : (c.body === 'MARS' ? 0xff9461 : 0x7fd6ff)));
        r.marker.scale.setScalar(isSel ? .036 : .024);
        if (r.line && r.line.material.opacity != null && !c.approach) r.line.material.opacity = isSel ? .85 : .3;
        if (r.model.userData.rotors && r.spinRotors) r.model.userData.rotors.forEach((ro, i) => ro.rotation.y += dt * (i ? -40 : 40));
      }
    }

    /* ---------- 3D LOADER (LCROSS Centaur impact) ---------- */
    const LD = { active: false };
    const GM = 4902.8, RM = 1737.4, VINF2 = 2.5 * 2.5 - 2 * GM / RM, R0 = 3.4;
    const vAt = altKm => Math.sqrt(VINF2 + 2 * GM / (RM + altKm));
    const TTI = (() => { const A0 = (R0 - 1) * RM, N = 400, a = new Float64Array(N + 1); for (let i = 1; i <= N; i++) { const a0 = (i - 1) / N * A0, a1 = i / N * A0; a[i] = a[i - 1] + (a1 - a0) / vAt((a0 + a1) / 2); } return { A0, N, a }; })();
    const ttiAt = alt => { const f = clamp(alt / TTI.A0, 0, 1) * TTI.N, i = Math.floor(f), j = Math.min(TTI.N, i + 1); return lerp(TTI.a[i], TTI.a[j], f - i); };
    function setupLoader() {
      const M = bodies.MOON; M.mesh.updateMatrixWorld();
      const n = latLonVec(-84.68, -48.70).applyQuaternion(M.mesh.quaternion).normalize();
      const b = V(0, 0, 0).crossVectors(n, V(1, 0, 0)).normalize();
      const sDir = n.clone().applyAxisAngle(b, .95), tdir = sDir.clone().sub(n.clone().multiplyScalar(n.dot(sDir))).normalize();
      const C = M.center.clone(), q = new THREE.Quaternion().setFromUnitVectors(sDir, n), qi = new THREE.Quaternion();
      const path = []; for (let i = 0; i <= 240; i++) { const s = i / 240; path.push(sDir.clone().applyQuaternion(qi.clone().slerp(q, s)).multiplyScalar(lerp(R0, 1.0, Math.pow(s, 1.3))).add(C)); }
      const craft = buildModel('centaur'); craft.scale.setScalar(.09); scene.add(craft);
      const pos = new Float32Array(path.length * 3); path.forEach((p, i) => pos.set([p.x, p.y, p.z], i * 3));
      const tg = new THREE.BufferGeometry(); tg.setAttribute('position', new THREE.BufferAttribute(pos, 3)); tg.setDrawRange(0, 0);
      const trail = new THREE.Line(tg, new THREE.LineBasicMaterial({ color: 0x7fd6ff, transparent: true, opacity: .85, blending: THREE.AdditiveBlending, toneMapped: false }));
      const pred = new THREE.Line(new THREE.BufferGeometry().setFromPoints(path), new THREE.LineDashedMaterial({ color: 0xffffff, transparent: true, opacity: .22, dashSize: .05, gapSize: .05 }));
      pred.computeLineDistances(); scene.add(trail, pred);
      const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX.glow, color: 0x9fe6ff, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, transparent: true })); glow.scale.setScalar(.22); scene.add(glow);
      const camPos = C.clone().addScaledVector(b, 2.75).addScaledVector(n, 1.28).addScaledVector(tdir, .95);
      const look = C.clone().addScaledVector(n, 1.16).addScaledVector(tdir, .62);
      Object.assign(LD, { active: true, n, b, tdir, C, path, craft, trail, pred, glow, camPos, look, p: 0, impacted: false, t0: 0, fx: [], shake: 0, done: false });
      sunDir.copy(tdir).multiplyScalar(.75).addScaledVector(b, .45).addScaledVector(n, .55).normalize(); keyLight.position.copy(sunDir).multiplyScalar(100);
      camera.up.copy(n); camera.position.copy(camPos); camera.lookAt(look);
    }
    function samplePath(path, u, out) { const f = clamp(u, 0, 1) * (path.length - 1), i = Math.floor(f), j = Math.min(path.length - 1, i + 1); return out.lerpVectors(path[i], path[j], f - i); }
    function updateLoader(dt) {
      if (!LD.active) return;
      const p = Loader.shown() / 100, u = .18 * p + .82 * Math.pow(p, 2.4); // (TR) yerçekimiyle ivmelenen yaklaşma
      if (!LD.impacted) {
        const pos = samplePath(LD.path, u, V(0, 0, 0)), ahead = samplePath(LD.path, Math.min(1, u + .01), V(0, 0, 0));
        LD.craft.position.copy(pos); LD.glow.position.copy(pos); LD.glow.scale.setScalar(.16 + u * .3); LD.glow.material.opacity = .55 + u * .45;
        if (LD.trail.material) LD.trail.material.opacity = .35 + u * .65;
        if (!LD.shadow) { const sh = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX.glow, color: 0x000000, transparent: true, depthWrite: false, opacity: 0 })); sh.position.copy(LD.path[LD.path.length - 1]).addScaledVector(LD.n, .002); scene.add(sh); LD.shadow = sh; }
        LD.shadow.material.opacity = Math.min(.85, u * u * .9); LD.shadow.scale.setScalar(.02 + (1 - u) * .12);
        const dir = ahead.sub(pos); if (dir.lengthSq() > 1e-9) LD.craft.quaternion.setFromUnitVectors(Y, dir.normalize());
        LD.trail.geometry.setDrawRange(0, Math.max(1, Math.floor(u * (LD.path.length - 1)) + 1));
        const altKm = Math.max(0, (pos.distanceTo(LD.C) - 1) * RM);
        Loader.tele(altKm, vAt(altKm), ttiAt(altKm));
        const pr = project(LD.path[LD.path.length - 1]); Loader.reticle(pr.x, pr.y, pr.ok);
      }
      // gentle cinematic drift
      const k = elapsed * .05;
      camera.position.copy(LD.camPos).applyAxisAngle(LD.n, Math.sin(k) * .05).addScaledVector(LD.tdir, -Math.min(.25, p * .25));
      if (LD.shake > 0) { LD.shake = Math.max(0, LD.shake - dt * 1.4); camera.position.add(V((Math.random() - .5) * LD.shake * .06, (Math.random() - .5) * LD.shake * .06, (Math.random() - .5) * LD.shake * .06)); }
      camera.lookAt(LD.look);
      for (const f of LD.fx) f(elapsed - LD.t0, dt);
    }
    function loaderImpact() {
      if (LD.impacted) return;
      LD.impacted = true; LD.t0 = elapsed; LD.shake = 1;
      const P = LD.path[LD.path.length - 1].clone();
      LD.craft.visible = false; LD.glow.visible = false; if (LD.shadow) LD.shadow.visible = false; Loader.blast();
      const pr = project(P); Loader.flash(pr.x, pr.y);
      Loader.tele(0, vAt(0), 0);
      const flash = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX.glow, color: 0xfff0d0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, transparent: true })); flash.position.copy(P); scene.add(flash);
      LD.fx.push(a => { const k = a < .35 ? a / .35 : Math.pow(Math.max(0, 1 - (a - .35) / 2.6), 1.6); flash.material.opacity = k; flash.scale.setScalar(.15 + (1 - Math.exp(-a * 1.6)) * 1.6); });
      const rings = [0, .22, .5].map((d, i) => {
        const r = mesh(new THREE.RingGeometry(.92, 1, 96), new THREE.MeshBasicMaterial({ color: i === 1 ? 0x7fd6ff : 0xffcf8a, transparent: true, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
        r.position.copy(LD.n).multiplyScalar(1.004).add(LD.C); r.quaternion.setFromUnitVectors(V(0, 0, 1), LD.n); r.scale.setScalar(.001); scene.add(r);
        LD.fx.push(a => { const t = a - d; if (t < 0) return; r.scale.setScalar(.005 + (1 - Math.exp(-t * 1.1)) * .75); r.material.opacity = Math.pow(Math.max(0, 1 - t / 3), 1.5); });
        return r;
      });
      /* (TR) regolit parçacıkları tamamen ekran kartında hesaplanır (balistik yörünge, işlemci yükü yok) */
      const N = 1400, vel = new Float32Array(N * 3), seed = new Float32Array(N), pos = new Float32Array(N * 3);
      for (let i = 0; i < N; i++) { const rnd = V(Math.random() - .5, Math.random() - .5, Math.random() - .5).normalize().addScaledVector(LD.n, 1.4).normalize().multiplyScalar(.12 + Math.random() ** 2 * .6); vel.set([rnd.x, rnd.y, rnd.z], i * 3); seed[i] = Math.random(); }
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aVel', new THREE.BufferAttribute(vel, 3)); g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
      const pm = new THREE.ShaderMaterial({ uniforms: { uT: { value: 0 }, uP: { value: P.clone() }, uN: { value: LD.n.clone() }, uPR: { value: renderer.getPixelRatio() } }, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
        vertexShader: 'attribute vec3 aVel; attribute float aSeed; uniform float uT,uPR; uniform vec3 uP,uN; varying float vA; void main(){ float t=(1.0-exp(-uT*.9))*1.7*(.75+aSeed*.5); vec3 w=uP+aVel*t-uN*(.08*t*t); float h=dot(w-uP,uN); if(h<0.0) w-=uN*h; vA=pow(clamp(1.0-uT/4.6,0.0,1.0),1.4)*(.55+aSeed*.45); vec4 mv=modelViewMatrix*vec4(w,1.0); gl_Position=projectionMatrix*mv; gl_PointSize=(1.4+aSeed*2.2)*uPR; }',
        fragmentShader: 'varying float vA; void main(){ vec2 c=gl_PointCoord-.5; float d=dot(c,c); if(d>.25) discard; gl_FragColor=vec4(vec3(1.0,.85,.62)*vA*(1.0-d*3.0),1.0); }' });
      const pts = new THREE.Points(g, pm); pts.frustumCulled = false; scene.add(pts);
      LD.fx.push(a => { pm.uniforms.uT.value = a; });
      LD.objects = [flash, pts, ...rings];
      setTimeout(exitLoader, 3300); // (TR) patlama tamamlanır, toz sisi ekranı kapladığında geçiş başlar // (TR) ışık ekranı kapladığı anda gözlemevi ortaya çıkar
    }
    function exitLoader() {
      if (LD.done) return; LD.done = true;
      Loader.finish();
      const up = camera.up.clone();
      // derive spherical rig parameters from the current loader pose
      const B = BODIES.MOON; cam.body = 'MOON';
      cam.target.copy(LD.look); tmp.subVectors(camera.position, LD.look);
      cam.radius = tmp.length(); const a = anglesFromDir(tmp.clone().normalize()); cam.theta = a.theta; cam.phi = a.phi;
      cam.upFrom = up;
      sunDir.set(...SUN_DEFAULT).normalize(); keyLight.position.copy(sunDir).multiplyScalar(100);
      flyTo({ target: bodyCenter('MOON'), radius: B.view, duration: 3.2, body: 'MOON', minR: B.min, maxR: B.max, theta: .55, phi: 1.15 });
      LD.active = false;
      setTimeout(() => { [LD.craft, LD.trail, LD.pred, LD.glow, LD.shadow, ...(LD.objects || [])].forEach(o => { if (!o) return; scene.remove(o); o.traverse && o.traverse(m => { if (m.geometry) m.geometry.dispose(); if (m.material && m.material !== MAT) (Array.isArray(m.material) ? m.material : [m.material]).forEach(x => x.dispose && x.dispose()); }); }); LD.fx = []; LD.objects = null; }, 5800);
      Store.set({ booted: true });
    }

    /* ---------- picking & controls ---------- */
    function pick(x, y) {
      raycaster.setFromCamera(new THREE.Vector2(x / innerWidth * 2 - 1, -(y / innerHeight) * 2 + 1), camera);
      const h = raycaster.intersectObjects(markers.filter(m => m.visible), false); return h.length ? h[0].object.userData.craftId : null;
    }
    function bindControls() {
      const el = $('#stage'), ptrs = new Map(); let down = null, pinch = 0;
      el.addEventListener('pointerdown', e => { el.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); down = { x: e.clientX, y: e.clientY, t: performance.now() }; el.classList.add('drag'); });
      el.addEventListener('pointermove', e => {
        if (!ptrs.has(e.pointerId)) return; const prev = ptrs.get(e.pointerId); ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (cam.anim || LD.active) return;
        if (ptrs.size === 1) { const k = .0045 * clamp(cam.radius / 3, .15, 1.2); cam.theta -= (e.clientX - prev.x) * k; cam.phi = clamp(cam.phi - (e.clientY - prev.y) * k, .08, Math.PI - .08); }
        else if (ptrs.size === 2) { const [a, b] = [...ptrs.values()], d = Math.hypot(a.x - b.x, a.y - b.y); if (pinch) cam.radius = clamp(cam.radius * pinch / d, cam.minR, cam.maxR); pinch = d; }
      });
      const up = e => {
        ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch = 0; el.classList.remove('drag');
        if (down && Math.hypot(e.clientX - down.x, e.clientY - down.y) < 6 && performance.now() - down.t < 500 && Store.get().booted) { const id = pick(e.clientX, e.clientY); if (id) UI.selectCraft(id); }
        down = null;
      };
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
      el.addEventListener('wheel', e => { if (document.body.classList.contains('story') && !LD.active && !e.ctrlKey && !e.shiftKey && !e.altKey) return; /* (TR) hikâye modunda tekerlek sayfayı kaydırır; Ctrl/Shift/Alt + tekerlek ya da iki parmak yakınlaştırır */ e.preventDefault(); if (cam.anim || LD.active) return; cam.radius = clamp(cam.radius * Math.exp((e.deltaY || e.deltaX) * .0012), cam.minR, cam.maxR); }, { passive: false });
    }

    /* ---------- loop ---------- */
    let roT = 0;
    function loop() {
      requestAnimationFrame(loop);
      if (document.hidden) { clock.getDelta(); return; }
      const raw = clock.getDelta(), dt = Math.min(raw, .05); if (__perfHook) __perfHook(raw); elapsed += dt; orbitTime += dt;
      updateBodies(dt); updateCrafts(dt);
      Sim.update(dt);
      if (LD.active) updateLoader(dt); else updateCamera(Math.min(raw, .25));
      skyTint.lerp(skyTarget, Math.min(1, dt * 1.5));
      stars.position.copy(camera.position); sky.position.copy(camera.position);
      sunSprite.position.copy(camera.position).addScaledVector(sunDir, 3000);
      renderer.render(scene, camera);
      updateLabels(); Inspector.render(dt);
      roT += dt; if (roT > .25 && !LD.active) { roT = 0; UI.readouts(Math.max(0, camera.position.distanceTo(bodyCenter(cam.body)) - 1) * BODIES[cam.body].radiusKm); }
    }
    function setTheme(key) { skyTarget.set(...THEME[key][0]); }

    function onState(s, p) {
      if (!s.booted) return;
      if (changed(s, p, 'activeSpacecraftId') || changed(s, p, 'selectedCelestialBody')) {
        if (s.activeSpacecraftId && changed(s, p, 'activeSpacecraftId')) focusCraft(s.activeSpacecraftId);
        else if (!s.activeSpacecraftId && p.booted) focusBody(s.selectedCelestialBody);
      }
      if (changed(s, p, 'selectedCelestialBody')) setTheme(s.selectedCelestialBody);
      if (changed(s, p, 'activeLanguage')) refreshLabels();
    }
    function replaceModel(id, obj) {
      const r = crafts[id]; if (!r) return;
      const w = normalizeModel(obj, 1); r.holder.remove(r.model); r.model = w; r.holder.add(w); r.fromFile = true; Inspector.show(id);
    }
    return {
      get scene() { return scene; }, get camera() { return camera; }, get ready() { return ready; },
      crafts, bodies, cam, bodyCenter, latLonVec, anglesFromDir, flyTo, focusBody, lookAtEvent, replaceModel, samplePath,
      initRenderer, buildSky, buildBodies, buildCrafts, buildLabels, bindControls, setupLoader, loaderImpact, exitLoader,
      compile() { renderer.compile(scene, camera); },
      start() { ready = true; Store.subscribe(onState); loop(); }
    };
  })();

  /* =================================================================
     PHASE 2 - LOADER CONTROLLER (DOM + progress)
     ================================================================= */
  const Loader = (() => {
    const root = $('#loader'), MIN_MS = 6800;
    let real = 0, shown = 0, t0 = performance.now(), forced = false, impacted = false, finished = false, stageKey = 'ldEngine', raf = 0;
    function frame(now) {
      raf = requestAnimationFrame(frame);
      const timeP = forced ? 100 : clamp((now - t0) / MIN_MS * 100, 0, 100);
      const target = Math.min(real, timeP);
      shown += (target - shown) * .07; if (target - shown < .04) shown = target;
      const pct = impacted ? 100 : Math.min(99, Math.floor(shown));
      if (!impacted && real >= 100 && shown > 99.4 && Engine.ready) { impacted = true; Engine.loaderImpact(); stage('impact'); }
      if (pct !== Store.get().loadingProgress) Store.set({ loadingProgress: pct });
      $('#ldPct').textContent = pct; $('#ldBar').style.width = (impacted ? 100 : shown) + '%';
    }
    function stage(k) { stageKey = k; const el = $('#ldStage'); el.textContent = t(k); el.classList.toggle('hit', k === 'impact'); }
    return {
      start() { stage('ldEngine'); raf = requestAnimationFrame(frame); $('#ldSkip').onclick = () => { forced = true; }; },
      setReal(v, k) { real = Math.max(real, v); if (k) stage(k); },
      shown: () => impacted ? 100 : shown,
      relabel() { stage(stageKey); },
      ready3d() { root.classList.remove('boot'); },
      tele(alt, vel, tti) {
        $('#ldAlt').textContent = fmtNum(alt, 0); $('#ldVel').textContent = fmtNum(vel, 3);
        const s = Math.max(0, tti), hh = Math.floor(s / 3600), mm = Math.floor(s % 3600 / 60), ss = Math.floor(s % 60);
        $('#ldTti').textContent = `T-${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
      },
      reticle(x, y, ok) { const r = $('#ldReticle'); r.style.left = x + 'px'; r.style.top = y + 'px'; r.style.opacity = ok && !impacted ? 1 : 0; },
      flash(x, y) {
        const f = $('#ldFlash'); f.style.setProperty('--fx', x + 'px'); f.style.setProperty('--fy', y + 'px');
        f.animate([{ opacity: 0 }, { opacity: 1, offset: .05 }, { opacity: 0 }], { duration: 1600, easing: 'ease-out' });
        $('#ldReticle').style.opacity = 0;
      },
      blast() {
        const f = $('#ldFlash'), x = f.style.getPropertyValue('--fx') || '50%', y = f.style.getPropertyValue('--fy') || '50%';
        const mk = cls => { const d = document.createElement('div'); d.className = cls; d.style.left = x; d.style.top = y; document.body.appendChild(d); return d; };
        const bloom = mk('ld-bloom'), r1 = mk('ld-shock'), r2 = mk('ld-shock ld-shock2');
        bloom.animate([{ transform: 'translate(-50%,-50%) scale(.05)', opacity: 0 }, { transform: 'translate(-50%,-50%) scale(.7)', opacity: 1, offset: .14 }, { transform: 'translate(-50%,-50%) scale(1)', opacity: .55, offset: .5 }, { transform: 'translate(-50%,-50%) scale(1.15)', opacity: 0 }], { duration: 3400, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'forwards' });
        r1.animate([{ transform: 'translate(-50%,-50%) scale(.02)', opacity: 1 }, { transform: 'translate(-50%,-50%) scale(1)', opacity: 0 }], { duration: 2000, easing: 'cubic-bezier(.1,.8,.3,1)', fill: 'forwards' });
        r2.animate([{ transform: 'translate(-50%,-50%) scale(.02)', opacity: .8 }, { transform: 'translate(-50%,-50%) scale(1)', opacity: 0 }], { duration: 2600, delay: 160, easing: 'cubic-bezier(.1,.8,.3,1)', fill: 'forwards' });
        root.animate([0, 1, 2, 3, 4, 5, 6].map(i => ({ transform: i === 6 ? 'none' : `translate(${(Math.random() - .5) * 14 * (1 - i / 6)}px,${(Math.random() - .5) * 14 * (1 - i / 6)}px)` })), { duration: 420, easing: 'linear' });
        const haze = mk('ld-haze');
        haze.animate([{ transform: 'translate(-50%,-50%) scale(.15)', opacity: 0 }, { transform: 'translate(-50%,-50%) scale(.75)', opacity: .5, offset: .3 }, { transform: 'translate(-50%,-50%) scale(1)', opacity: .92, offset: .62 }, { transform: 'translate(-50%,-50%) scale(1.12)', opacity: .92, offset: .72 }, { transform: 'translate(-50%,-50%) scale(1.3)', opacity: 0 }], { duration: 5200, delay: 250, easing: 'cubic-bezier(.33,0,.25,1)', fill: 'forwards' });
        setTimeout(() => [bloom, r1, r2, haze].forEach(d => d.remove()), 5600);
      },
      finish() { if (finished) return; finished = true;
        const st = $('#stage'); if (st) st.animate([{ transform: 'scale(1.07)', opacity: .25 }, { transform: 'scale(1)', opacity: 1 }], { duration: 2600, easing: 'cubic-bezier(.22,.61,.36,1)' });
        root.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 1600, easing: 'ease-out', fill: 'forwards' }); root.classList.add('fade'); setTimeout(() => { cancelAnimationFrame(raf); root.style.display = 'none'; }, 1700); },
      error(m) { const e = $('#ldError'); e.style.display = 'block'; e.textContent = m; }
    };
  })();

  /* =================================================================
     PLANET TRANSIT SCREEN
     ================================================================= */
  const Transit = (() => {
    const el = $('#transit'), cv = $('#warp'), g = cv.getContext('2d');
    let on = false, start = 0, raf = 0, streaks = [];
    function resize() { const d = Math.min(devicePixelRatio || 1, 2); cv.width = innerWidth * d; cv.height = innerHeight * d; g.setTransform(d, 0, 0, d, 0, 0); }
    function frame(now) {
      if (!on) return; raf = requestAnimationFrame(frame);
      const W = innerWidth, H = innerHeight, cx = W / 2, cy = H / 2, el2 = (now - start) / 1000;
      const accent = frame.acc || (frame.acc = getComputedStyle(document.body).getPropertyValue('--accent-rgb').trim() || '127,214,255');
      g.fillStyle = 'rgba(2,4,8,.35)'; g.fillRect(0, 0, W, H);
      const speed = Math.min(1, el2 / .8) * (1 - smooth(1.9, 2.6, el2) * .8);
      for (const s of streaks) {
        s.d += s.v * speed * 18 * (1 + s.d / 300);
        if (s.d > Math.max(W, H)) { s.d = Math.random() * 40; s.a = Math.random() * 6.283; }
        const x1 = cx + Math.cos(s.a) * s.d, y1 = cy + Math.sin(s.a) * s.d, len = s.d * .08 * speed + 1;
        const x0 = cx + Math.cos(s.a) * (s.d - len), y0 = cy + Math.sin(s.a) * (s.d - len);
        g.strokeStyle = `rgba(${s.w ? '255,255,255' : accent},${Math.min(1, s.d / 260) * .85})`; g.lineWidth = s.w ? 1.2 : .9;
        g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke();
      }
    }
    function show(key) { frame.acc = null;
      const B = BODIES[key], list = CRAFT.filter(c => c.body === key), y = Store.get().timelineYear;
      const first = list.reduce((a, c) => c.arriveYear < a.arriveYear ? c : a, list[0]);
      $('#trKick').textContent = t('inbound'); $('#trCoord').textContent = key === 'MOON' ? 'EARTH-MOON L1 / 384,400 km' : 'HELIOCENTRIC / 1.52 AU';
      $('#trName').textContent = t(key === 'MOON' ? 'moon' : 'mars'); $('#trSub').textContent = t(key === 'MOON' ? 'moonSub' : 'marsSub');
      $('#trStats').innerHTML = [['radius', B.stats.radius], ['gravity', B.stats.gravity], ['distEarth', B.stats.dist], ['dayLength', B.stats.day], ['artifacts', String(list.filter(c => y >= c.arriveYear).length)], ['firstArrival', first.arriveYear + ' / ' + craftName(first)]]
        .map(([k, v]) => `<div><label>${t(k)}</label><b>${esc(v)}</b></div>`).join('');
      streaks = Array.from({ length: 320 }, () => ({ a: Math.random() * 6.283, d: Math.random() * Math.max(innerWidth, innerHeight), v: .4 + Math.random(), w: Math.random() < .2 }));
      resize(); on = true; start = performance.now(); el.classList.add('on'); el.setAttribute('aria-hidden', 'false');
      cancelAnimationFrame(raf); raf = requestAnimationFrame(frame);
      clearTimeout(show.tm); show.tm = setTimeout(hide, 2650);
    }
    function hide() { el.classList.remove('on'); el.setAttribute('aria-hidden', 'true'); setTimeout(() => { on = false; }, 500); }
    addEventListener('resize', () => on && resize());
    return { show };
  })();

  /* =================================================================
     PHASE 4 - SIMULATION MODULE
     ================================================================= */
  const Sim = (() => {
    let S = null; const N = 360;
    /* =================================================================
       ARRIVAL PROFILES - how each craft really reached the surface
       (TR) GERÇEK VARIŞ PROFİLLERİ: her aracın Ay'a/Mars'a nasıl vardığı görev kayıtlarına göre
       anahtar karelerle tanımlanır (doğrudan çarpma, sıyırma çarpma, motorlu iniş, askıda kalma,
       paraşüt, hava yastığıyla sekme, erken motor kesilmesi). Konum her karede bu karelerden
       yumuşak geçişlerle (ease) hesaplanır; sıçrama yayları balistik parabol izler.
       Units: a = altitude and d = downrange (negative while approaching), both in craft heights;
       altM / vMs are the real figures shown in the HUD. Sources: NSSDCA, NASA/JPL, ESA, SpaceIL.
       ================================================================= */
    const K = (t, a, d, o) => Object.assign({ t, a, d }, o || {});
    const MARS_ENTRY = () => [
      K(0, 46, -64, { heat: 0, altM: 125000, vMs: 5600, ph: 'entry' }),
      K(2.4, 24, -30, { heat: 1, altM: 40000, vMs: 3300, ph: 'entry' }),
      K(4.2, 15, -15, { heat: .1, altM: 12000, vMs: 430, ph: 'entry', ease: 'out' })
    ];
    /* airbag bounces: Pathfinder's first rebound was ~15.7 m and it bounced at least 15 times over ~1 km */
    function bounces(keys, hops, step) {
      let t = keys[keys.length - 1].t, d = keys[keys.length - 1].d;
      hops.forEach(h => { const dt = .34 + Math.sqrt(h) * .42; t += dt; d += step * (.35 + Math.sqrt(h)); keys.push(K(t, 0, d, { hop: h, ph: 'bounce', vMs: 3 + h * 4, altM: 0 })); });
      keys.push(K(t + .9, 0, d + step * .6, { ease: 'out', ph: 'roll', vMs: 0 }));
      keys.push(K(t + 2.0, 0, d + step * .6, { bag: 0, ph: 'petals' }));
      return keys;
    }
    function airbagLander(rockets) {
      const k = MARS_ENTRY().concat([
        K(5.3, 12, -11, { chute: 1, heat: 0, altM: 9000, vMs: 400, ph: 'chute' }),
        K(7.4, 4.6, -3.2, { ease: 'out', chute: 1, altM: 300, vMs: 65, ph: 'chute' }),
        K(7.8, 4.1, -2.8, { chute: 1, bag: 1, altM: 200, vMs: 63, ph: 'bags' }),
        K(8.4, 2.6, -2.0, { chute: 1, bag: 1, eng: rockets ? 1 : 0, altM: 98, vMs: 55, ph: rockets ? 'retro' : 'bags' }),
        K(9.0, 1.1, -1.5, { ease: 'out', chute: 0, bag: 1, eng: 0, altM: 21, vMs: 14, ph: 'cut' }),
        K(9.45, 0, -1.25, { ease: 'acc', bag: 1, altM: 0, vMs: 14, ph: 'bounce' })
      ]);
      return bounces(k, [2.3, 1.8, 1.4, 1.05, .78, .55, .38, .24, .14, .07], .7);
    }
    function legLanderMars(o) {
      return MARS_ENTRY().concat([
        K(5.3, o.chuteA, -o.chuteA, { chute: 1, heat: 0, altM: o.chuteM, vMs: 400, ph: 'chute' }),
        K(o.tSep, o.sepA, -o.sepA * .9, { ease: 'out', chute: 1, altM: o.sepM, vMs: o.sepV, ph: 'chute' }),
        K(o.tSep + .45, o.sepA * .88, -o.sepA * .75, { chute: 0, eng: 1, pulse: o.pulse ? 1 : 0, altM: o.sepM * .92, vMs: o.sepV, ph: 'retro' })
      ]);
    }
    const PROFILES = {
      /* --- Moon: impactors (designed to hit, or end-of-mission impacts from orbit) --- */
      luna2: { type: 'impact', keys: [K(0, 64, -26, { altM: 250000, vMs: 2400, ph: 'coast' }), K(6.5, 0, 0, { ease: 'acc', altM: 0, vMs: 3300, ph: 'coast' })] },          // direct ascent, ~3.3 km/s
      ranger7: { type: 'impact', keys: [K(0, 64, -9, { altM: 2110000, vMs: 1500, ph: 'imaging' }), K(7, 0, 0, { ease: 'acc', altM: 0, vMs: 2620, ph: 'imaging' })] },     // near-vertical, 2.62 km/s, imaging the last 17 min
      prospector: { type: 'impact', graze: true, keys: [K(0, 6.6, -60, { altM: 20000, vMs: 1690, ph: 'graze', tilt: .4 }), K(7, 0, 0, { ease: 'lin', altM: 0, vMs: 1690, ph: 'graze', tilt: .4 })] }, // 6.3 deg, 1.69 km/s
      smart1: { type: 'impact', graze: true, keys: [K(0, 3.6, -68, { altM: 12000, vMs: 2000, ph: 'graze' }), K(7, 0, 0, { ease: 'lin', altM: 0, vMs: 2000, ph: 'graze' }), K(8.3, 0, 9, { hop: .9, altM: 0, vMs: 1500, ph: 'bounce' })] }, // grazing 5-10 deg, possible rebound
      lcross: { type: 'impact', centaur: 5.6, keys: [K(0, 64, -5, { altM: 80000, vMs: 2500, ph: 'coast' }), K(5.6, 28, -2.2, { ease: 'lin', altM: 35000, vMs: 2500, ph: 'centaur' }), K(10, 0, 0, { ease: 'lin', altM: 0, vMs: 2500, ph: 'centaur' })] }, // ~86 deg, Centaur then S-S/C 4 min later
      grail: { type: 'impact', graze: true, keys: [K(0, 2.2, -84, { altM: 10000, vMs: 1700, ph: 'graze' }), K(7, 0, 0, { ease: 'lin', altM: 0, vMs: 1700, ph: 'graze' })] }, // 1.5 deg into a mountain, 1.7 km/s
      beresheet: { type: 'impact', graze: true, keys: [
        K(0, 30, -92, { eng: 1, tilt: -1.0, altM: 22000, vMs: 1000, ph: 'powered' }),
        K(3, 16, -62, { eng: 1, tilt: -.95, altM: 14000, vMs: 820, ph: 'powered' }),
        K(3.5, 14.6, -57, { eng: 0, tilt: -.9, altM: 13000, vMs: 800, ph: 'enginecut' }),           // IMU reset, main engine off
        K(6, 5, -38, { eng: 0, tilt: -.7, altM: 5500, vMs: 900, ph: 'enginecut' }),
        K(6.5, 3.6, -26, { eng: 1, tilt: -.6, altM: 1500, vMs: 940, ph: 'restart' }),               // engine back, too late
        K(8, 0, 0, { ease: 'acc', eng: .7, tilt: -.5, altM: 0, vMs: 950, ph: 'restart' })]          // ~950 m/s at ~8 deg
      },
      /* --- Moon: landers --- */
      luna9: { type: 'land', keys: bounces([
        K(0, 44, -6, { altM: 75000, vMs: 2600, ph: 'coast' }),
        K(1, 37, -5, { eng: 1, altM: 70000, vMs: 2500, ph: 'retro' }),
        K(6, 1.5, -.5, { ease: 'out', eng: 1, altM: 250, vMs: 15, ph: 'retro' }),
        K(6.8, .45, -.15, { eng: .7, altM: 5, vMs: 6, ph: 'retro' }),
        K(7.0, .42, -.12, { eng: 0, bag: 1, altM: 5, vMs: 6, ph: 'bags' }),                          // capsule ejected, airbags
        K(7.4, 0, 0, { ease: 'acc', bag: 1, altM: 0, vMs: 6.1, ph: 'bounce' })], [.55, .3, .14], .45) },
      surveyor3: { type: 'land', keys: [
        K(0, 44, -5, { altM: 75000, vMs: 2600, ph: 'coast' }),
        K(1, 38, -4.4, { eng: 1, altM: 75000, vMs: 2600, ph: 'retro' }),
        K(4.2, 6, -.8, { ease: 'out', eng: 1, altM: 11000, vMs: 130, ph: 'retro' }),
        K(7, .2, -.05, { ease: 'out', eng: .6, altM: 4.3, vMs: 1.5, ph: 'vernier' }),
        K(7.4, 0, 0, { eng: .6, altM: 0, vMs: 1.5, ph: 'touchdown' }),
        K(8.9, 0, .22, { hop: 2.2, eng: .55, altM: 0, vMs: 1, ph: 'bounce' }),                      // verniers kept firing: ~10 m hop
        K(9.9, 0, .32, { hop: .75, eng: 0, altM: 0, vMs: 1, ph: 'bounce' }),                         // ~3 m hop
        K(10.4, 0, .34, { ease: 'out', altM: 0, vMs: 0, ph: 'touchdown' })] },
      apollo11: { type: 'land', keys: [
        K(0, 30, -84, { eng: 1, tilt: -1.25, altM: 15000, vMs: 1690, ph: 'braking' }),
        K(5, 9, -26, { ease: 'out', eng: 1, tilt: -1.0, altM: 2200, vMs: 150, ph: 'braking' }),
        K(6.6, 5, -11, { eng: 1, tilt: -.25, altM: 600, vMs: 40, ph: 'pitchover' }),
        K(8.6, 2.2, -4.6, { ease: 'out', eng: .8, tilt: -.12, altM: 150, vMs: 18, ph: 'approach' }),
        K(11.8, 1.2, -1.2, { eng: .7, tilt: .1, altM: 60, vMs: 16, ph: 'hover' }),                 // flew past the boulder field
        K(12.9, .8, -.25, { eng: .6, tilt: .03, altM: 30, vMs: 4, ph: 'hover' }),
        K(14.4, 0, 0, { ease: 'out', eng: .5, tilt: 0, altM: 0, vMs: .5, ph: 'touchdown' })] },
      apollo17: { type: 'land', keys: [
        K(0, 30, -80, { eng: 1, tilt: -1.25, altM: 15000, vMs: 1690, ph: 'braking' }),
        K(5, 9, -24, { ease: 'out', eng: 1, tilt: -1.0, altM: 2200, vMs: 150, ph: 'braking' }),
        K(6.6, 5, -10, { eng: 1, tilt: -.25, altM: 600, vMs: 40, ph: 'pitchover' }),
        K(9, 1.6, -2.4, { ease: 'out', eng: .8, tilt: -.1, altM: 120, vMs: 12, ph: 'approach' }),
        K(11.4, 0, 0, { ease: 'out', eng: .5, tilt: 0, altM: 0, vMs: .6, ph: 'touchdown' })] },
      lunokhod1: { type: 'land', keys: [
        K(0, 40, -10, { eng: 1, altM: 20000, vMs: 1700, ph: 'retro' }),
        K(6, 1.3, -.4, { ease: 'out', eng: 1, altM: 20, vMs: 3, ph: 'retro' }),
        K(7.6, 0, 0, { ease: 'out', eng: .5, altM: 0, vMs: 1, ph: 'touchdown' })] },
      yutu: { type: 'land', keys: [
        K(0, 30, -74, { eng: 1, tilt: -1.2, altM: 15000, vMs: 1700, ph: 'powered' }),
        K(5, 6, -6, { ease: 'out', eng: 1, tilt: -.2, altM: 2000, vMs: 60, ph: 'powered' }),
        K(6.8, 2.6, -.8, { ease: 'out', eng: .7, tilt: 0, altM: 100, vMs: 2, ph: 'hover' }),         // hover at 100 m, hazard avoidance
        K(8.8, 2.6, 0, { ease: 'io', eng: .7, altM: 100, vMs: 1, ph: 'hover' }),
        K(11, .12, 0, { ease: 'io', eng: .6, altM: 4, vMs: 1.5, ph: 'descent' }),
        K(11.06, .12, 0, { eng: 0, altM: 4, vMs: 1.5, ph: 'freefall' }),                          // engine off at ~4 m
        K(11.5, 0, 0, { ease: 'acc', eng: 0, altM: 0, vMs: 3.6, ph: 'touchdown' })] },
      /* --- Mars --- */
      viking1: { type: 'land', keys: legLanderMars({ chuteA: 9, chuteM: 6000, tSep: 7.8, sepA: 3.6, sepM: 1500, sepV: 60 }).concat([K(10.8, 0, 0, { ease: 'out', eng: .6, altM: 0, vMs: 2.4, ph: 'touchdown' })]) },
      viking2: { type: 'land', keys: legLanderMars({ chuteA: 9, chuteM: 6000, tSep: 7.8, sepA: 3.6, sepM: 1500, sepV: 60 }).concat([K(10.8, 0, 0, { ease: 'out', eng: .6, altM: 0, vMs: 2.4, ph: 'touchdown' })]) },
      phoenix: { type: 'land', keys: legLanderMars({ chuteA: 14, chuteM: 12600, tSep: 8.4, sepA: 2.8, sepM: 980, sepV: 56, pulse: true }).concat([K(10.6, .15, -.08, { ease: 'out', eng: 1, pulse: 1, altM: 50, vMs: 2.4, ph: 'retro' }), K(11.6, 0, 0, { eng: .8, pulse: 1, altM: 0, vMs: 2.4, ph: 'touchdown' })]) },
      insight: { type: 'land', keys: legLanderMars({ chuteA: 14, chuteM: 12600, tSep: 8.4, sepA: 2.8, sepM: 980, sepV: 56, pulse: true }).concat([K(10.6, .15, -.08, { ease: 'out', eng: 1, pulse: 1, altM: 50, vMs: 2.4, ph: 'retro' }), K(11.6, 0, 0, { eng: .8, pulse: 1, altM: 0, vMs: 2.4, ph: 'touchdown' })]) },
      mars3: { type: 'land', keys: legLanderMars({ chuteA: 10, chuteM: 7000, tSep: 8.4, sepA: .9, sepM: 30, sepV: 10 }).concat([K(9.3, 0, 0, { ease: 'out', eng: .4, altM: 0, vMs: 2, ph: 'touchdown' })]) },
      mpl: { type: 'land', hard: true, keys: legLanderMars({ chuteA: 14, chuteM: 8800, tSep: 8.4, sepA: 2.8, sepM: 1300, sepV: 80, pulse: true }).concat([
        K(10.1, 1.1, -.5, { ease: 'out', eng: 1, pulse: 1, altM: 40, vMs: 13, ph: 'retro' }),
        K(10.16, 1.1, -.5, { eng: 0, altM: 40, vMs: 13, ph: 'enginecut' }),                        // spurious touchdown signal, engines off at 40 m
        K(11.1, 0, 0, { ease: 'acc', eng: 0, altM: 0, vMs: 22, ph: 'enginecut' })]) },
      pathfinder: { type: 'land', keys: airbagLander(true) },
      spirit: { type: 'land', keys: airbagLander(true) },
      opportunity: { type: 'land', keys: airbagLander(true) },
      beagle2: { type: 'land', keys: airbagLander(false) }                                          // airbags, no rockets
    };
    const FIELDS = ['eng', 'heat', 'chute', 'bag', 'tilt', 'altM', 'vMs', 'pulse'];
    // AKICILIK: tüm profiller %25 yavaşlatılır; konum, anahtar karelerden geçen monoton kübik Hermite eğrisiyle (PCHIP)
    // hesaplanır. Böylece aşama geçişlerinde hız sıçramaz, araç durup kalkmaz; eğri aşırı salınım (overshoot) da yapmaz.
    const TIME_SCALE = 1.25, RATE = 120;
    function pchip(keys, ch) {
      const n = keys.length, m = new Array(n).fill(0), dl = [];
      for (let i = 0; i < n - 1; i++) dl.push((keys[i + 1][ch] - keys[i][ch]) / Math.max(1e-6, keys[i + 1].t - keys[i].t));
      for (let i = 1; i < n - 1; i++) {
        if (keys[i].hop || keys[i + 1].hop) { m[i] = keys[i + 1].hop ? 0 : dl[i - 1]; continue; }   // contact with a bounce: velocity changes physically
        const h0 = keys[i].t - keys[i - 1].t, h1 = keys[i + 1].t - keys[i].t, a = dl[i - 1], b = dl[i];
        if (a * b <= 0) m[i] = 0; else { const w1 = 2 * h1 + h0, w2 = h1 + 2 * h0; m[i] = (w1 + w2) / (w1 / a + w2 / b); }
        if (keys[i].ease === 'out') m[i] *= .45;                                                    // braking into this key
      }
      m[0] = dl[0]; m[n - 1] = keys[n - 1].ease === 'out' ? dl[n - 2] * .3 : keys[n - 1].ease === 'acc' ? dl[n - 2] * 1.35 : dl[n - 2];
      return m;
    }
    function prepProfile(src) {
      const keys = src.keys.map(k => Object.assign({}, k, { t: k.t * TIME_SCALE })), last = keys[keys.length - 1].d;
      keys.forEach((k, i) => { k.d -= last; FIELDS.forEach(f => { if (k[f] === undefined) k[f] = i ? keys[i - 1][f] : 0; }); if (!k.ph) k.ph = i ? keys[i - 1].ph : 'coast'; });
      const dur = keys[keys.length - 1].t, ma = pchip(keys, 'a'), md = pchip(keys, 'd'), ns = Math.ceil(dur * RATE) + 1;
      const A = new Float32Array(ns), Dd = new Float32Array(ns);
      let i = 0;
      for (let j = 0; j < ns; j++) {
        const t = Math.min(dur, j / RATE); while (i < keys.length - 2 && t > keys[i + 1].t) i++;
        const k0 = keys[i], k1 = keys[i + 1], h = Math.max(1e-6, k1.t - k0.t), f = clamp((t - k0.t) / h, 0, 1);
        if (k1.hop) { A[j] = lerp(k0.a, k1.a, f) + 4 * k1.hop * f * (1 - f); Dd[j] = lerp(k0.d, k1.d, f); continue; }   // ballistic arc
        const f2 = f * f, f3 = f2 * f, h00 = 2 * f3 - 3 * f2 + 1, h10 = f3 - 2 * f2 + f, h01 = -2 * f3 + 3 * f2, h11 = f3 - f2;
        A[j] = Math.max(0, h00 * k0.a + h10 * h * ma[i] + h01 * k1.a + h11 * h * ma[i + 1]);
        Dd[j] = h00 * k0.d + h10 * h * md[i] + h01 * k1.d + h11 * h * md[i + 1];
      }
      A[ns - 1] = 0; Dd[ns - 1] = 0;
      return { type: src.type, graze: !!src.graze, hard: !!src.hard, centaur: src.centaur && src.centaur * TIME_SCALE, keys, dur, cursor: 0, A, D: Dd };
    }
    const easeF = (f, e) => e === 'out' ? 1 - (1 - f) * (1 - f) : e === 'acc' ? f * (.55 + .45 * f) : e === 'in' ? f * f : e === 'io' ? f * f * (3 - 2 * f) : f;
    const sst = f => f * f * (3 - 2 * f);
    /* evaluates the profile at time t into o (no allocation) */
    function evalProfile(P, t, o) {
      const k = P.keys; let i = P.cursor;
      while (i < k.length - 2 && t > k[i + 1].t) i++;
      while (i > 0 && t < k[i].t) i--;
      P.cursor = i;
      const A = k[i], B = k[Math.min(i + 1, k.length - 1)], f = clamp((t - A.t) / Math.max(1e-6, B.t - A.t), 0, 1), e = easeF(f, B.ease), s = sst(f);
      // konum: önceden 120 Hz'de örneklenmiş pürüzsüz eğriden doğrusal okuma (yeni nesne yok)
      const x = clamp(t, 0, P.dur) * RATE, j = Math.min(P.A.length - 2, Math.floor(x)), w = x - j;
      o.a = P.A[j] + (P.A[j + 1] - P.A[j]) * w; o.d = P.D[j] + (P.D[j + 1] - P.D[j]) * w;
      o.eng = lerp(A.eng, B.eng, s); o.heat = lerp(A.heat, B.heat, s); o.chute = lerp(A.chute, B.chute, s); o.bag = lerp(A.bag, B.bag, s);
      o.tilt = lerp(A.tilt, B.tilt, e); o.pulse = B.pulse; o.altM = lerp(A.altM, B.altM, e); o.vMs = lerp(A.vMs, B.vMs, f); o.ph = B.ph;
      return o;
    }
    /* ---------- arrival runtime: parachute, airbags, engine plume, heat glow, dust, camera ---------- */
    const CH = .02;                                   // one craft height in scene units (models are normalised and scaled to ~0.024)
    let _o = null, _dir, _fwdL, _upT, _tmpA, _tmpB, _camT, _site;
    function makeChute() {
      const g = new THREE.Group();
      const canopy = mesh(new THREE.SphereGeometry(1.15, 20, 6, 0, Math.PI * 2, 0, Math.PI * .42), MAT.cream); canopy.position.y = 1.9; g.add(canopy);
      const band = mesh(new THREE.SphereGeometry(1.16, 20, 2, 0, Math.PI * 2, Math.PI * .3, Math.PI * .08), MAT.red); band.position.y = 1.9; g.add(band);
      const pts = []; for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2; pts.push(0, .35, 0, Math.cos(a) * 1.05, 1.9 + .32, Math.sin(a) * 1.05); }
      const lg = new THREE.BufferGeometry(); lg.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pts), 3));
      g.add(new THREE.LineSegments(lg, new THREE.LineBasicMaterial({ color: 0xd8d2c4, transparent: true, opacity: .7 })));
      return g;
    }
    function makeBags() {
      const g = new THREE.Group(), geo = new THREE.IcosahedronGeometry(.36, 1);
      const dirs = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1], [.6, .6, .6], [-.6, .6, -.6], [.6, -.6, -.6], [-.6, -.6, .6], [.6, .6, -.6], [-.6, -.6, -.6]];
      dirs.forEach((d, i) => { const m = mesh(geo, i % 3 ? MAT.cream : MAT.bag); const v = V(d[0], d[1], d[2]).normalize().multiplyScalar(.5); m.position.copy(v); g.add(m); });
      return g;
    }
    function startArrival(r, c, P, scene) {
      if (!_o) { _o = {}; _dir = V(0, 0, 0); _fwdL = V(0, 0, 0); _upT = V(0, 0, 0); _tmpA = V(0, 0, 0); _tmpB = V(0, 0, 0); _camT = V(0, 0, 0); _site = V(0, 0, 0); }
      const body = r.body, center = body.center, isMars = c.body === 'MARS';
      const nrm = r.normal.clone().applyQuaternion(body.mesh.quaternion);
      let fwd = V(0, 1, 0).cross(nrm); if (fwd.lengthSq() < 1e-4) fwd.set(1, 0, 0); fwd.normalize();
      const surf = (r.surf || 1) + .0006;
      const S0 = { id: c.id, r, c, P, mode: c.sim, dur: P.dur, t: 0, surf, center, B: body.B, isMars, nrm, fwd, ended: false, fx: [], endAt: 0, extra: [], prevA: 99, chuteRel: -1, bagRoll: 0, plumeDone: false };
      S0.g = body.B.radiusKm < 2000 ? 1.62 : 3.72;
      // trail precomputed from the same profile (time-uniform samples)
      const posA = new Float32Array(N * 3), colA = new Float32Array(N * 3), path = [];
      for (let i = 0; i < N; i++) { evalProfile(P, i / (N - 1) * P.dur, _o); const p = arrivalPos(S0, _o, V(0, 0, 0)); path.push(p); posA.set([p.x, p.y, p.z], i * 3); const h = _o.heat, e = _o.eng; colA.set([.35 + .65 * Math.max(h, e * .8), .55 + .2 * e - .25 * h, .9 - .7 * h - .4 * e], i * 3); }
      P.cursor = 0;
      const tg = new THREE.BufferGeometry(); tg.setAttribute('position', new THREE.BufferAttribute(posA, 3)); tg.setAttribute('color', new THREE.BufferAttribute(colA, 3)); tg.setDrawRange(0, 0);
      const trail = new THREE.Line(tg, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: .55, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
      const head = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX.glow, color: 0xffb46a, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, transparent: true }));
      const heat = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX.glow, color: 0xff7a3a, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, transparent: true }));
      head.scale.setScalar(.0001); heat.scale.setScalar(.0001); scene.add(trail, head, heat);
      Object.assign(S0, { path, trail, head, heatSpr: heat, colA, endN: nrm });
      if (P.keys.some(k => k.chute > 0)) { S0.chute = makeChute(); S0.chute.visible = false; scene.add(S0.chute); S0.extra.push(S0.chute); }
      if (P.keys.some(k => k.bag > 0)) { S0.bags = makeBags(); S0.bags.visible = false; scene.add(S0.bags); S0.extra.push(S0.bags); }
      S0.dust = makeDust(scene, 900, isMars ? 0xc98a62 : 0xb9b4ac, .006 * S0.g / 1.62, center, (r.surf || 1) + .0004);
      r.override = true; r._parent = r.holder.parent; r._q = r.holder.quaternion.clone(); scene.attach(r.holder);
      _site.copy(nrm).multiplyScalar(surf).add(center);
      S0.camT = V(0, 0, 0).copy(path[0]).lerp(_site, .5);
      const a = Engine.anglesFromDir ? Engine.anglesFromDir(nrm) : null;
      Engine.flyTo({ follow: () => S0.camT, radius: 1.2, theta: a ? a.theta + .75 : undefined, phi: a ? clamp(a.phi - .25, .25, 2.9) : undefined, duration: 1.2, body: c.body, minR: .05, maxR: BODIES[c.body].max });
      return S0;
    }
    /* world position for profile state o: rotate the site normal toward the approach direction by the downrange angle */
    function arrivalPos(S, o, out) {
      const ang = o.d * CH / S.surf, ca = Math.cos(ang), sa = Math.sin(ang);
      out.copy(S.nrm).multiplyScalar(ca).addScaledVector(S.fwd, sa);           // local up
      return out.multiplyScalar(S.surf + o.a * CH).add(S.center);
    }
    function emitRing(S, at, up, fwd, n, speed, lift, spread, life, bias) {
      _tmpA.copy(up).cross(fwd).normalize();                                     // side vector
      for (let i = 0; i < n; i++) {
        const a = Math.random() * 6.2832, sp = speed * (.4 + Math.random() * .8), lf = lift * (.5 + Math.random());
        const bx = Math.cos(a) + bias, by = Math.sin(a) * spread;
        S.dust.emit(at.x, at.y, at.z, (fwd.x * bx + _tmpA.x * by) * sp + up.x * lf, (fwd.y * bx + _tmpA.y * by) * sp + up.y * lf, (fwd.z * bx + _tmpA.z * by) * sp + up.z * lf, life * (.6 + Math.random() * .6));
      }
    }
    function updateArrival(dtRaw) {
      // AKICILIK: kare süresi yumuşatılır ve 1/30 s ile sınırlanır; geç gelen bir kare aracı ileri sıçratmaz
      S.dtS = S.dtS === undefined ? Math.min(dtRaw, 1 / 30) : S.dtS + (Math.min(dtRaw, 1 / 30) - S.dtS) * .25;
      const dt = S.dtS;
      S.t += dt; const t = Math.min(S.t, S.dur), o = evalProfile(S.P, t, _o), r = S.r;
      const pos = arrivalPos(S, o, _pos);
      // local frame at the craft: up (_dir) and along-track (_fwdL)
      _dir.copy(pos).sub(S.center).normalize();
      _fwdL.copy(S.fwd).addScaledVector(_dir, -S.fwd.dot(_dir)).normalize();
      _upT.copy(_dir).multiplyScalar(Math.cos(o.tilt)).addScaledVector(_fwdL, Math.sin(o.tilt));
      if (!S.ended) { r.holder.position.copy(pos); r.holder.quaternion.setFromUnitVectors(Y, _upT); }
      S.trail.geometry.setDrawRange(0, Math.max(2, Math.floor(t / S.dur * (N - 1)) + 1));
      // engine plume under the craft (pulsed thrusters flicker), heat glow in front during entry
      const flick = o.pulse ? .55 + .45 * Math.sin(S.t * 60) * Math.sin(S.t * 23) : .9 + .1 * Math.sin(S.t * 40);
      S.head.position.copy(pos).addScaledVector(_upT, -CH * .55); S.head.scale.setScalar(o.eng > .02 && !S.ended ? CH * (1.1 + 2.2 * o.eng) * flick : .0001);
      S.heatSpr.position.copy(pos).addScaledVector(_fwdL, CH * .4); S.heatSpr.scale.setScalar(o.heat > .02 ? CH * (1.5 + 7 * o.heat) : .0001);
      // parachute: opens smoothly, then is released and drifts away
      if (S.chute) {
        if (S.chuteRel < 0 && S.prevChute > .5 && o.chute < S.prevChute - .01) S.chuteRel = S.t;
        if (S.chuteRel < 0) { S.chute.visible = o.chute > .02; S.chute.position.copy(pos).addScaledVector(_dir, CH * .3); S.chute.quaternion.setFromUnitVectors(Y, _dir); S.chute.scale.setScalar(CH * 1.3 * Math.max(.05, o.chute)); }
        else { const k = S.t - S.chuteRel; S.chute.position.addScaledVector(_dir, CH * dt * .9).addScaledVector(_fwdL, CH * dt * 1.4); S.chute.visible = k < 3.5; }
        S.prevChute = o.chute;
      }
      // airbags: inflate around the lander and roll with the bounces
      if (S.bags) {
        S.bags.visible = o.bag > .02; S.bags.position.copy(pos).addScaledVector(_dir, CH * .45);
        const roll = (o.d - (S.prevD === undefined ? o.d : S.prevD)) * CH / (CH * .9); S.prevD = o.d;
        _tmpB.copy(_dir).cross(_fwdL).normalize(); if (roll) S.bags.rotateOnWorldAxis(_tmpB, -roll);
        S.bags.scale.setScalar(CH * 1.15 * Math.max(.05, o.bag));
      }
      // regolith / dust: thrusters at low altitude, puffs at every ground contact
      _ground.copy(_dir).multiplyScalar(S.surf - .0002).add(S.center);
      if (o.eng > .15 && o.a < 3.2 && !S.ended) emitRing(S, _ground, _dir, _fwdL, Math.ceil(5 * o.eng * (1 - o.a / 3.2)), .012 * o.eng, .002, 1, 3, 0);
      if (S.prevA > .03 && o.a <= .03 && !S.ended) emitRing(S, _ground, _dir, _fwdL, S.P.hard || S.P.type === 'impact' ? 70 : 24, S.P.hard ? .014 : .007, S.P.hard ? .006 : .0025, 1, 3, S.P.graze ? 1.2 : 0);
      S.prevA = o.a;
      // LCROSS: the Centaur hits first, the shepherding spacecraft flies through its plume
      if (S.P.centaur && !S.plumeDone && S.t >= S.P.centaur) { S.plumeDone = true; _tmpB.copy(S.nrm).multiplyScalar(S.surf).add(S.center); emitRing(S, _tmpB, S.nrm, S.fwd, 320, .006, .016, 1, 5, 0); }
      if (S.dust) S.dust.step(dt, S.ended && S.t - S.endAt > 1.2);
      // camera: follows between the craft and the landing site, zooming in as it descends
      _site.copy(S.nrm).multiplyScalar(S.surf).add(S.center);
      // kamera: hedef ve uzaklık üstel yumuşatmayla izlenir; sekmelerde kamera sarsılmaz
      _tmpA.copy(_dir).multiplyScalar(S.surf + Math.min(o.a, 6) * CH * .6).add(S.center).lerp(_site, o.a < 4 ? .3 : .45);
      S.camT.lerp(_tmpA, 1 - Math.exp(-dt * 2.2));
      S.camR = S.camR === undefined ? 1.2 : S.camR + (clamp(.17 + o.a * CH * 2.2 + Math.abs(o.d) * CH * .3, .17, 1.5) - S.camR) * (1 - Math.exp(-dt * .9));
      const cam = Engine.cam; if (cam && !cam.anim) cam.radius = S.camR;
      // HUD: real telemetry from the profile
      const metres = o.altM < 10000, alt = metres ? o.altM : o.altM / 1000, vel = metres ? o.vMs : o.vMs / 1000;
      // gösterge saniyede 10 kez güncellenir (her karede HTML yeniden yazmak takılmaya yol açıyordu)
      if (S.t - (S.hudT || -1) > .1 || S.hudPh !== o.ph || S.hudEnd !== S.ended) { S.hudT = S.t; S.hudPh = o.ph; S.hudEnd = S.ended; UI.simHud({ mode: S.mode, alt, vel, unit: metres ? 'm' : 'km', t: S.t, ended: S.ended, outcome: S.outcome, phase: o.ph }); }
      if (!S.ended && S.t >= S.dur) endArrival(pos);
      if (S.ended) { const a = S.t - S.endAt; for (const f of S.fx) f.update(a, dt); if (a > 4.6) stop(); }
    }
    function endArrival(pos) {
      S.ended = true; S.endAt = S.t; S.head.visible = false; S.heatSpr.visible = false;
      const c = S.c, outcome = S.P.type === 'impact' ? 'impact' : (c.outcome === 'lost' ? 'lost' : 'land');
      S.outcome = outcome; Store.set({ simulation: { id: S.id, mode: S.mode, phase: 'end', outcome } });
      if (S.bags) S.bags.visible = false;
      if (outcome === 'impact') {
        // calm ejecta: radial curtain for steep impacts, a down-range fan for grazing ones (no flash, no fireball)
        _ground.copy(_dir).multiplyScalar(S.surf - .0002).add(S.center);
        if (S.P.graze) emitRing(S, _ground, _dir, _fwdL, 300, .016, .004, .35, 4, 1.6);
        else emitRing(S, _ground, _dir, _fwdL, 300, .009, .011, 1, 4.5, 0);
      }
    }
    function start(id) {
      stop(true);
      if (!_pos) { _pos = new THREE.Vector3(); _up = new THREE.Vector3(); _ground = new THREE.Vector3(); _t1 = new THREE.Vector3(); _t2 = new THREE.Vector3(); }
      const r = Engine.crafts[id]; if (!r) return;
      const c = r.c, body = r.body, center = body.center, B = body.B, scene = Engine.scene;
      // Gerçek varış profili olan araçlar (Ay ve Mars inişleri/çarpmaları) anahtar kare sistemiyle canlandırılır
      if ((c.sim === 'impact' || c.sim === 'edl') && PROFILES[c.id]) { S = startArrival(r, c, prepProfile(PROFILES[c.id]), scene); Store.set({ simulation: { id, mode: c.sim, phase: 'run' } }); return; }
      const path = []; let mode = c.sim, dur = 7, endN = null;
      const isMars = c.body === 'MARS';
      if (mode === 'impact' || mode === 'edl') {
        const nrm = r.normal.clone().applyQuaternion(body.mesh.quaternion);
        let side = V(0, 1, 0).cross(nrm); if (side.lengthSq() < 1e-4) side.set(1, 0, 0); side.normalize();
        const sweep = mode === 'edl' ? .9 : .75, rS = mode === 'edl' ? 1.7 : 2.3, sDir = nrm.clone().applyAxisAngle(side, -sweep);
        const q = new THREE.Quaternion().setFromUnitVectors(sDir, nrm), qi = new THREE.Quaternion();
        for (let i = 0; i < N; i++) { const s = i / (N - 1);
          // GÖREV 1.1/1.2 - Ay ve Mars inişleri aynı yumuşak kinematiği kullanır: radyal hız (1-s)^2.6 ve yatay hız (1-s)^2.2 ease-out ile
          // temas anında sıfıra iner; son bölüm yavaş, dikey bir alçalmadır. Yol yerel yüzey yarıçapında biter (clipping/zıplama yok).
          /* landers brake smoothly: radial and horizontal speed both fall to zero at touchdown, the last stretch is a slow vertical descent */
          const ha = mode === 'edl' ? 1 - Math.pow(1 - Math.min(1, s / .85), 2.2) : s, ra = mode === 'edl' ? 1 - Math.pow(1 - s, 2.6) : Math.pow(s, 1.25);
          path.push(sDir.clone().applyQuaternion(qi.clone().slerp(q, ha)).multiplyScalar(lerp(rS, mode === 'edl' ? r.surf + .0006 : r.surf + .001, ra)).add(center)); }
        dur = mode === 'edl' ? 8 : 6.5; endN = nrm;
      } else if (mode === 'decay') {
        const r0 = r.local.length(), n = r.orbit.normal.clone(), d0 = r.local.clone().normalize();
        for (let i = 0; i < N; i++) { const s = i / (N - 1); path.push(d0.clone().applyAxisAngle(n, s * 2.4 * Math.PI * 2).multiplyScalar(lerp(r0, 1.01, Math.pow(s, 1.6))).add(center)); }
        dur = 10; endN = path[N - 1].clone().sub(center).normalize();
      } else if (mode === 'entry') {
        const base = r.path; for (let i = 0; i < N; i++) path.push(Engine.samplePath(base, .55 + i / (N - 1) * .45, V(0, 0, 0)).clone().add(body.group.position));
        dur = 6; endN = path[N - 1].clone().sub(center).normalize();
      } else if (mode === 'flight') {
        const nrm = r.normal.clone().applyQuaternion(body.mesh.quaternion), tan = V(0, 1, 0).cross(nrm).normalize();
        for (let i = 0; i < N; i++) { const s = i / (N - 1), h = Math.sin(Math.PI * clamp(s * 1.15, 0, 1)) * .012, x = smooth(.15, .85, s) * .03; path.push(nrm.clone().multiplyScalar(r.surf + .0006 + h).addScaledVector(tan, x).add(center)); }
        dur = 9; endN = nrm; r.spinRotors = true;
      }
      const posA = new Float32Array(N * 3), colA = new Float32Array(N * 3); path.forEach((p, i) => posA.set([p.x, p.y, p.z], i * 3));
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(posA, 3)); g.setAttribute('color', new THREE.BufferAttribute(colA, 3)); g.setDrawRange(0, 0);
      const trail = new THREE.Line(g, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
      const head = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX.glow, color: 0x9fefff, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, transparent: true }));
      head.scale.setScalar(.06); scene.add(trail, head);
      // move holder to world space for the duration
      r.override = true; r._parent = r.holder.parent; r._q = r.holder.quaternion.clone(); scene.attach(r.holder);
      S = { id, r, c, path, mode, dur, t: 0, surf: (r.surf || 1) + .0006, trail, head, colA, endN, center, B, isMars, ended: false, fx: [], endAt: 0 };
      // Gövdeye özgü yerçekimi: Ay 1.62 m/s², Mars 3.72 m/s² (sahne ölçeğinde görselleştirme için orantılı)
      S.g = B.radiusKm < 2000 ? 1.62 : 3.72;
      if ((mode === 'edl' || mode === 'impact') && endN) S.dust = makeDust(scene, 600, isMars ? 0xc98a62 : 0xb9b4ac, .006 * S.g / 1.62, center, (r.surf || 1) + .0004);
      const camR = mode === 'flight' ? .16 : mode === 'decay' ? Math.max(3.2, r.local.length() * 2.2) : mode === 'entry' ? 4.5 : 3.0;
      Engine.lookAtEvent(endN || V(0, 0, 1), c.body, camR, mode === 'flight' ? path[0].clone() : null);
      Store.set({ simulation: { id, mode, phase: 'run' } });
    }
    // GÖREV 3.4 - Bellek yönetimi: animasyon döngüsünde yeni Vector3/Quaternion üretilmez,
    // aşağıdaki geçici (scratch) nesneler her karede .copy()/.set() ile yeniden kullanılır (çöp toplayıcı takılması olmaz).
    // (THREE sayfa yüklendikten sonra hazır olduğu için nesneler ilk simülasyonda bir kez oluşturulur)
    let _pos, _up, _ground, _t1, _t2;
    /* ---------- regolith / dust particle pool (fixed size, preallocated) ----------
       GÖREV 1.4 - Ay tozu (regolit): itici gazının kaldırdığı toz, sabit boyutlu ve önceden ayrılmış bir parçacık havuzunda
       balistik olarak hareket eder; yerçekimi gövdenin gerçek değeriyle (Ay 1.62, Mars 3.72 m/s²) orantılıdır ve parçacıklar
       zemine çarpınca yüzeye sabitlenir (ground clamping), zıplamaz. */
    function makeDust(scene, n, color, g, center, surf) {
      const pos = new Float32Array(n * 3), vel = new Float32Array(n * 3), life = new Float32Array(n);
      const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); geo.setDrawRange(0, n);
      const mat = new THREE.PointsMaterial({ color, size: 2.0, sizeAttenuation: false, transparent: true, opacity: .6, depthWrite: false, toneMapped: false });
      const pts = new THREE.Points(geo, mat); pts.frustumCulled = false; scene.add(pts);
      for (let i = 0; i < n; i++) { life[i] = 0; pos[i * 3] = center.x; pos[i * 3 + 1] = center.y; pos[i * 3 + 2] = center.z; }
      let head = 0, fade = 1;
      return {
        pts,
        emit(px, py, pz, vx, vy, vz, l) { const i = head; head = (head + 1) % n; pos[i * 3] = px; pos[i * 3 + 1] = py; pos[i * 3 + 2] = pz; vel[i * 3] = vx; vel[i * 3 + 1] = vy; vel[i * 3 + 2] = vz; life[i] = l; },
        step(dt, settle) {
          const drag = Math.exp(-dt * .9);
          for (let i = 0; i < n; i++) {
            if (life[i] <= 0) continue; life[i] -= dt;
            const k = i * 3, dx = pos[k] - center.x, dy = pos[k + 1] - center.y, dz = pos[k + 2] - center.z, d = Math.hypot(dx, dy, dz) || 1;
            vel[k] = vel[k] * drag - dx / d * g * dt; vel[k + 1] = vel[k + 1] * drag - dy / d * g * dt; vel[k + 2] = vel[k + 2] * drag - dz / d * g * dt;
            pos[k] += vel[k] * dt; pos[k + 1] += vel[k + 1] * dt; pos[k + 2] += vel[k + 2] * dt;
            const d2 = Math.hypot(pos[k] - center.x, pos[k + 1] - center.y, pos[k + 2] - center.z);
            if (d2 < surf) { const f = surf / d2; pos[k] = center.x + (pos[k] - center.x) * f; pos[k + 1] = center.y + (pos[k + 1] - center.y) * f; pos[k + 2] = center.z + (pos[k + 2] - center.z) * f; vel[k] *= .2; vel[k + 1] *= .2; vel[k + 2] *= .2; }
          }
          if (settle) fade = Math.max(0, fade - dt / 3.5); mat.opacity = .6 * fade; geo.attributes.position.needsUpdate = true;
        },
        dispose() { scene.remove(pts); geo.dispose(); mat.dispose(); }
      };
    }
    const heatColor = h => [lerp(.5, 1, h), lerp(.9, .5 - h * .2, h), lerp(1, .15, h)];
    function heatAt(R) {
      if (!S) return 0;
      if (S.mode === 'flight') return 0;
      if (!S.isMars) return S.mode === 'impact' ? smooth(1.15, 1.0, R) * .5 : 0;
      if (S.mode === 'edl') return smooth(1.35, 1.06, R) * (1 - smooth(1.06, 1.02, R));
      return smooth(1.12, 1.012, R);
    }
    function update(dt) {
      if (!S) return;
      if (S.P) return updateArrival(dt);
      S.t += dt; const u = clamp(S.t / S.dur, 0, 1);
      const pos = Engine.samplePath(S.path, u, _pos), idx = Math.max(1, Math.floor(u * (N - 1)));
      S.trail.geometry.setDrawRange(0, idx + 1);
      const R = pos.distanceTo(S.center), heat = heatAt(R);
      for (let i = 0; i <= idx; i++) { const h = heatAt(S.path[i].distanceTo(S.center)), f = .25 + .75 * i / idx, col = heatColor(h); S.colA.set([col[0] * f, col[1] * f, col[2] * f], i * 3); }
      S.trail.geometry.attributes.color.needsUpdate = true;
      if (!S.ended) {
        S.r.holder.position.copy(pos); S.head.position.copy(pos);
        // Araç iniş boyunca yerel yüzey normaline dik tutulur (geçici vektör yeniden kullanılır, yeni nesne yok)
        if (S.mode === 'edl') S.r.holder.quaternion.setFromUnitVectors(Y, _up.copy(pos).sub(S.center).normalize());
        // GÖREV 1.4 - Son yaklaşmada iticilerin altındaki regolit: yüzeye ~yaklaştıkça yanal toz akışı artar
        if (S.dust && S.mode === 'edl') {
          const h = R - S.surf, k = clamp(1 - h / .004, 0, 1);
          if (k > 0) {
            _ground.copy(S.endN).multiplyScalar(S.surf - .0002).add(S.center);
            _t1.set(0, 1, 0).cross(S.endN); if (_t1.lengthSq() < 1e-4) _t1.set(1, 0, 0); _t1.normalize(); _t2.copy(S.endN).cross(_t1);
            const m = Math.ceil(6 * k);
            for (let i = 0; i < m; i++) { const a = Math.random() * 6.2832, sp = (.004 + Math.random() * .01) * k, up = .0015 + Math.random() * .002;
              S.dust.emit(_ground.x, _ground.y, _ground.z, (_t1.x * Math.cos(a) + _t2.x * Math.sin(a)) * sp + S.endN.x * up, (_t1.y * Math.cos(a) + _t2.y * Math.sin(a)) * sp + S.endN.y * up, (_t1.z * Math.cos(a) + _t2.z * Math.sin(a)) * sp + S.endN.z * up, 2.5 + Math.random() * 2); }
          }
        }
        const near = 1 - smooth(S.surf + .0045, S.surf + .0008, R);
        const thr = S.mode === 'edl' ? (S.isMars ? smooth(1.035, 1.012, R) : smooth(1.2, 1.01, R)) * .35 * near : 0;
        S.head.scale.setScalar(.05 + heat * .22 + thr * .1); S.head.material.color.setRGB(...(thr > .05 ? [1, .7, .35] : heatColor(heat)));
        if ((S.mode === 'decay' || S.mode === 'entry') && heat > .7) S.r.hidden = true;
      }
      const altKm = Math.max(0, (R - S.surf) * S.B.radiusKm), gm = S.B.gm, rk = R * S.B.radiusKm;
      let vel;
      if (S.mode === 'impact') vel = Math.sqrt(.6 + 2 * gm / rk);
      // GÖREV 1.2 - Son yaklaşma kinematiği: sabit frenleme ivmesiyle v = sqrt(2·a·h); a = itici ivmesi - yerçekimi.
      // Ay'da g = 1.62 m/s², itici net ~2 m/s² frenleme sağlar; hız yüzeyde tam sıfıra iner (ease-out).
      else if (S.mode === 'edl') vel = Math.min(Math.sqrt(gm / rk), Math.sqrt(2 * (S.isMars ? 3.0 : 2.0) * Math.max(0, R - S.surf) * S.B.radiusKm * 1000) / 1000);
      else if (S.mode === 'decay') vel = Math.sqrt(gm / rk);
      else if (S.mode === 'entry') vel = Math.sqrt(2.6 * 2.6 + 2 * gm / rk);
      else vel = 0;
      if (S.mode === 'flight') {
        // the scene exaggerates the hop for visibility; report realistic Ingenuity figures (about 12 m up, a few m/s)
        const hopM = Math.max(0, R - S.surf) / .012 * 12, horiz = 4.5 * Math.sin(Math.PI * smooth(.15, .85, u));
        UI.simHud({ mode: S.mode, alt: hopM, vel: horiz, unit: 'm', t: S.t, ended: S.ended, outcome: S.outcome });
      } else UI.simHud({ mode: S.mode, alt: altKm, vel, unit: 'km', t: S.t, ended: S.ended, outcome: S.outcome });
      if (u >= 1 && !S.ended) end();
      if (S.dust) S.dust.step(dt, S.ended);
      if (S.ended) { const a = S.t - S.endAt; for (const f of S.fx) f.update(a, dt); if (a > 4.2) stop(); }
    }
    function end() {
      S.ended = true; S.endAt = S.t;
      const p = S.path[S.path.length - 1], m = S.mode, c = S.c, scene = Engine.scene;
      const outcome = m === 'impact' ? 'impact' : m === 'decay' ? 'burn' : m === 'entry' ? 'lost' : m === 'flight' ? 'flight' : (c.outcome === 'lost' ? 'lost' : 'land');
      S.outcome = outcome; S.r.spinRotors = false;
      Store.set({ simulation: { id: S.id, mode: m, phase: 'end', outcome } });
      if (outcome === 'flight') return;
      /* every lander touches down intact: no flash, no shock ring, only a low drifting dust skirt; the craft stays on the surface */
      if (m === 'edl') {
        S.head.visible = false;
        const n = 46, pos = new Float32Array(n * 3), vel = [], nrm = S.endN.clone();
        let t1 = V(0, 1, 0).cross(nrm); if (t1.lengthSq() < 1e-4) t1.set(1, 0, 0); t1.normalize(); const t2 = nrm.clone().cross(t1);
        for (let i = 0; i < n; i++) { pos.set([p.x, p.y, p.z], i * 3); const a = i / n * Math.PI * 2 + Math.random() * .3; vel.push(t1.clone().multiplyScalar(Math.cos(a)).addScaledVector(t2, Math.sin(a)).addScaledVector(nrm, .15 + Math.random() * .15).multiplyScalar(.006 + Math.random() * .006)); }
        const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        const pts = new THREE.Points(g, new THREE.PointsMaterial({ color: S.isMars ? 0xc98a62 : 0xb9b4ac, size: 2.0, sizeAttenuation: false, transparent: true, opacity: .55, depthWrite: false, toneMapped: false }));
        scene.add(pts);
        S.fx.push({ obj: pts, update(a, dt) { const arr = g.attributes.position.array; const drag = Math.exp(-dt * 1.6); for (let i = 0; i < n; i++) { const v = vel[i]; v.multiplyScalar(drag); arr[i * 3] += v.x * dt; arr[i * 3 + 1] += v.y * dt; arr[i * 3 + 2] += v.z * dt; } g.attributes.position.needsUpdate = true; pts.material.opacity = .55 * Math.max(0, 1 - a / 3.5); } });
        return;
      }
      // GÖREV 1.4 - Çarpma: parlama, şok halkası ve patlama parçacıkları kaldırıldı. Yerine yerçekimiyle yükselip geri düşen,
      // zemine sabitlenen sakin bir regolit perdesi (ejecta) var; araç parçalanmış gibi gösterilmez.
      if (m === 'impact' && S.dust) {
        S.head.visible = false; const nrm = S.endN;
        _t1.set(0, 1, 0).cross(nrm); if (_t1.lengthSq() < 1e-4) _t1.set(1, 0, 0); _t1.normalize(); _t2.copy(nrm).cross(_t1);
        _ground.copy(nrm).multiplyScalar(S.surf - .0002).add(S.center);
        for (let i = 0; i < 260; i++) { const a = Math.random() * 6.2832, sp = .004 + Math.random() * .012, up = .006 + Math.random() * .01;
          S.dust.emit(_ground.x, _ground.y, _ground.z, (_t1.x * Math.cos(a) + _t2.x * Math.sin(a)) * sp + nrm.x * up, (_t1.y * Math.cos(a) + _t2.y * Math.sin(a)) * sp + nrm.y * up, (_t1.z * Math.cos(a) + _t2.z * Math.sin(a)) * sp + nrm.z * up, 3 + Math.random() * 2); }
        return;
      }
      const big = outcome === 'burn';
      const fl = new THREE.Sprite(new THREE.SpriteMaterial({ map: TEX.glow, color: outcome === 'land' ? 0xbfefff : 0xffe2b0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, transparent: true }));
      fl.position.copy(p); scene.add(fl);
      S.fx.push({ obj: fl, update(a) { const k = Math.max(0, 1 - a / (big ? 1.4 : .8)); fl.material.opacity = k; fl.scale.setScalar((big ? .8 : .22) * (.3 + a * 1.4)); } });
      if (outcome !== 'burn') {
        const rg = mesh(new THREE.RingGeometry(.9, 1, 64), new THREE.MeshBasicMaterial({ color: outcome === 'land' ? 0x7fd6ff : 0xffd27a, transparent: true, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
        rg.position.copy(S.endN).multiplyScalar(1.004).add(S.center); rg.quaternion.setFromUnitVectors(V(0, 0, 1), S.endN); scene.add(rg);
        S.fx.push({ obj: rg, update(a) { rg.material.opacity = Math.max(0, 1 - a / 2.6); rg.scale.setScalar(.01 + a * (big ? .16 : .05)); } });
      }
      const n = outcome === 'land' ? 60 : 420, pos = new Float32Array(n * 3), vel = [], nrm = S.endN.clone();
      for (let i = 0; i < n; i++) {
        pos.set([p.x, p.y, p.z], i * 3);
        const rnd = V(Math.random() - .5, Math.random() - .5, Math.random() - .5).normalize();
        vel.push(outcome === 'burn' || outcome === 'lost' ? rnd.multiplyScalar(.04 + Math.random() * .08).addScaledVector(S.path[S.path.length - 1].clone().sub(S.path[S.path.length - 3]).normalize(), .12) : rnd.addScaledVector(nrm, 1.3).normalize().multiplyScalar((outcome === 'land' ? .04 : .12) * (.3 + Math.random())));
      }
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const pts = new THREE.Points(g, new THREE.PointsMaterial({ color: outcome === 'land' ? 0xd9a07a : 0xffc070, size: 2.2, sizeAttenuation: false, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
      scene.add(pts);
      S.fx.push({ obj: pts, update(a, dt) {
        const arr = g.attributes.position.array;
        for (let i = 0; i < n; i++) { const v = vel[i], px = arr[i * 3] - S.center.x, py = arr[i * 3 + 1] - S.center.y, pz = arr[i * 3 + 2] - S.center.z, d = Math.hypot(px, py, pz) || 1; if (d < 1.002) continue; v.x -= px / d * .12 * dt; v.y -= py / d * .12 * dt; v.z -= pz / d * .12 * dt; arr[i * 3] += v.x * dt; arr[i * 3 + 1] += v.y * dt; arr[i * 3 + 2] += v.z * dt; }
        g.attributes.position.needsUpdate = true; pts.material.opacity = Math.max(0, 1 - a / 4);
      } });
      if (big || outcome === 'lost') S.r.hidden = true; // yörüngeden düşüş / atmosferde yanma (Mars orbiterları) için
    }
    function stop(silent) {
      if (!S) return; const scene = Engine.scene, r = S.r;
      scene.remove(S.trail, S.head); if (S.heatSpr) scene.remove(S.heatSpr); if (S.extra) S.extra.forEach(o => scene.remove(o)); S.trail.geometry.dispose(); S.fx.forEach(f => scene.remove(f.obj)); if (S.dust) S.dust.dispose();
      if (r._parent) { r._parent.attach(r.holder); r.holder.quaternion.copy(r._q); }
      if (r.c.approach) r.holder.position.copy(r.local);
      r.override = false; r.hidden = false; r.spinRotors = false; S = null;
      if (!silent) Store.set({ simulation: null });
    }
    return { start, update, stop, get active() { return S; } };
  })();

  /* =================================================================
     MODEL INSPECTOR (second renderer inside the panel)
     ================================================================= */
  const Inspector = (() => {
    let renderer, scene, camera, holder, current = null, wrap, rot = 0, model = null;
    function init() {
      wrap = $('#inspWrap');
      renderer = new THREE.WebGLRenderer({ canvas: $('#inspector'), antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2)); renderer.outputEncoding = THREE.sRGBEncoding; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.1;
      scene = new THREE.Scene();
      camera = new THREE.PerspectiveCamera(30, 2, .4, 12); camera.position.set(1.7, 1.0, 2.2); camera.lookAt(0, .35, 0);
      const l = new THREE.DirectionalLight(0xfff2e0, 2.6); l.position.set(3, 4, 2); scene.add(l); const fl = new THREE.DirectionalLight(0xbcd6ff, 1.1); fl.position.set(-3, 1.5, 2.5); scene.add(fl); const rim = new THREE.DirectionalLight(0xffe2c4, 1.2); rim.position.set(-1, 2, -3.5); scene.add(rim); scene.add(new THREE.HemisphereLight(0xdde8ff, 0x3a3028, .9)); scene.add(new THREE.AmbientLight(0xffffff, .35));
      const grid = mesh(new THREE.RingGeometry(.66, .68, 64), new THREE.MeshBasicMaterial({ color: 0x7fd6ff, transparent: true, opacity: .35, side: THREE.DoubleSide })); grid.rotation.x = -Math.PI / 2; scene.add(grid);
      const disc = mesh(new THREE.CircleGeometry(.66, 48), new THREE.MeshBasicMaterial({ color: 0x0b1320, transparent: true, opacity: .5 })); disc.rotation.x = -Math.PI / 2; disc.position.y = -.001; scene.add(disc);
      holder = new THREE.Group(); scene.add(holder);
    }
    function loadFile(f) { const id = Store.get().activeSpacecraftId; if (!id) return; $('#inspCap').textContent = '...'; AssetHooks.loadFromFile(id, f).catch(err => { $('#inspCap').textContent = String(err.message || err).slice(0, 60); }); }
    function show(id) {
      if (!renderer) return;
      while (holder.children.length) holder.remove(holder.children[0]);
      current = id; model = null; if (!id) return;
      const r = Engine.crafts[id];
      model = r.makeModel ? r.makeModel() : r.fromFile ? normalizeModel(r.model.clone(true), 1) : buildModel(r.c.model, r.c.variant);
      holder.add(model);
      $('#inspCap').textContent = r.makeModel ? 'NASA 3D / ' + r.c.model.toUpperCase() : r.fromFile ? t('inspectorFile') : t('inspector') + ' / ' + r.c.model.toUpperCase();
    }
    function render(dt) {
      if (!renderer || !current || !Store.get().activeSpacecraftId) return;
      if (document.hidden) return;
      if (!render.ro) { render.sz = [wrap.clientWidth, wrap.clientHeight]; render.vis = true; render.ro = new ResizeObserver(e => { const r2 = e[0].contentRect; render.sz = [r2.width, r2.height]; }); render.ro.observe(wrap);
        if (window.IntersectionObserver) new IntersectionObserver(e => { render.vis = e[0].isIntersecting; }).observe(wrap); }
      const w = render.sz[0], h = render.sz[1]; if (!w || !h || !render.vis) return;
      if (renderer.domElement.width !== Math.floor(w * renderer.getPixelRatio())) { renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }
      rot += dt * .45; holder.rotation.y = rot;
      if (model && model.userData.rotors) model.userData.rotors.forEach((r, i) => r.rotation.y += dt * (i ? -3 : 3));
      renderer.render(scene, camera);
    }
    return { init, show, render };
  })();

  /* =================================================================
     PHASE 4 / 5 - USER INTERFACE
     ================================================================= */
  const UI = (() => {
    const body = document.body;
    const ICON_PLAY = '<svg class="i" viewBox="0 0 16 16"><path d="M5 3l8 5-8 5z"/></svg>';
    const ICON_PAUSE = '<svg class="i" viewBox="0 0 16 16"><path d="M5 3v10M11 3v10"/></svg>';
    const CLOSE = '<svg class="i" viewBox="0 0 16 16"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
    let playTimer = null;

    function applyStatic() {
      document.documentElement.lang = L.HTML_LANG[lang()];
      document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
      document.title = t('appTitle') + ' / NASA Space Apps';
      $('#search').placeholder = t('search');
      $('#langCur').textContent = lang() + ' / ' + L.NATIVE[lang()];
      $('#langMenu').innerHTML = L.LANGS.map(k => `<button role="menuitemradio" data-lang="${k}" class="${k === lang() ? 'on' : ''}">${L.NATIVE[k]}<span>${k}</span></button>`).join('');
      $('#ldLangs').innerHTML = L.LANGS.map(k => `<button class="chip${k === lang() ? ' on' : ''}" data-lang="${k}">${L.NATIVE[k]}</button>`).join('');
      Loader.relabel();
    }
    const bodyList = key => CRAFT.filter(c => c.body === key);
    function worldNav() {
      const s = Store.get();
      document.querySelectorAll('.world').forEach(b => b.classList.toggle('on', b.dataset.body === s.selectedCelestialBody));
      ['MOON', 'MARS'].forEach(k => { $('#wn' + k).textContent = bodyList(k).filter(c => s.timelineYear >= c.arriveYear).length + ' / ' + bodyList(k).length; });
    }

    /* ---------- catalog ---------- */
    function matches(c, q) {
      if (!q) return true; q = q.toLowerCase();
      return [c.code, c.agency, c.site, ...Object.values(c.name)].some(v => String(v).toLowerCase().includes(q));
    }
    function renderChips() {
      const s = Store.get(), cats = CATS.filter(c => c.body === s.selectedCelestialBody);
      $('#catChips').innerHTML = `<button class="chip${s.catFilter === 'all' ? ' on' : ''}" data-cat="all">${t('all')}</button>` + cats.map(c => `<button class="chip${s.catFilter === c.id ? ' on' : ''}" data-cat="${c.id}">${t(c.key)}</button>`).join('');
    }
    function renderCatalog() {
      const s = Store.get(), y = s.timelineYear;
      let html = '', n = 0;
      for (const cat of CATS.filter(c => c.body === s.selectedCelestialBody && (s.catFilter === 'all' || s.catFilter === c.id))) {
        const list = CRAFT.filter(c => c.cat === cat.id && matches(c, s.search)); if (!list.length) continue;
        html += `<div class="cat-h"><span>${t(cat.key)}</span><span>${list.length}</span></div>`;
        for (const c of list) {
          n++; const st = craftStatus(c, y);
          html += `<button class="item${s.activeSpacecraftId === c.id ? ' on' : ''}${y < c.arriveYear ? ' future' : ''}" data-id="${c.id}">
            <span class="code">${c.code}</span><span><span class="nm">${esc(craftName(c))}</span><span class="meta">${c.arriveYear} / ${esc(c.agency)}</span></span>
            <span class="dot ${st.cls}" title="${esc(t(st.key))}"></span></button>`;
        }
      }
      $('#catList').innerHTML = html || `<p class="empty">${t('noResults')}</p>`;
      const all = bodyList(s.selectedCelestialBody);
      $('#catCount').textContent = String(all.filter(c => y >= c.arriveYear).length).padStart(2, '0') + ' / ' + all.length;
    }

    /* ---------- panel ---------- */
    function renderPanel() {
      const s = Store.get(), c = BYID[s.activeSpacecraftId];
      body.classList.toggle('craft-mode', !!c);
      $('#inspWrap').style.display = c ? '' : 'none';
      $('#pActions').style.display = c ? '' : 'none';
      if (!c) { renderBodyOverview(); return; }
      const st = craftStatus(c, s.timelineYear), cat = CATS.find(k => k.id === c.cat), x = ctx(c);
      $('#pHead').innerHTML = `<div class="p-head" style="position:relative">
        <button class="icon-btn p-close" id="pClose" aria-label="${esc(t('close'))}">${CLOSE}</button>
        <div class="p-meta"><span class="tag">${c.code}</span><span>${esc(t(cat.key))}</span></div>
        <h2>${esc(craftName(c))}</h2><span class="pill ${st.cls}">${esc(t(st.key))}</span></div>`;
      const tab = s.panelTab;
      let tb = `<div class="tabs" role="tablist">${['overview', 'history', 'sources'].map(k => `<button role="tab" data-tab="${k}" class="${tab === k ? 'on' : ''}">${t('tab' + k[0].toUpperCase() + k.slice(1))}</button>`).join('')}</div><div class="tab">`;
      if (tab === 'overview') {
        tb += `<div class="f f2"><div><label>${t('launch')}</label><div class="num">${fmtDate(c.launch)}</div></div><div><label>${t('arrival')}</label><div class="num">${fmtDate(c.arrive)}</div></div></div>
          <div class="f f2"><div><label>${t('endDate')}</label><div class="num">${fmtDate(c.end)}</div></div><div><label>${t('agency')}</label><div class="num">${esc(c.agency)}</div></div></div>
          <div class="f"><label>${t('location')}</label><div class="num">${esc(locStr(c))}</div></div>
          <div class="f"><label>${t('cause')}</label><div>${esc(x[0])}</div></div>
          <div class="f"><label>${t('significance')}</label><div>${esc(x[1])}</div></div>`;
      } else if (tab === 'history') {
        tb += `<ol class="chron">${c.hd.map((d, i) => `<li class="${+d.slice(0, 4) > s.timelineYear ? 'future' : ''}"><time>${fmtDate(d)}</time><p>${esc(x[2 + i] || '')}</p></li>`).join('')}</ol>`;
      } else {
        tb += `<div class="src">
          <a href="https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=${c.nssdc}" target="_blank" rel="noopener"><b>${t('nssdca')}</b><span>${c.nssdc}</span></a>
          <a href="https://en.wikipedia.org/wiki/${c.wiki}" target="_blank" rel="noopener"><b>${t('wiki')}</b><span>en.wikipedia.org/wiki/${esc(c.wiki)}</span></a>
        </div><p class="note">${t('modelNote')} ${t('idNote')}</p>`;
      }
      tb += '</div>';
      $('#pBody').innerHTML = tb;
      const simKey = 'sim_' + c.sim;
      $('#simMode').textContent = t(simKey);
      $('#simBtn').disabled = s.timelineYear < c.arriveYear || !!s.simulation || !Store.get().booted;
    }
    function renderBodyOverview() {
      const s = Store.get(), key = s.selectedCelestialBody, B = BODIES[key], list = bodyList(key), y = s.timelineYear;
      const vis = list.filter(c => y >= c.arriveYear);
      const first = list.reduce((a, c) => c.arriveYear < a.arriveYear ? c : a, list[0]);
      const last = (vis.length ? vis : list).reduce((a, c) => c.end > a.end ? c : a, (vis.length ? vis : list)[0]);
      $('#pHead').innerHTML = '';
      const dos = DOSS.filter(d => d.body === key);
      $('#pBody').innerHTML = `<div class="bo">
        <div class="bo-kicker">${key === 'MOON' ? 'LUNA / SELENE' : 'MARS / ARES'}</div>
        <h2>${t(key === 'MOON' ? 'moon' : 'mars')}</h2><div class="sub">${t(key === 'MOON' ? 'moonSub' : 'marsSub')}</div>
        <p class="intro">${t(key === 'MOON' ? 'bodyIntroMoon' : 'bodyIntroMars')}</p>
        <div class="stats">
          <div><label>${t('radius')}</label><b>${B.stats.radius}</b></div><div><label>${t('gravity')}</label><b>${B.stats.gravity}</b></div>
          <div><label>${t('distEarth')}</label><b>${B.stats.dist}</b></div><div><label>${t('dayLength')}</label><b>${B.stats.day}</b></div>
          <div><label>${t('artifacts')}</label><b>${vis.length} / ${list.length}</b><small>${t('year')} ${y}</small></div>
          <div><label>${t('firstArrival')}</label><b>${first.arriveYear}</b><small>${esc(craftName(first))}</small></div>
          <div style="grid-column:span 2"><label>${t('lastSilence')}</label><b>${fmtDate(last.end)}</b><small>${esc(craftName(last))}</small></div>
        </div>
        <div class="sec-t">${t('discover')}</div>
        <div class="dos-mini">${dos.map(d => { const x = d.tx[lang()] || d.tx.EN; return `<button data-dos="${d.id}"><b>${esc(x[0])}</b><span>${esc(x[1])}</span></button>`; }).join('')}</div>
        <p class="note">${t('countNote')}</p></div>`;
    }

    /* ---------- timeline ---------- */
    function drawHist() {
      const cv = $('#tlHist'), d = Math.min(devicePixelRatio || 1, 2), w = cv.clientWidth, h = cv.clientHeight; if (!w) return;
      cv.width = w * d; cv.height = h * d; const g = cv.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0);
      const s = Store.get(), y = s.timelineYear, list = bodyList(s.selectedCelestialBody), x0 = 1957, x1 = 2026, X = v => (v - x0) / (x1 - x0) * w;
      const css = getComputedStyle(body), acc = css.getPropertyValue('--accent-rgb').trim(), warm = css.getPropertyValue('--warm-rgb').trim();
      const max = list.length;
      for (let yr = x0; yr <= x1; yr++) {
        const cnt = list.filter(c => c.arriveYear <= yr).length, bh = cnt / max * (h - 8), bx = X(yr), bw = Math.max(1, w / (x1 - x0) - 1.5);
        g.fillStyle = yr <= y ? `rgba(${acc},${.18 + .5 * (cnt / max)})` : 'rgba(140,160,180,.10)'; g.fillRect(bx, h - bh, bw, bh);
      }
      list.forEach(c => { g.fillStyle = c.arriveYear <= y ? `rgba(${c.status === 'lost' ? '255,106,85' : warm},.95)` : 'rgba(140,160,180,.35)'; g.beginPath(); g.arc(X(c.arriveYear) + 2, 4, 2.2, 0, 6.3); g.fill(); });
    }
    function renderTimeline() {
      const s = Store.get(), y = s.timelineYear;
      $('#yearOut').textContent = y; $('#yearRange').value = y;
      $('#cntLabel').textContent = t('artifactsOn') + ' / ' + t(s.selectedCelestialBody === 'MOON' ? 'moon' : 'mars');
      $('#cntOut').textContent = bodyList(s.selectedCelestialBody).filter(c => y >= c.arriveYear).length;
      drawHist();
    }
    function setPlaying(on) {
      clearInterval(playTimer); $('#playBtn').innerHTML = on ? ICON_PAUSE : ICON_PLAY; $('#playBtn').setAttribute('aria-label', on ? t('pause') : t('play'));
      if (on) {
        if (Store.get().timelineYear >= 2026) Store.set({ timelineYear: 1957 });
        playTimer = setInterval(() => { const y = Store.get().timelineYear; if (y >= 2026) { Store.set({ timelinePlaying: false }); return; } Store.set({ timelineYear: y + 1 }); }, 240);
      }
    }

    /* ---------- modals ---------- */
    function renderBib() {
      let h = `<div class="prov">${['nssdc.gsfc.nasa.gov', 'science.nasa.gov', 'ssd.jpl.nasa.gov', 'en.wikipedia.org'].map(d => `<a href="https://${d}" target="_blank" rel="noopener">${d}</a>`).join('')}</div>`;
      for (const key of ['MOON', 'MARS']) for (const cat of CATS.filter(c => c.body === key)) {
        h += `<section class="m-sec"><h4><span>${t(key === 'MOON' ? 'moon' : 'mars')}</span><span>${t(cat.key)}</span></h4><div class="ref-grid">`;
        for (const c of CRAFT.filter(x => x.cat === cat.id)) {
          h += `<article class="ref"><h5><span>${c.code}</span>${esc(craftName(c))}</h5><ol>
            <li><b>${t('nssdca')}</b><a href="https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=${c.nssdc}" target="_blank" rel="noopener">${c.nssdc}</a></li>
            <li><b>${t('wiki')}</b><a href="https://en.wikipedia.org/wiki/${c.wiki}" target="_blank" rel="noopener">wiki/${esc(c.wiki)}</a></li></ol></article>`;
        }
        h += '</div></section>';
      }
      h += `<section class="m-sec"><p class="note">${t('idNote')} ${t('modelNote')}</p></section>`;
      $('#bibBody').innerHTML = h;
    }
    function renderDossiers() {
      const s = Store.get(), key = s.selectedCelestialBody, list = [...DOSS.filter(d => d.body === key), ...DOSS.filter(d => d.body !== key)];
      $('#dosBody').innerHTML = `<div class="dos-grid">${list.map(d => {
        const x = d.tx[lang()] || d.tx.EN;
        return `<article class="dos${s.dossierOpen === d.id ? ' hl' : ''}" id="dos-${d.id}"><div class="bt">${t(d.body === 'MOON' ? 'moon' : 'mars')}</div><h4>${esc(x[0])}</h4><p>${esc(x[1])}</p>
          <div class="rel">${d.craft.map(id => `<button data-craft="${id}">${BYID[id].code} / ${esc(craftName(BYID[id]))}</button>`).join('')}</div>
          <div class="lk">${d.links.map(([n, u]) => `<a href="${u}" target="_blank" rel="noopener">${n}: ${esc(u.split('/wiki/')[1] || u)}</a>`).join('')}</div></article>`;
      }).join('')}</div>`;
    }

    /* ---------- actions ---------- */
    function selectCraft(id) {
      const c = BYID[id]; if (!c) return;
      if (Sim.active) Sim.stop();
      const s = Store.get();
      if (c.body !== s.selectedCelestialBody) Transit.show(c.body);
      Store.set({ activeSpacecraftId: id, selectedCelestialBody: c.body, panelTab: s.activeSpacecraftId === id ? s.panelTab : 'overview', dossierOpen: null, bibliographyModalOpen: false });
      body.classList.remove('cat-open'); body.classList.add('panel-open');
    }
    function selectBody(key) {
      if (Sim.active) Sim.stop();
      const s = Store.get();
      if (s.selectedCelestialBody === key && !s.activeSpacecraftId) { Engine.focusBody(key); return; }
      if (s.selectedCelestialBody !== key) Transit.show(key);
      Store.set({ selectedCelestialBody: key, activeSpacecraftId: null, catFilter: 'all' });
    }
    function simHud(d) {
      const el = $('#simHud'); if (!d) { el.hidden = true; return; } el.hidden = false;
      const end = d.ended && d.outcome ? `<span class="end">${t('simEnd_' + d.outcome)}</span>` : `<span>${d.phase ? t('ph_' + d.phase) : t('simRunning')}</span>`;
      el.innerHTML = `<span class="mode">${t('sim_' + d.mode)}</span><span>${t('alt')} <b>${fmtNum(d.alt, d.unit === 'm' ? 1 : 0)}</b> ${d.unit}</span><span>${t('vel')} <b>${fmtNum(d.vel, d.unit === 'm' ? 1 : 3)}</b> ${d.unit}/s</span><span>T+ <b>${d.t.toFixed(1)}</b> s</span>${end}`;
    }
    function readouts(km) {
      $('#roClock').textContent = new Date().toISOString().slice(0, 19).replace('T', ' ');
      $('#roRange').textContent = fmtNum(km, 0) + ' km';
      $('#roBody').textContent = t(Store.get().selectedCelestialBody === 'MOON' ? 'moon' : 'mars').toUpperCase();
    }

    function onState(s, p) {
      if (changed(s, p, 'activeLanguage')) {
        try { localStorage.setItem('abnf-lang', s.activeLanguage); } catch (e) { /* ignore */ }
        applyStatic(); renderChips(); renderCatalog(); renderPanel(); renderTimeline(); renderBib(); renderDossiers(); worldNav();
        if (s.activeSpacecraftId) Inspector.show(s.activeSpacecraftId);
        $('#playBtn').setAttribute('aria-label', s.timelinePlaying ? t('pause') : t('play'));
      }
      if (changed(s, p, 'selectedCelestialBody')) {
        setTimeout(() => { body.dataset.theme = BODIES[s.selectedCelestialBody].theme; drawHist(); }, Store.get().booted ? 350 : 0);
        renderChips(); renderCatalog(); renderPanel(); renderTimeline(); worldNav();
      }
      if (changed(s, p, 'activeSpacecraftId')) { renderCatalog(); renderPanel(); Inspector.show(s.activeSpacecraftId); if (!s.activeSpacecraftId) body.classList.remove('panel-open'); }
      if (changed(s, p, 'panelTab')) renderPanel();
      if (changed(s, p, 'catFilter') || changed(s, p, 'search')) { renderChips(); renderCatalog(); }
      if (changed(s, p, 'timelineYear')) { renderTimeline(); renderCatalog(); renderPanel(); worldNav(); }
      if (changed(s, p, 'timelinePlaying')) setPlaying(s.timelinePlaying);
      if (changed(s, p, 'simulation')) { if (!s.simulation) simHud(null); if (s.activeSpacecraftId) $('#simBtn').disabled = !!s.simulation; }
      if (changed(s, p, 'bibliographyModalOpen')) $('#bibModal').classList.toggle('on', s.bibliographyModalOpen);
      if (changed(s, p, 'dossierOpen')) {
        $('#dosModal').classList.toggle('on', s.dossierOpen !== null); renderDossiers();
        if (s.dossierOpen && s.dossierOpen !== true) setTimeout(() => { const el = $('#dos-' + s.dossierOpen); if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 80);
      }
      if (changed(s, p, 'booted') && s.booted) { body.classList.add('ready'); renderPanel(); }
    }

    function init() {
      applyStatic(); worldNav(); renderChips(); renderCatalog(); renderPanel(); renderTimeline(); renderBib(); renderDossiers();
      $('#playBtn').innerHTML = ICON_PLAY;
      $('#catList').addEventListener('click', e => { const b = e.target.closest('.item'); if (b) selectCraft(b.dataset.id); });
      $('#catChips').addEventListener('click', e => { const b = e.target.closest('[data-cat]'); if (b) Store.set({ catFilter: b.dataset.cat }); });
      $('#search').addEventListener('input', e => Store.set({ search: e.target.value.trim() }));
      $('#worldNav').addEventListener('click', e => { const b = e.target.closest('.world'); if (b) selectBody(b.dataset.body); });
      $('#panel').addEventListener('click', e => {
        if (e.target.closest('#pClose')) { if (Sim.active) Sim.stop(); Store.set({ activeSpacecraftId: null }); return; }
        const tb = e.target.closest('[data-tab]'); if (tb) { Store.set({ panelTab: tb.dataset.tab }); return; }
        const d = e.target.closest('[data-dos]'); if (d) Store.set({ dossierOpen: d.dataset.dos });
      });
      $('#simBtn').addEventListener('click', () => { const id = Store.get().activeSpacecraftId; if (id && Engine.ready) Sim.start(id); });
      $('#yearRange').addEventListener('input', e => Store.set({ timelineYear: +e.target.value, timelinePlaying: false }));
      $('#playBtn').addEventListener('click', () => Store.set({ timelinePlaying: !Store.get().timelinePlaying }));
      $('#attrib').addEventListener('click', () => Store.set({ bibliographyModalOpen: true }));
      $('#btnSources').addEventListener('click', () => Store.set({ bibliographyModalOpen: true }));
      $('#btnDiscover').addEventListener('click', () => Store.set({ dossierOpen: true }));
      document.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', () => Store.set(b.dataset.close === 'bib' ? { bibliographyModalOpen: false } : { dossierOpen: null })));
      ['bibModal', 'dosModal'].forEach(id => $('#' + id).addEventListener('click', e => { if (e.target.id === id) Store.set(id === 'bibModal' ? { bibliographyModalOpen: false } : { dossierOpen: null }); }));
      $('#dosBody').addEventListener('click', e => { const b = e.target.closest('[data-craft]'); if (b) selectCraft(b.dataset.craft); });
      $('#btnLang').addEventListener('click', e => { e.stopPropagation(); $('#langMenu').classList.toggle('on'); });
      $('#langMenu').addEventListener('click', e => { const b = e.target.closest('[data-lang]'); if (b) { Store.set({ activeLanguage: b.dataset.lang }); $('#langMenu').classList.remove('on'); } });
      $('#ldLangs').addEventListener('click', e => { const b = e.target.closest('[data-lang]'); if (b) Store.set({ activeLanguage: b.dataset.lang }); });
      document.addEventListener('click', () => $('#langMenu').classList.remove('on'));
      $('#catToggle').addEventListener('click', () => body.classList.toggle('cat-open'));
      addEventListener('keydown', e => {
        if (e.target.tagName === 'INPUT') return;
        const s = Store.get();
        if (e.key === 'Escape') { if (s.bibliographyModalOpen) Store.set({ bibliographyModalOpen: false }); else if (s.dossierOpen) Store.set({ dossierOpen: null }); else if (s.activeSpacecraftId) { if (Sim.active) Sim.stop(); Store.set({ activeSpacecraftId: null }); } }
        if (!s.booted || s.bibliographyModalOpen || s.dossierOpen) return;
        if (e.key === '1') selectBody('MOON'); if (e.key === '2') selectBody('MARS');
      });
      addEventListener('resize', drawHist);
      Store.subscribe(onState);
    }
    return { init, selectCraft, selectBody, simHud, readouts };
  })();

  /* =================================================================
     BOOT - real loading stages drive the 3D loader
     ================================================================= */
  const THREE_URL = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
  (async function boot() {
    UI.init(); Loader.start(); Loader.setReal(6, 'ldEngine');
    try { await loadScript(THREE_URL); } catch (e) { Loader.error('Three.js could not be loaded from cdnjs.cloudflare.com. Check the connection and reload.'); return; }
    Loader.setReal(22, 'ldTerrain'); await nextFrame();
    try {
      buildMaterials(); Engine.initRenderer(); Engine.buildSky(); Engine.buildBodies(); Engine.setupLoader();
      Engine.start(); Loader.ready3d(); Loader.setReal(42); await nextFrame();
      Loader.setReal(48, 'ldModels'); await nextFrame();
      Engine.buildCrafts(); Loader.setReal(72); await nextFrame();
      Engine.buildLabels(); Engine.bindControls(); Loader.setReal(82, 'ldCatalog'); await nextFrame();
      Inspector.init(); Engine.compile(); Loader.setReal(100, 'ldReady');
      window.__eng = Engine; window.__insp = Inspector; window.__st = Store; setTimeout(() => NasaModels.loadAll(), 1500); // (TR) NASA modelleri arka planda yüklenir
    } catch (e) { console.error(e); Loader.error('WebGL initialisation failed: ' + (e.message || e)); }
  })();

  window.ABNF = { Store, DATA: D, I18N: L, AssetHooks, ModelRepositories, Engine, Sim };
})();

/* =====================================================================
   YAPILAN OPTİMİZASYONLAR VE FİZİK İYİLEŞTİRMELERİ (jüri özeti)
   1. Fizik: Ay ve Mars inişleri tek bir kinematik modelle çalışır; hız ease-out ile
      temas anında sıfıra iner, telemetri v = sqrt(2·a·h) ile gerçek yerçekimine
      (Ay 1.62, Mars 3.72 m/s²) göre hesaplanır. Patlama efektleri kaldırıldı; itici
      gazının kaldırdığı regolit tozu balistik olarak uçar ve zemine sabitlenir.
   2. Görüntü kararlılığı: dinamik near düzlemi, yüzey ayrıntılarında polygonOffset,
      sınır küresinden hesaplanan kamera minimum mesafesi ve tek parça birleştirilmiş
      modeller sayesinde yakınlaştırmada z-fighting, titreme ve iç içe geçme oluşmaz.
   3. Performans: her uydu malzeme başına tek geometriye birleştirildi (~270 çizim
      çağrısı), Mars kabartması yüklemede bir kez hesaplanır, pixel ratio 2 ile
      sınırlı, animasyon döngüsünde yeni nesne üretilmez ve gölge haritası yerine
      shader içi aydınlatma kullanılır; poligon ve doku detayı düşürülmedi.
   ===================================================================== */
