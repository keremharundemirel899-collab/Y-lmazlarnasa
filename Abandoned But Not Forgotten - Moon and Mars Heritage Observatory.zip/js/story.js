/* =================================================================
   STORY LAYOUT - section-based scrollytelling over the fixed 3D scene.
   (TR) Mevcut paneller silinmez; aynı DOM düğümleri (aynı id'ler, aynı dinleyiciler) dikey bölümlere taşınır.
   3D sahne sabit kalır; bölümler kaydırıldıkça buzlu cam paneller içinde belirir.
   ================================================================= */
(() => {
  const $ = s => document.querySelector(s);
  const ready = fn => document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', fn) : fn();
  ready(() => {
    const ui = $('#ui'); if (!ui) return;
    const story = document.createElement('main'); story.id = 'story';
    const sec = (id, key, inner, cls = '') => { const s = document.createElement('section'); s.className = 'st-sec ' + cls; s.id = id; if (key) s.dataset.key = key; const w = document.createElement('div'); w.className = 'st-inner reveal'; s.appendChild(w); (inner || []).forEach(n => n && w.appendChild(n)); story.appendChild(s); return s; };

    /* hero: planet + big mirrored headline + scroll cue */
    const hero = sec('st-hero', 'heroKey', [], 'st-hero');
    const heroTitle = document.createElement('div'); heroTitle.className = 'hero-title'; heroTitle.setAttribute('aria-hidden', 'true');
    hero.firstChild.appendChild(heroTitle);
    const cue = document.createElement('button'); cue.className = 'scroll-cue'; cue.innerHTML = '<span data-i18n="scrollCue"></span><i></i>';
    hero.appendChild(cue);

    /* overview / selected craft: the existing panel, unchanged inside */
    const panel = $('#panel'), insp = $('#inspWrap'), acts = $('#pActions');
    sec('st-over', 'over', [panel], 'st-right');
    const inspSec = sec('st-insp', 'insp', [insp, acts], 'st-right st-inspsec');
    sec('st-cat', 'catalog', [$('#catalog')], 'st-left');
    sec('st-time', 'timeline', [$('#timeline')], 'st-wide');
    sec('st-src', 'sources', [$('#attrib')], 'st-left st-last');
    ui.appendChild(story);
    $('#catToggle') && ($('#catToggle').style.display = 'none');

    const veil = document.createElement('div'); veil.id = 'storyVeil'; document.body.insertBefore(veil, ui);
    const prog = document.createElement('div'); prog.id = 'storyProg'; prog.innerHTML = '<i></i>'; document.body.appendChild(prog);
    const dots = document.createElement('nav'); dots.id = 'storyDots'; dots.setAttribute('aria-label', 'Sections'); document.body.appendChild(dots);

    /* section labels reuse existing translated strings */
    const LBL = { heroKey: () => document.querySelector('#worldNav .world.on b')?.textContent || '', over: () => heroTitle.querySelector('h2')?.textContent || '', insp: () => $('#inspCap')?.textContent || '', catalog: () => tt('catalog'), timeline: () => tt('timeline'), sources: () => tt('sources') };
    const tt = k => { const el = document.querySelector(`[data-i18n="${k}"]`); return el ? el.textContent : k; };
    const secs = [...story.querySelectorAll('.st-sec')];
    secs.forEach(s => { const b = document.createElement('button'); b.className = 'dot'; b.dataset.for = s.id; b.innerHTML = '<span></span>'; b.addEventListener('click', () => go(s)); dots.appendChild(b); });
    const visibleSecs = () => secs.filter(s => s.offsetParent !== null && getComputedStyle(s).display !== 'none');
    const go = s => window.scrollTo({ top: s === hero ? 0 : s.offsetTop - 70, behavior: 'smooth' });
    cue.addEventListener('click', () => { const v = visibleSecs(); v[1] && go(v[1]); });

    /* hero headline mirrors the panel's current headline (body overview or selected craft) */
    const cueText = () => { const D = window.ABNF_I18N && window.ABNF_I18N.DICT; if (!D) return; const hint = document.querySelector('[data-i18n="dragHint"]'); const cur = hint && hint.textContent;
      const lg = Object.keys(D).find(k => D[k].dragHint === cur) || 'EN'; const v = (D[lg] && D[lg].scrollCue) || D.EN.scrollCue; const sp = cue.firstChild; if (sp.textContent !== v) sp.textContent = v; };
    const mirror = () => { cueText();
      const bo = $('#pBody .bo'), ph = $('#pHead .p-head');
      let html = '';
      if (ph) { const m = ph.querySelector('.p-meta'), h = ph.querySelector('h2'); html = (m ? `<div class="bo-kicker">${m.textContent}</div>` : '') + (h ? `<h2>${h.textContent}</h2>` : ''); }
      else if (bo) { const k = bo.querySelector('.bo-kicker'), h = bo.querySelector('h2'), s = bo.querySelector('.sub'); html = (k ? `<div class="bo-kicker">${k.textContent}</div>` : '') + (h ? `<h2>${h.textContent}</h2>` : '') + (s ? `<div class="sub">${s.textContent}</div>` : ''); }
      if (heroTitle.innerHTML !== html) { heroTitle.innerHTML = html; heroTitle.classList.remove('in'); void heroTitle.offsetWidth; heroTitle.classList.add('in'); }
      inspSec.style.display = document.body.classList.contains('craft-mode') ? '' : 'none';
      dots.querySelectorAll('.dot').forEach(d => { const s = $('#' + d.dataset.for); d.style.display = s.style.display === 'none' ? 'none' : ''; const k = s.dataset.key; d.querySelector('span').textContent = LBL[k] ? LBL[k]() : ''; });
    };
    let lastCraft = null, mT = 0;
    new MutationObserver(() => { cancelAnimationFrame(mT); mT = requestAnimationFrame(() => {
      mirror();
      const craft = document.body.classList.contains('craft-mode') ? ($('#pHead h2')?.textContent || '') : null;
      if (craft && craft !== lastCraft && document.body.classList.contains('story') && userPick) go($('#st-over'));
      lastCraft = craft; userPick = false;
    }); }).observe($('#ui'), { childList: true, subtree: true, characterData: true });
    new MutationObserver(mirror).observe(document.body, { attributes: true, attributeFilter: ['class', 'data-world'] });
    let userPick = false; ['pointerdown', 'keydown'].forEach(ev => addEventListener(ev, () => { userPick = true; setTimeout(() => userPick = false, 1200); }, true));


    /* ===== SCIENTIFIC REFERENCES (categorised, verifiable links) ===== */
    const REF = {
      cats: [
        { k: 'A', tr: 'NASA Resmi Görev ve Uzay Aracı Arşivleri', en: 'Official NASA mission & spacecraft archives', items: [
          ['NSSDCA — NASA Space Science Data Coordinated Archive', 'https://nssdc.gsfc.nasa.gov/', 'Fırlatma, varış ve son sinyal tarihleri, kütle ve görev künyeleri.', 'Launch, arrival and last-signal dates, masses and mission records.'],
          ['NSSDCA — Chronology of Lunar and Planetary Exploration', 'https://nssdc.gsfc.nasa.gov/planetary/chrono.html', 'Ay ve Mars görevlerinin tam kronolojisi; zaman çizelgesinin temeli.', 'Full chronology of lunar and Mars missions; basis of the timeline.'],
          ['NSSDCA — Mars: Current and Past Missions', 'https://nssdc.gsfc.nasa.gov/planetary/planets/marspage.html', 'Viking, Pathfinder, Spirit, Opportunity, Phoenix, InSight ve Sovyet Mars görevleri.', 'Viking, Pathfinder, Spirit, Opportunity, Phoenix, InSight and Soviet Mars missions.'],
          ['NSSDCA — The History of Mars Exploration', 'https://nssdc.gsfc.nasa.gov/planetary/mars/marshist.html', 'Başarılı ve başarısız Mars görevlerinin tarihsel bağlamı.', 'Historical context of successful and failed Mars missions.'],
          ['NASA Science — Lunar Reconnaissance Orbiter (LRO)', 'https://science.nasa.gov/mission/lro/about/', 'LRO görevi; Ay yüzeyindeki donanımın yörüngeden görüntülenmesi.', 'LRO mission; orbital imaging of hardware on the lunar surface.'],
          ['NASA History — Apollo Lunar Surface Journal', 'https://www.nasa.gov/history/alsj/', 'Apollo 11 ve 17 yüzey operasyonları, bırakılan deney setleri ve LRV.', 'Apollo 11 and 17 surface operations, deployed experiments and the LRV.']
        ] },
        { k: 'B', tr: '3D Yüzey, Harita ve Koordinat Veri Setleri', en: '3D surface, map & coordinate datasets', items: [
          ['NASA SVS — CGI Moon Kit', 'https://svs.gsfc.nasa.gov/4720', 'Ay küresinin LROC WAC renk mozaiği ve LOLA yükseklik haritası (kabartma).', 'LROC WAC colour mosaic and LOLA elevation map used on the Moon globe.'],
          ['NASA Science — LRO Instruments (LROC, LOLA)', 'https://science.nasa.gov/mission/lro/spacecraft-and-instruments/', 'Ay dokusunu ve krater kabartmasını üreten kamera ve lazer altimetre.', 'The camera and laser altimeter behind the Moon texture and crater relief.'],
          ['NASA 3D Resources (GitHub, public domain)', 'https://github.com/nasa/NASA-3D-Resources', 'Apollo LM, Viking, MER, InSight, Ingenuity ve MGS 3D modelleri; Mars küresel dokusu.', 'Apollo LM, Viking, MER, InSight, Ingenuity and MGS models; Mars global texture.'],
          ['USGS Astrogeology — Gazetteer of Planetary Nomenclature', 'https://www.usgs.gov/tools/gazetteer-planetary-nomenclature', 'Krater ve bölge adları ile enlem-boylam referansları (IAU onaylı).', 'IAU-approved feature names and latitude/longitude references.'],
          ['MRO HiRISE — University of Arizona', 'https://www.uahirise.org/', 'Mars yüzeyindeki iniş araçlarının yörüngeden doğrulanmış konumları.', 'Orbital confirmation of lander positions on the Martian surface.'],
          ['NASA JPL — InSight seen by MRO/HiRISE', 'https://www.jpl.nasa.gov/news/mars-insight-lander-seen-in-first-images-from-space/', 'InSight iniş noktasının HiRISE ile kesinleştirilmesi.', 'Pinpointing of the InSight landing site with HiRISE.']
        ] },
        { k: 'C', tr: 'Uzay Arkeolojisi ve Koruma Protokolleri', en: 'Space archaeology & preservation', items: [
          ["NASA's Recommendations to Space-Faring Entities (2011)", 'https://www.nasa.gov/pdf/617743main_NASA-USG_LUNAR_HISTORIC_SITES_RevA-508.pdf', 'Apollo ve diğer ABD Ay eserleri için yaklaşma ve koruma sınırları.', 'Approach and keep-out guidance for Apollo and other U.S. lunar artifacts.'],
          ['One Small Step to Protect Human Heritage in Space Act (2020)', 'https://www.govinfo.gov/content/pkg/COMPS-16007/pdf/COMPS-16007.pdf', '2011 önerilerini NASA ortakları için koşul hâline getiren ABD yasası.', 'U.S. law making the 2011 recommendations a condition for NASA partners.'],
          ['NASA Lunar Landing and Operations Policy Analysis (2022)', 'https://www.nasa.gov/wp-content/uploads/2022/10/lunar_landing_and_operations_policy_analysis_final_report_24oct2022_tagged_0.pdf', 'Tarihi iniş alanlarının korunmasına yönelik güncel politika analizi.', 'Current policy analysis on protecting historic landing sites.'],
          ['NASA Open Data Portal', 'https://data.nasa.gov/', 'Projede başvurulan açık NASA veri kataloğu.', 'Open NASA data catalogue consulted for the project.']
        ] },
        { k: 'D', tr: 'Hackathon Çerçevesi ve Yapay Zekâ Şeffaflık Beyanı', en: 'Hackathon framework & AI transparency', items: [
          ['NASA International Space Apps Challenge', 'https://www.spaceappschallenge.org/', '"Abandoned but not Forgotten" görev yönergesi ve katılım kuralları.', '"Abandoned but not Forgotten" challenge statement and participation rules.'],
          ['three.js (MIT License)', 'https://github.com/mrdoob/three.js', 'Tarayıcıda WebGL ile 3D sahne çizimi.', 'WebGL 3D rendering in the browser.']
        ] }
      ],
      ai: { tr: 'Yapay zekâ beyanı: Bu projenin arayüz geliştirme, veri derleme, 3D model dönüştürme ve görselleştirme süreçlerinde Anthropic Claude yapay zekâ asistanından yararlanılmıştır. Tüm görev verileri yukarıdaki resmi NASA ve USGS kaynaklarıyla karşılaştırılmıştır; nihai içerik ve sorumluluk proje ekibine aittir.', en: 'AI disclosure: Anthropic Claude was used as an AI assistant for interface development, data compilation, 3D model conversion and visualisation. All mission data were checked against the official NASA and USGS sources above; final content and responsibility rest with the project team.' },
      head: { tr: ['Kaynaklar ve Bilimsel Referanslar', 'Sitedeki her veri, doku ve konum aşağıdaki resmi arşivlere dayanır.'], en: ['Sources & Scientific References', 'Every figure, texture and position on this site traces back to the official archives below.'] }
    };
    const refBox = document.createElement('div'); refBox.id = 'refs'; refBox.className = 'refs';
    $('#st-src .st-inner').appendChild(refBox);
    const curLang = () => { const D = window.ABNF_I18N && window.ABNF_I18N.DICT, h = document.querySelector('[data-i18n="dragHint"]'); return (D && h && Object.keys(D).find(k => D[k].dragHint === h.textContent)) || 'EN'; };
    const esc = x => String(x).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    let refLang = '';
    const renderRefs = () => { const L = curLang() === 'TR' ? 'tr' : 'en'; if (L === refLang) return; refLang = L;
      refBox.innerHTML = `<header class="refs-head"><h3>${esc(REF.head[L][0])}</h3><p>${esc(REF.head[L][1])}</p></header>` +
        REF.cats.map(c => `<section class="ref-cat"><h4><span class="ref-k">${c.k}</span>${esc(c[L])}</h4><ol>` +
          c.items.map(i => `<li><a href="${i[1]}" target="_blank" rel="noopener noreferrer">${esc(i[0])}<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M4.5 2.5h5v5M9.5 2.5L3 9"/></svg></a><p>${esc(L === 'tr' ? i[2] : i[3])}</p><span class="ref-host">${esc(new URL(i[1]).host)}</span></li>`).join('') +
          `</ol>${c.k === 'D' ? `<div class="ref-ai"><b>AI</b><p>${esc(REF.ai[L])}</p></div>` : ''}</section>`).join('');
    };
    renderRefs();
    new MutationObserver(renderRefs).observe(document.querySelector('[data-i18n="dragHint"]') || document.body, { childList: true, characterData: true, subtree: true });

    /* reveal on enter (transform + opacity only) */
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) e.target.classList.add('in'); }), { threshold: .12, rootMargin: '0px 0px -8% 0px' });
    story.querySelectorAll('.reveal').forEach(n => io.observe(n));
    const active = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { dots.querySelectorAll('.dot').forEach(d => d.classList.toggle('on', d.dataset.for === e.target.id)); slide(); } }), { rootMargin: '-45% 0px -50% 0px' });
    secs.forEach(s => active.observe(s));

    /* fixed scene: soft parallax + readability veil, one rAF per scroll burst */
    const stage = $('#stage'); let raf = 0, tx = 0;
    const onScroll = () => { if (raf) return; raf = requestAnimationFrame(() => { raf = 0;
      const y = scrollY, vh = innerHeight, max = document.documentElement.scrollHeight - vh, k = Math.min(1, y / vh);
      const side = (document.querySelector('#storyDots .dot.on') || {}).dataset; const sid = side && side.for, dir = /over|insp/.test(sid || '') ? -1 : /cat|src/.test(sid || '') ? 1 : 0; tx = dir * 14 * k;
      stage.style.transform = `translate3d(${tx * .2}vw, ${-k * 1.5}vh, 0) scale(${1 + k * .08})`; /* (TR) hafif paralaks; kenarlarda boşluk açılmaz */
      veil.style.opacity = (k * .55).toFixed(3); cue.style.opacity = (1 - Math.min(1, y / (vh * .25))).toFixed(3);
      prog.firstChild.style.transform = `scaleY(${max > 0 ? y / max : 0})`;
      document.body.classList.toggle('scrolled', y > vh * .35);
    }); };
    addEventListener('scroll', onScroll, { passive: true });
    /* (TR) gezegen, okunan panelin karşı tarafına yumuşakça kayar */
    stage.style.transition = 'transform .9s cubic-bezier(.22,.61,.36,1)';
    function slide() { onScroll(); setTimeout(onScroll, 120); setTimeout(onScroll, 300); }

    /* story scrolling unlocks after the cinematic intro has finished */
    const ld = $('#loader');
    const unlock = () => { if (document.body.classList.contains('story')) return; document.body.classList.add('story'); mirror(); onScroll(); };
    if (!ld || getComputedStyle(ld).display === 'none') unlock();
    else new MutationObserver((_, o) => { if (getComputedStyle(ld).display === 'none') { o.disconnect(); unlock(); } }).observe(ld, { attributes: true, attributeFilter: ['style', 'class'] });
    document.querySelectorAll('#worldNav .world').forEach(b => b.addEventListener('click', () => { if (scrollY > 10) window.scrollTo({ top: 0, behavior: 'smooth' }); }));
    mirror();
  });
})();
