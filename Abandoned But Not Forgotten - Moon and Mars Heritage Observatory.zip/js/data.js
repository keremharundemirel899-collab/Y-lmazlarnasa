/* =====================================================================
   DATA LAYER - "Abandoned But Not Forgotten" (Moon + Mars edition)
   Sources: NASA NSSDCA master catalog (nssdc.gsfc.nasa.gov), NASA Science
   (science.nasa.gov) and Wikipedia (en.wikipedia.org). Archive IDs, dates
   and coordinates are compiled for education; verify before citing.
   tx[LANG] = [ cause, significance, history[0], history[1], ... ]
   hd       = dates aligned with history entries
   ===================================================================== */
window.ABNF_DATA = (function () {
  const BODIES = {
    MOON: {
      key: 'MOON', radiusKm: 1737.4, gm: 4902.8, pos: [0, 0, 0], view: 4.4, min: 1.08, max: 22, type: 1,
      atmo: [0, 0, 0], spin: 0.004, tilt: 0.03,
      stats: { radius: '1,737.4 km', gravity: '1.62 m/s²', dist: '384,400 km', day: '29.5 d' },
      wiki: 'Moon', theme: 'moon'
    },
    MARS: {
      key: 'MARS', radiusKm: 3389.5, gm: 42828.4, pos: [760, 90, -940], view: 5.2, min: 1.08, max: 30, type: 2,
      atmo: [1.0, 0.55, 0.32], spin: 0.009, tilt: 0.44,
      stats: { radius: '3,389.5 km', gravity: '3.72 m/s²', dist: '55 - 401 M km', day: '24 h 39 m' },
      wiki: 'Mars', theme: 'mars'
    }
  };

  const CATEGORIES = [
    { id: 'M1', body: 'MOON', key: 'cat_M1' },
    { id: 'M2', body: 'MOON', key: 'cat_M2' },
    { id: 'R1', body: 'MARS', key: 'cat_R1' },
    { id: 'R2', body: 'MARS', key: 'cat_R2' },
    { id: 'R3', body: 'MARS', key: 'cat_R3' }
  ];


  const CRAFT = [
    /* ============================ MOON - impactors & crash sites ============================ */
    {
      id: 'luna2', body: 'MOON', cat: 'M1', model: 'luna2', agency: 'USSR', nssdc: '1959-014A', wiki: 'Luna_2',
      name: { RU: "Луна-2", EN: 'Luna 2', TR: 'Luna 2', ZH: '月球2号', HI: 'लूना 2' }, site: 'Near Archimedes & Autolycus (est.)', lat: 30.0, lon: 0.0,
      launch: '1959-09-12', arrive: '1959-09-13', end: '1959-09-13', status: 'impact', sim: 'impact',
      hd: ['1959-09-12', '1959-09-13', '1959-09-13'],
      tx: {
        EN: ['Designed as an impactor; it struck the Moon near the craters Archimedes and Autolycus on 13 September 1959 (UTC). The exact impact point is unknown; the marker shows the NSSDCA estimate (30°N, 0°).', 'The first human-made object to reach the surface of another celestial body.', 'Launched from Baikonur on a direct-ascent trajectory.', 'Impact near Archimedes and Autolycus at about 3.3 km/s.', 'Its magnetometer detected no significant lunar magnetic field.'],
        TR: ["Çarpma aracı olarak tasarlandı; 13 Eylül 1959'da (UTC) Archimedes ve Autolycus kraterleri yakınında Ay'a çarptı. Kesin çarpma noktası bilinmiyor; işaret NSSDCA tahminini (30°K, 0°) gösteriyor.", 'Başka bir gök cisminin yüzeyine ulaşan ilk insan yapımı nesne.', "Baykonur'dan doğrudan Ay rotasıyla fırlatıldı.", 'Archimedes ve Autolycus kraterleri yakınına yaklaşık 3,3 km/s hızla çarptı.', "Manyetometresi Ay'da belirgin bir manyetik alan bulmadı."],
        ZH: ['设计即为撞击器；1959年9月13日（协调世界时）撞击月面阿基米德与奥托吕科斯撞击坑附近。确切撞击点不详，标记为NSSDCA估计位置（北纬30°，0°）。', '首个抵达另一天体表面的人造物体。', '从拜科努尔以直接上升轨道发射。', '以约3.3公里/秒的速度撞击阿基米德与奥托吕科斯撞击坑附近。', '其磁强计未探测到明显的月球磁场。'],
        HI: ['प्रभावक के रूप में बनाया गया; 13 सितंबर 1959 (UTC) को आर्किमिडीज़ और ऑटोलाइकस क्रेटरों के पास चंद्रमा से टकराया। सटीक प्रभाव बिंदु अज्ञात है; चिह्न NSSDCA का अनुमान (30°N, 0°) दिखाता है।', 'किसी अन्य खगोलीय पिंड की सतह तक पहुँचने वाली पहली मानव-निर्मित वस्तु।', 'बैकोनूर से सीधे चंद्र पथ पर प्रक्षेपित।', 'लगभग 3.3 km/s की गति से आर्किमिडीज़ और ऑटोलाइकस क्रेटरों के पास टकराया।', 'इसके मैग्नेटोमीटर को कोई उल्लेखनीय चंद्र चुंबकीय क्षेत्र नहीं मिला।'],
        ES: ['Diseñado como impactador; chocó contra la Luna cerca de los cráteres Arquímedes y Autólico el 13 de septiembre de 1959 (UTC). El punto exacto se desconoce; el marcador muestra la estimación de la NSSDCA (30°N, 0°).', 'El primer objeto fabricado por el ser humano que alcanzó la superficie de otro cuerpo celeste.', 'Lanzado desde Baikonur en trayectoria de ascenso directo.', 'Impacto cerca de Arquímedes y Autólico a unos 3,3 km/s.', 'Su magnetómetro no detectó un campo magnético lunar significativo.'],
        FR: ["Conçu comme impacteur ; il a percuté la Lune près des cratères Archimède et Autolycus le 13 septembre 1959 (UTC). Le point exact est inconnu ; le repère indique l'estimation de la NSSDCA (30°N, 0°).", "Le premier objet fabriqué par l'homme à atteindre la surface d'un autre corps céleste.", "Lancé depuis Baïkonour sur une trajectoire d'ascension directe.", "Impact près d'Archimède et d'Autolycus à environ 3,3 km/s.", "Son magnétomètre n'a détecté aucun champ magnétique lunaire notable."],
        RU: ["Создана как ударный зонд; 13 сентября 1959 года (UTC) врезалась в Луну около кратеров Архимед и Автолик. Точное место падения неизвестно; метка показывает оценку NSSDCA (30° с. ш., 0°).", "Первый созданный человеком объект, достигший поверхности другого небесного тела.", "Запущена с Байконура по прямой траектории к Луне.", "Падение около кратеров Архимед и Автолик на скорости около 3,3 км/с.", "Её магнитометр не обнаружил заметного магнитного поля Луны."]
      }
    },
    {
      id: 'ranger7', body: 'MOON', cat: 'M1', model: 'ranger', agency: 'NASA / JPL', nssdc: '1964-041A', wiki: 'Ranger_7',
      name: { RU: "Рейнджер-7", EN: 'Ranger 7', TR: 'Ranger 7', ZH: '徘徊者7号', HI: 'रेंजर 7' }, site: 'Mare Cognitum', lat: -10.63, lon: -20.68,
      launch: '1964-07-28', arrive: '1964-07-31', end: '1964-07-31', status: 'impact', sim: 'impact',
      hd: ['1964-07-28', '1964-07-31', '1964-07-31'],
      tx: {
        EN: ['Planned impact in Mare Cognitum after transmitting images until the final seconds.', 'Returned 4,308 images, the first close-up views of the Moon from a US spacecraft.', 'Launched on an Atlas-Agena B; the first US success after 13 consecutive failed lunar attempts, including Rangers 1 to 6.', 'Cameras began imaging about 17 minutes before impact.', 'Final frame taken about 488 m above the surface.'],
        TR: ["Son saniyelere kadar görüntü gönderdikten sonra Mare Cognitum'a planlı olarak çarptı.", "4.308 görüntü gönderdi; bir ABD aracından Ay'ın ilk yakın plan görüntüleri.", 'Atlas-Agena B ile fırlatıldı; Ranger 1-6 dahil üst üste 13 başarısız ABD Ay girişiminden sonraki ilk başarı.', 'Kameralar çarpışmadan yaklaşık 17 dakika önce çekime başladı.', 'Son kare yüzeyin yaklaşık 488 m üzerinden çekildi.'],
        ZH: ['按计划撞击知海，撞击前最后几秒仍在传回图像。', '传回4308幅图像，是美国航天器首次获得的月面近景。', '由宇宙神-阿金纳B火箭发射；在包括徘徊者1至6号在内的美国连续13次探月失败后首次成功。', '撞击前约17分钟相机开始拍摄。', '最后一帧在距月面约488米处拍摄。'],
        HI: ['अंतिम क्षणों तक तस्वीरें भेजने के बाद मेयर कॉग्निटम में नियोजित प्रभाव।', '4,308 चित्र भेजे; किसी अमेरिकी यान से चंद्रमा के पहले निकट दृश्य।', 'एटलस-एजेना B से प्रक्षेपित; रेंजर 1 से 6 सहित लगातार 13 असफल अमेरिकी चंद्र प्रयासों के बाद पहली सफलता।', 'प्रभाव से लगभग 17 मिनट पहले कैमरों ने चित्र लेना शुरू किया।', 'अंतिम चित्र सतह से लगभग 488 मीटर ऊपर लिया गया।'],
        ES: ['Impacto planificado en Mare Cognitum tras enviar imágenes hasta los últimos segundos.', 'Envió 4.308 imágenes, las primeras vistas cercanas de la Luna desde una nave estadounidense.', 'Lanzado en un Atlas-Agena B; el primer éxito de EE. UU. tras 13 intentos lunares fallidos consecutivos, incluidos los Ranger 1 a 6.', 'Las cámaras empezaron a fotografiar unos 17 minutos antes del impacto.', 'El último fotograma se tomó a unos 488 m de la superficie.'],
        FR: ["Impact prévu dans Mare Cognitum après avoir transmis des images jusqu'aux dernières secondes.", 'A transmis 4 308 images, les premières vues rapprochées de la Lune par un engin américain.', 'Lancé par une Atlas-Agena B ; premier succès américain après 13 tentatives lunaires ratées consécutives, dont Ranger 1 à 6.', "Les caméras ont commencé à photographier environ 17 minutes avant l'impact.", 'La dernière image a été prise à environ 488 m de la surface.'],
        RU: ["Запланированное падение в Море Познанном после передачи снимков до последних секунд.", "Передал 4308 снимков — первые крупные планы Луны, полученные американским аппаратом.", "Запущен ракетой «Атлас-Аджена B»; первый успех США после 13 подряд неудачных лунных попыток, включая «Рейнджеры» 1–6.", "Камеры начали съёмку примерно за 17 минут до падения.", "Последний кадр сделан примерно в 488 м над поверхностью."]
      }
    },
    {
      id: 'prospector', body: 'MOON', cat: 'M1', model: 'prospector', agency: 'NASA', nssdc: '1998-001A', wiki: 'Lunar_Prospector',
      name: { EN: 'Lunar Prospector', TR: 'Lunar Prospector', ZH: '月球勘探者号', HI: 'लूनर प्रॉस्पेक्टर' }, site: 'Shoemaker crater', lat: -87.7, lon: 42.0,
      launch: '1998-01-07', arrive: '1998-01-11', end: '1999-07-31', status: 'impact', sim: 'impact',
      hd: ['1998-01-07', '1998-01-11', '1999-07-31'],
      tx: {
        EN: ['Deliberately crashed into a permanently shadowed crater near the south pole to search for a water-vapour plume; none was detected.', 'Mapped hydrogen at the poles hinting at water ice, and carried ashes of planetary scientist Eugene Shoemaker.', 'Launched on an Athena II.', 'Entered lunar orbit.', 'Controlled impact into Shoemaker crater.'],
        TR: ['Su buharı bulutu aramak için güney kutbu yakınındaki kalıcı gölgeli bir kratere bilerek düşürüldü; bulut tespit edilmedi.', "Kutuplarda su buzuna işaret eden hidrojeni haritaladı ve gezegen bilimci Eugene Shoemaker'ın küllerini taşıdı.", 'Athena II ile fırlatıldı.', 'Ay yörüngesine girdi.', 'Shoemaker kraterine kontrollü çarpma.'],
        ZH: ['为寻找水蒸气羽流，被有意撞向南极附近的永久阴影坑；未探测到羽流。', '测绘了两极的氢分布，暗示存在水冰，并携带了行星科学家尤金·舒梅克的骨灰。', '由雅典娜II火箭发射。', '进入环月轨道。', '受控撞击舒梅克撞击坑。'],
        HI: ['जल-वाष्प गुबार खोजने के लिए इसे दक्षिणी ध्रुव के पास एक स्थायी छायांकित क्रेटर में जानबूझकर गिराया गया; कोई गुबार नहीं मिला।', 'ध्रुवों पर हाइड्रोजन का मानचित्रण किया जो जल-हिम का संकेत था, और ग्रह-वैज्ञानिक यूजीन शूमेकर की अस्थियाँ ले गया।', 'एथेना II से प्रक्षेपित।', 'चंद्र कक्षा में प्रवेश।', 'शूमेकर क्रेटर में नियंत्रित प्रभाव।'],
        ES: ['Se estrelló deliberadamente en un cráter en sombra permanente cerca del polo sur para buscar una nube de vapor de agua; no se detectó ninguna.', 'Cartografió hidrógeno en los polos, indicio de hielo de agua, y llevó las cenizas del científico planetario Eugene Shoemaker.', 'Lanzado en un Athena II.', 'Entró en órbita lunar.', 'Impacto controlado en el cráter Shoemaker.'],
        FR: ["Volontairement écrasé dans un cratère en ombre permanente près du pôle Sud pour chercher un panache de vapeur d'eau ; aucun n'a été détecté.", "A cartographié l'hydrogène aux pôles, indice de glace d'eau, et transportait les cendres du planétologue Eugene Shoemaker.", 'Lancé par une Athena II.', 'Mise en orbite lunaire.', 'Impact contrôlé dans le cratère Shoemaker.'],
        RU: ["Намеренно направлен в постоянно затенённый кратер у южного полюса, чтобы найти облако водяного пара; его не обнаружили.", "Составил карты водорода на полюсах, указывавшие на водяной лёд, и доставил прах планетолога Юджина Шумейкера.", "Запущен ракетой «Афина II».", "Выход на окололунную орбиту.", "Управляемое падение в кратер Шумейкер."]
      }
    },
    {
      id: 'smart1', body: 'MOON', cat: 'M1', model: 'smart1', agency: 'ESA', nssdc: '2003-043C', wiki: 'SMART-1',
      name: { EN: 'SMART-1' }, site: 'Lacus Excellentiae', lat: -34.26, lon: -46.19,
      launch: '2003-09-27', arrive: '2004-11-15', end: '2006-09-03', status: 'impact', sim: 'impact',
      hd: ['2003-09-27', '2004-11-15', '2006-09-03'],
      tx: {
        EN: ['Ended with a planned impact in Lacus Excellentiae; the flash was observed from Earth.', "Europe's first lunar mission and a pioneering test of solar-electric (ion) propulsion.", 'Launched on an Ariane 5 into an Earth transfer orbit.', 'Captured into lunar orbit after a long ion-drive spiral.', 'Impact on the near side at about 2 km/s.'],
        TR: ["Lacus Excellentiae'ye planlı bir çarpmayla sona erdi; parlama Dünya'dan gözlendi.", "Avrupa'nın ilk Ay görevi ve güneş-elektrik (iyon) itkisinin öncü bir denemesi.", 'Ariane 5 ile Dünya transfer yörüngesine fırlatıldı.', 'Uzun bir iyon motoru sarmalının ardından Ay yörüngesine yakalandı.', 'Yakın yüze yaklaşık 2 km/s hızla çarptı.'],
        ZH: ['以计划内撞击卓越湖告终；撞击闪光在地球上被观测到。', '欧洲首个月球任务，也是太阳能电推进（离子推进）的开创性试验。', '由阿丽亚娜5号送入地球转移轨道。', '经长时间离子推进螺旋飞行后被月球捕获。', '以约2公里/秒的速度撞击月球正面。'],
        HI: ['लैकस एक्सीलेंटिए में नियोजित प्रभाव के साथ समाप्त; चमक पृथ्वी से देखी गई।', 'यूरोप का पहला चंद्र मिशन और सौर-विद्युत (आयन) प्रणोदन का अग्रणी परीक्षण।', 'एरियन 5 से पृथ्वी स्थानांतरण कक्षा में प्रक्षेपित।', 'लंबे आयन-इंजन सर्पिल के बाद चंद्र कक्षा में पकड़ा गया।', 'निकट पक्ष पर लगभग 2 km/s से प्रभाव।'],
        ES: ['Terminó con un impacto planificado en Lacus Excellentiae; el destello se observó desde la Tierra.', 'La primera misión lunar europea y una prueba pionera de propulsión eléctrica solar (iónica).', 'Lanzado en un Ariane 5 a una órbita de transferencia terrestre.', 'Capturado en órbita lunar tras una larga espiral con motor iónico.', 'Impacto en la cara visible a unos 2 km/s.'],
        FR: ["S'est achevé par un impact prévu dans Lacus Excellentiae ; l'éclair a été observé depuis la Terre.", 'La première mission lunaire européenne et un essai pionnier de propulsion électrique solaire (ionique).', 'Lancé par une Ariane 5 sur une orbite de transfert terrestre.', 'Capturé en orbite lunaire après une longue spirale à propulsion ionique.', 'Impact sur la face visible à environ 2 km/s.'],
        RU: ["Миссия завершилась запланированным падением в Озере Превосходства; вспышку наблюдали с Земли.", "Первая лунная миссия Европы и новаторское испытание солнечно-электрического (ионного) двигателя.", "Запущен ракетой «Ариан-5» на переходную орбиту.", "Захвачен лунной орбитой после долгой спирали на ионном двигателе.", "Падение на видимой стороне на скорости около 2 км/с."]
      }
    },
    {
      id: 'lcross', body: 'MOON', cat: 'M1', model: 'lcross', agency: 'NASA', nssdc: '2009-031B', wiki: 'LCROSS',
      name: { EN: 'LCROSS', TR: 'LCROSS', ZH: 'LCROSS 月坑观测与遥感卫星', HI: 'एलक्रॉस (LCROSS)' }, site: 'Cabeus', lat: -84.68, lon: -48.70,
      launch: '2009-06-18', arrive: '2009-10-09', end: '2009-10-09', status: 'impact', sim: 'impact',
      hd: ['2009-06-18', '2009-10-09', '2009-10-09'],
      tx: {
        EN: ['Planned impact: the spent Centaur upper stage struck Cabeus crater, followed minutes later by the shepherding spacecraft that observed the plume.', 'The impact plume confirmed water ice in a permanently shadowed crater at the lunar south pole.', 'Launched with the Lunar Reconnaissance Orbiter on an Atlas V.', 'Spent Centaur upper stage strikes Cabeus crater (the marker shows this point).', 'Shepherding spacecraft flies through the plume, then impacts minutes later.'],
        TR: ['Planlı çarpma: tükenmiş Centaur üst kademesi Cabeus kraterine çarptı; birkaç dakika sonra bulutu gözleyen çoban araç da çarptı.', "Çarpma bulutu, Ay'ın güney kutbundaki kalıcı gölgeli bir kraterde su buzu olduğunu doğruladı.", 'Ay Keşif Yörünge Aracı (LRO) ile birlikte Atlas V ile fırlatıldı.', 'Tükenmiş Centaur üst kademesi Cabeus kraterine çarpar (işaret bu noktayı gösteriyor).', 'Çoban araç bulutun içinden geçer ve dakikalar sonra çarpar.'],
        ZH: ['计划内撞击：废弃的半人马座上面级撞向卡比厄斯撞击坑，数分钟后负责观测羽流的伴飞航天器也随之撞击。', '撞击羽流证实了月球南极永久阴影坑中存在水冰。', '与月球勘测轨道器一同由宇宙神五号发射。', '废弃的半人马座上面级撞击卡比厄斯撞击坑（标记即为此点）。', '伴飞航天器穿过羽流，数分钟后也撞击月面。'],
        HI: ['नियोजित प्रभाव: प्रयुक्त सेंटॉर ऊपरी चरण कैबियस क्रेटर से टकराया, और कुछ मिनट बाद गुबार का अवलोकन करने वाला अनुरक्षक यान भी टकराया।', 'प्रभाव से उठे गुबार ने चंद्र दक्षिणी ध्रुव के एक स्थायी छायांकित क्रेटर में जल-हिम की पुष्टि की।', 'लूनर रिकॉनिसेंस ऑर्बिटर के साथ एटलस V से प्रक्षेपित।', 'प्रयुक्त सेंटॉर ऊपरी चरण कैबियस क्रेटर से टकराया (चिह्न यही बिंदु दिखाता है)।', 'अनुरक्षक यान गुबार से गुज़रा और कुछ मिनट बाद टकराया।'],
        ES: ['Impacto planificado: la etapa superior Centaur agotada golpeó el cráter Cabeus y, minutos después, la nave pastora que observó la columna de material.', 'La columna del impacto confirmó la presencia de hielo de agua en un cráter en sombra permanente del polo sur lunar.', 'Lanzado con el Lunar Reconnaissance Orbiter en un Atlas V.', 'La etapa Centaur agotada impacta en el cráter Cabeus (el marcador muestra este punto).', 'La nave pastora atraviesa la columna y se estrella minutos después.'],
        FR: ["Impact prévu : l'étage supérieur Centaur épuisé a percuté le cratère Cabeus, suivi quelques minutes plus tard par l'engin accompagnateur qui a observé le panache.", "Le panache de l'impact a confirmé la présence de glace d'eau dans un cratère en ombre permanente du pôle Sud lunaire.", 'Lancé avec le Lunar Reconnaissance Orbiter par une Atlas V.', "L'étage Centaur épuisé percute le cratère Cabeus (le repère indique ce point).", "L'engin accompagnateur traverse le panache puis s'écrase quelques minutes plus tard."],
        RU: ["Запланированное падение: отработанная верхняя ступень «Центавр» врезалась в кратер Кабеус, а через несколько минут за ней последовал аппарат-наблюдатель, изучавший выброс.", "Выброс подтвердил наличие водяного льда в постоянно затенённом кратере у южного полюса Луны.", "Запущен вместе с Lunar Reconnaissance Orbiter ракетой «Атлас V».", "Отработанная ступень «Центавр» врезается в кратер Кабеус (метка показывает эту точку).", "Аппарат-наблюдатель пролетает сквозь выброс и через несколько минут падает сам."]
      }
    },
    {
      id: 'grail', body: 'MOON', cat: 'M1', model: 'grail', agency: 'NASA / JPL', nssdc: '2011-046A', wiki: 'Gravity_Recovery_and_Interior_Laboratory',
      name: { RU: "GRAIL (Ebb и Flow)", EN: 'GRAIL (Ebb & Flow)', TR: 'GRAIL (Ebb ve Flow)', ZH: 'GRAIL（退潮与涨潮）', HI: 'GRAIL (एब और फ़्लो)', ES: 'GRAIL (Ebb y Flow)', FR: 'GRAIL (Ebb et Flow)' }, site: 'Sally K. Ride Impact Site', lat: 75.61, lon: -26.59,
      launch: '2011-09-10', arrive: '2011-12-31', end: '2012-12-17', status: 'impact', sim: 'impact',
      hd: ['2011-09-10', '2011-12-31', '2012-12-17'],
      tx: {
        EN: ['Their low orbit and remaining fuel ruled out further science, so the twin probes Ebb and Flow were flown into a mountain near the north pole.', 'Produced the highest-resolution gravity map of the Moon; NASA named the impact site after Sally Ride.', 'Twin spacecraft launched on a Delta II.', 'Ebb and Flow enter lunar orbit around New Year.', "Planned impacts seconds apart; site named the Sally K. Ride Impact Site (the marker shows Ebb's point)."],
        TR: ['Alçak yörünge ve kalan yakıt bilimsel çalışmaya izin vermeyince ikiz sondalar Ebb ve Flow kuzey kutbu yakınındaki bir dağa yönlendirildi.', "Ay'ın en yüksek çözünürlüklü kütle çekim haritasını üretti; NASA çarpma bölgesine Sally Ride'ın adını verdi.", 'İkiz araçlar Delta II ile fırlatıldı.', 'Ebb ve Flow yılbaşı civarında Ay yörüngesine girer.', "Saniyeler arayla planlı çarpmalar; bölgeye Sally K. Ride Çarpma Alanı adı verildi (işaret Ebb'in noktasını gösteriyor)."],
        ZH: ['由于轨道过低、剩余燃料不足以继续科学工作，双子探测器“退潮”与“涨潮”被引导撞向北极附近的一座山。', '绘制了分辨率最高的月球重力场图；NASA以萨莉·赖德的名字命名撞击点。', '双子航天器由德尔塔二号发射。', '“退潮”与“涨潮”于新年前后进入环月轨道。', '相隔数秒的计划撞击；撞击点被命名为萨莉·赖德撞击点（标记为“退潮”的撞击点）。'],
        HI: ['निम्न कक्षा और शेष ईंधन के कारण आगे विज्ञान संभव न होने पर जुड़वाँ यान एब और फ़्लो को उत्तरी ध्रुव के पास एक पर्वत से टकराया गया।', 'चंद्रमा का सबसे उच्च-विभेदन गुरुत्व मानचित्र बनाया; NASA ने प्रभाव स्थल का नाम सैली राइड के नाम पर रखा।', 'जुड़वाँ यान डेल्टा II से प्रक्षेपित।', 'एब और फ़्लो नववर्ष के आसपास चंद्र कक्षा में पहुँचे।', 'कुछ सेकंड के अंतर पर नियोजित प्रभाव; स्थल का नाम सैली के. राइड इम्पैक्ट साइट रखा गया (चिह्न एब का बिंदु दिखाता है)।'],
        ES: ['Su órbita baja y el combustible restante impedían seguir con la ciencia, así que las sondas gemelas Ebb y Flow se dirigieron contra una montaña cerca del polo norte.', 'Produjo el mapa de gravedad lunar de mayor resolución; la NASA dio al sitio el nombre de Sally Ride.', 'Naves gemelas lanzadas en un Delta II.', 'Ebb y Flow entran en órbita lunar en torno al Año Nuevo.', 'Impactos planificados con segundos de diferencia; el lugar se llamó Sitio de Impacto Sally K. Ride (el marcador muestra el punto de Ebb).'],
        FR: ['Leur orbite basse et le carburant restant excluant toute science supplémentaire, les sondes jumelles Ebb et Flow ont été dirigées vers une montagne près du pôle Nord.', 'Ont produit la carte de gravité lunaire la plus détaillée ; la NASA a baptisé le site du nom de Sally Ride.', 'Engins jumeaux lancés par une Delta II.', 'Ebb et Flow entrent en orbite lunaire vers le Nouvel An.', "Impacts prévus à quelques secondes d'intervalle ; site baptisé Sally K. Ride Impact Site (le repère indique le point d'Ebb)."],
        RU: ["Низкая орбита и остаток топлива не позволяли продолжать науку, поэтому зонды-близнецы Ebb и Flow направили в гору у северного полюса.", "Составили гравитационную карту Луны с самым высоким разрешением; NASA назвало место падения в честь Салли Райд.", "Аппараты-близнецы запущены ракетой «Дельта II».", "Ebb и Flow выходят на окололунную орбиту около Нового года.", "Запланированные падения с разницей в секунды; место названо в честь Салли Райд (метка показывает точку Ebb)."]
      }
    },
    {
      id: 'beresheet', body: 'MOON', cat: 'M1', model: 'beresheet', agency: 'SpaceIL / IAI', nssdc: '2019-009B', wiki: 'Beresheet',
      name: { RU: "Берешит", EN: 'Beresheet', ZH: '创世纪号', HI: 'बेरेशीट' }, site: 'Mare Serenitatis', lat: 32.60, lon: 19.35,
      launch: '2019-02-22', arrive: '2019-04-04', end: '2019-04-11', status: 'impact', sim: 'impact',
      hd: ['2019-02-22', '2019-04-04', '2019-04-11'],
      tx: {
        EN: ['An inertial measurement unit (IMU) fault, and a reset command sent to fix it, set off a chain that shut down the main engine during descent; it crashed in Mare Serenitatis.', "The first privately developed lunar landing attempt, carrying a 'lunar library' archive.", 'Launched as a rideshare on a Falcon 9.', 'Captured into lunar orbit after weeks of Earth orbit raises.', 'Engine shutdown during final descent; impact.'],
        TR: ["Eylemsizlik ölçüm birimi (IMU) arızası ve onu düzeltmek için gönderilen sıfırlama komutu, iniş sırasında ana motoru kapatan bir zinciri başlattı; Mare Serenitatis'e çakıldı.", "Özel olarak geliştirilen ilk Ay'a iniş girişimi; bir 'Ay kütüphanesi' arşivi taşıyordu.", 'Falcon 9 ile ortak yük olarak fırlatıldı.', 'Haftalar süren Dünya yörüngesi yükseltmelerinin ardından Ay yörüngesine yakalandı.', 'Son inişte motor kapandı; çarpma.'],
        ZH: ['惯性测量单元（IMU）故障及为排除故障发送的重置指令引发连锁反应，导致下降中主发动机关机；坠毁于澄海。', '首次由私营机构研制的登月尝试，携带了一份“月球图书馆”档案。', '作为搭载载荷由猎鹰9号发射。', '经数周抬升地球轨道后被月球捕获。', '最终下降时发动机关机，撞击月面。'],
        HI: ['जड़त्वीय मापन इकाई (IMU) के दोष और उसे ठीक करने के लिए भेजे गए रीसेट आदेश से ऐसी श्रृंखला शुरू हुई जिससे अवतरण के दौरान मुख्य इंजन बंद हो गया; यह मेयर सेरेनिटैटिस में दुर्घटनाग्रस्त हुआ।', "निजी रूप से विकसित पहला चंद्र लैंडिंग प्रयास, जो एक 'चंद्र पुस्तकालय' संग्रह ले गया।", 'फाल्कन 9 पर साझा पेलोड के रूप में प्रक्षेपित।', 'कई सप्ताह पृथ्वी कक्षा बढ़ाने के बाद चंद्र कक्षा में पकड़ा गया।', 'अंतिम अवतरण में इंजन बंद; प्रभाव।'],
        ES: ['Una falla de la unidad de medición inercial (IMU) y la orden de reinicio enviada para corregirla desencadenaron una cadena que apagó el motor principal durante el descenso; se estrelló en Mare Serenitatis.', "El primer intento de alunizaje desarrollado de forma privada; llevaba un archivo de 'biblioteca lunar'.", 'Lanzado como carga compartida en un Falcon 9.', 'Capturado en órbita lunar tras semanas elevando su órbita terrestre.', 'Apagado del motor en el descenso final; impacto.'],
        FR: ["Une panne de la centrale inertielle (IMU) et la commande de réinitialisation envoyée pour la corriger ont déclenché une chaîne qui a coupé le moteur principal pendant la descente ; il s'est écrasé dans Mare Serenitatis.", "La première tentative d'alunissage développée par le privé ; il emportait une archive de 'bibliothèque lunaire'.", 'Lancé en passager secondaire sur une Falcon 9.', "Capturé en orbite lunaire après des semaines de relèvement d'orbite terrestre.", 'Arrêt du moteur en descente finale ; impact.'],
        RU: ["Сбой инерциального измерительного блока (IMU) и отправленная для его исправления команда перезагрузки запустили цепочку, отключившую главный двигатель при спуске; аппарат разбился в Море Ясности.", "Первая попытка посадки на Луну, разработанная частной организацией; на борту был архив «лунной библиотеки».", "Запущен попутным грузом на Falcon 9.", "Захвачен лунной орбитой после нескольких недель подъёма околоземной орбиты.", "Отключение двигателя на заключительном этапе спуска; падение."]
      }
    },
    /* ============================ MOON - landers, rovers & crewed sites ============================ */
    {
      id: 'luna9', body: 'MOON', cat: 'M2', model: 'luna9', agency: 'USSR', nssdc: '1966-006A', wiki: 'Luna_9',
      name: { RU: "Луна-9", EN: 'Luna 9', ZH: '月球9号', HI: 'लूना 9' }, site: 'Oceanus Procellarum (est.)', lat: 7.13, lon: -64.37,
      launch: '1966-01-31', arrive: '1966-02-03', end: '1966-02-06', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['1966-01-31', '1966-02-03', '1966-02-06'],
      tx: {
        EN: ['Batteries ran out on 6 February 1966 after three days of surface operations.', 'The first spacecraft to make a soft landing on the Moon and transmit photographs from its surface.', 'Launched from Baikonur.', 'Landed in Oceanus Procellarum; petals opened and the camera began panoramas. The marker is an estimate: the lander has not been found in LRO images.', 'Last contact as the batteries were exhausted.'],
        TR: ["Üç günlük yüzey çalışmasının ardından 6 Şubat 1966'da bataryaları tükendi.", "Ay'a yumuşak iniş yapan ve yüzeyinden fotoğraf gönderen ilk uzay aracı.", "Baykonur'dan fırlatıldı.", "Oceanus Procellarum'a indi; yaprakları açıldı ve kamera panorama çekmeye başladı. İşaret tahminidir: araç LRO görüntülerinde bulunamadı.", 'Bataryalar tükenince son temas gerçekleşti.'],
        ZH: ['在月面工作三天后，电池于1966年2月6日耗尽。', '首个在月球软着陆并从月面传回照片的航天器。', '从拜科努尔发射。', '降落在风暴洋；花瓣式舱盖展开，相机开始拍摄全景。标记为估计位置：LRO图像中尚未找到着陆器。', '电池耗尽，最后一次通信。'],
        HI: ['सतह पर तीन दिन काम करने के बाद 6 फ़रवरी 1966 को बैटरियाँ समाप्त हो गईं।', 'चंद्रमा पर सॉफ्ट लैंडिंग करने और उसकी सतह से तस्वीरें भेजने वाला पहला यान।', 'बैकोनूर से प्रक्षेपित।', 'ओशनस प्रोसेलारम में उतरा; पंखुड़ियाँ खुलीं और कैमरे ने पैनोरमा लेना शुरू किया। चिह्न अनुमानित है: LRO चित्रों में लैंडर नहीं मिला।', 'बैटरियाँ ख़त्म होने पर अंतिम संपर्क।'],
        ES: ['Sus baterías se agotaron el 6 de febrero de 1966 tras tres días de operaciones en superficie.', 'La primera nave en posarse suavemente en la Luna y enviar fotografías desde su superficie.', 'Lanzado desde Baikonur.', 'Aterrizó en Oceanus Procellarum; abrió sus pétalos y la cámara comenzó a tomar panorámicas. El marcador es una estimación: el módulo no se ha encontrado en imágenes del LRO.', 'Último contacto al agotarse las baterías.'],
        FR: ["Ses batteries se sont épuisées le 6 février 1966 après trois jours d'activité en surface.", 'Le premier engin à se poser en douceur sur la Lune et à transmettre des photos de sa surface.', 'Lancé depuis Baïkonour.', "Posé dans Oceanus Procellarum ; ses pétales se sont ouverts et la caméra a pris des panoramas. Le repère est une estimation : l'atterrisseur n'a pas été retrouvé sur les images LRO.", "Dernier contact à l'épuisement des batteries."],
        RU: ["Батареи разрядились 6 февраля 1966 года после трёх дней работы на поверхности.", "Первый аппарат, совершивший мягкую посадку на Луну и передавший снимки с её поверхности.", "Запущена с Байконура.", "Посадка в Океане Бурь; лепестки раскрылись, и камера начала съёмку панорам. Метка приблизительна: аппарат не найден на снимках LRO.", "Последний сеанс связи при разряде батарей."]
      }
    },
    {
      id: 'surveyor3', body: 'MOON', cat: 'M2', model: 'surveyor', agency: 'NASA / JPL', nssdc: '1967-035A', wiki: 'Surveyor_3',
      name: { RU: "Сервейер-3", EN: 'Surveyor 3', ZH: '勘测者3号', HI: 'सर्वेयर 3' }, site: 'Oceanus Procellarum', lat: -3.01, lon: -23.42,
      launch: '1967-04-17', arrive: '1967-04-20', end: '1967-05-04', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['1967-04-17', '1967-04-20', '1967-05-04', '1969-11-20'],
      tx: {
        EN: ['Fell silent on 4 May 1967 at the onset of lunar night; never revived.', 'Apollo 12 astronauts landed nearby in 1969 and brought its camera back to Earth for study.', 'Launched on an Atlas-Centaur.', 'Bounced twice before settling in the Ocean of Storms because its engines kept firing.', 'Last contact as lunar night began.', 'Conrad and Bean walked to it and removed the TV camera and other parts.'],
        TR: ["4 Mayıs 1967'de Ay gecesi başlarken sustu; bir daha uyanmadı.", "Apollo 12 astronotları 1969'da yakınına indi ve kamerasını incelenmek üzere Dünya'ya getirdi.", 'Atlas-Centaur ile fırlatıldı.', "Motorları çalışmaya devam ettiği için Fırtınalar Okyanusu'na oturmadan önce iki kez sekti.", 'Ay gecesi başlarken son temas.', 'Conrad ve Bean yanına yürüyüp TV kamerasını ve diğer parçaları söktü.'],
        ZH: ['1967年5月4日月夜来临时沉寂，此后再未苏醒。', '阿波罗12号航天员于1969年在其附近着陆，并将其相机带回地球研究。', '由宇宙神-半人马座火箭发射。', '因发动机持续点火，在风暴洋弹跳两次后才停稳。', '月夜开始，最后一次通信。', '康拉德和比恩步行至其旁，拆下电视相机等部件。'],
        HI: ['4 मई 1967 को चंद्र रात्रि शुरू होते ही मौन हो गया; फिर कभी सक्रिय नहीं हुआ।', 'अपोलो 12 के अंतरिक्ष यात्री 1969 में इसके पास उतरे और इसका कैमरा अध्ययन के लिए पृथ्वी लाए।', 'एटलस-सेंटॉर से प्रक्षेपित।', 'इंजन चलते रहने के कारण ओशन ऑफ़ स्टॉर्म्स में टिकने से पहले दो बार उछला।', 'चंद्र रात्रि शुरू होने पर अंतिम संपर्क।', 'कॉनराड और बीन पैदल इसके पास पहुँचे और टीवी कैमरा व अन्य भाग निकाले।'],
        ES: ['Enmudeció el 4 de mayo de 1967 al comenzar la noche lunar; nunca se reactivó.', 'Los astronautas del Apolo 12 alunizaron cerca en 1969 y trajeron su cámara a la Tierra para estudiarla.', 'Lanzado en un Atlas-Centaur.', 'Rebotó dos veces antes de asentarse en el Océano de las Tormentas porque sus motores siguieron encendidos.', 'Último contacto al iniciarse la noche lunar.', 'Conrad y Bean caminaron hasta él y retiraron la cámara de TV y otras piezas.'],
        FR: ["S'est tu le 4 mai 1967 à l'arrivée de la nuit lunaire ; il ne s'est jamais réveillé.", "Les astronautes d'Apollo 12 se sont posés tout près en 1969 et ont rapporté sa caméra sur Terre pour l'étudier.", 'Lancé par une Atlas-Centaur.', "A rebondi deux fois avant de s'immobiliser dans l'océan des Tempêtes, ses moteurs restant allumés.", 'Dernier contact au début de la nuit lunaire.', "Conrad et Bean l'ont rejoint à pied et ont démonté la caméra TV et d'autres pièces."],
        RU: ["Замолчал 4 мая 1967 года с наступлением лунной ночи и больше не включился.", "Астронавты «Аполлона-12» сели рядом в 1969 году и привезли его камеру на Землю для изучения.", "Запущен ракетой «Атлас-Центавр».", "Дважды подпрыгнул, прежде чем остановиться в Океане Бурь, потому что двигатели продолжали работать.", "Последний сеанс связи с началом лунной ночи.", "Конрад и Бин дошли до него пешком и сняли телекамеру и другие детали."]
      }
    },
    {
      id: 'apollo11', body: 'MOON', cat: 'M2', model: 'lm', variant: 'a11', agency: 'NASA', nssdc: '1969-059C', wiki: 'Apollo_11',
      name: { RU: "Аполлон-11 «Игл»", EN: 'Apollo 11 Eagle', TR: 'Apollo 11 Eagle', ZH: '阿波罗11号“鹰”号', HI: 'अपोलो 11 ईगल', ES: 'Apolo 11 Eagle', FR: 'Apollo 11 Eagle' }, site: 'Tranquility Base', lat: 0.674, lon: 23.473,
      launch: '1969-07-16', arrive: '1969-07-20', end: '1969-07-21', status: 'crewed', sim: 'edl', outcome: 'land',
      hd: ['1969-07-16', '1969-07-20', '1969-07-21', '1969-07-21'],
      tx: {
        EN: ['The descent stage stayed behind as the launch platform; the ascent stage was jettisoned in lunar orbit after docking and its fate was never tracked.', 'First crewed landing; the site holds a laser retroreflector still used for lunar laser ranging.', 'Saturn V launch from Kennedy Space Center.', 'Eagle lands at Tranquility Base; Armstrong steps out hours later.', 'Ascent stage lifts off, leaving the descent stage, flag and experiments.', 'Ascent stage jettisoned into lunar orbit after crew transfer.'],
        TR: ['İniş katı fırlatma platformu olarak geride kaldı; kalkış katı kenetlenmeden sonra Ay yörüngesinde bırakıldı ve akıbeti hiç izlenmedi.', 'İlk insanlı iniş; bölgede hâlâ Ay lazer ölçümünde kullanılan bir lazer yansıtıcı bulunuyor.', "Kennedy Uzay Merkezi'nden Saturn V ile fırlatma.", "Eagle, Sükûnet Üssü'ne iner; Armstrong saatler sonra dışarı adım atar.", 'Kalkış katı havalanır; geride iniş katı, bayrak ve deneyler kalır.', 'Mürettebat aktarımından sonra kalkış katı Ay yörüngesinde bırakılır.'],
        ZH: ['下降级作为起飞平台留在月面；上升级在对接后被抛入环月轨道，其最终命运从未被追踪。', '首次载人登月；着陆点的激光反射器至今仍用于月球激光测距。', '土星五号从肯尼迪航天中心发射。', '“鹰”号降落在静海基地，数小时后阿姆斯特朗踏上月面。', '上升级起飞，下降级、旗帜与实验仪器留在原地。', '航天员转移后，上升级被抛入环月轨道。'],
        HI: ['अवरोहण चरण प्रक्षेपण मंच के रूप में पीछे रह गया; आरोहण चरण को डॉकिंग के बाद चंद्र कक्षा में छोड़ दिया गया और उसकी अंतिम स्थिति कभी ट्रैक नहीं हुई।', 'पहली मानवयुक्त लैंडिंग; स्थल पर लगा लेज़र परावर्तक आज भी चंद्र लेज़र रेंजिंग में उपयोग होता है।', 'कैनेडी स्पेस सेंटर से सैटर्न V द्वारा प्रक्षेपण।', 'ईगल ट्रैंक्विलिटी बेस पर उतरा; कुछ घंटों बाद आर्मस्ट्रांग बाहर निकले।', 'आरोहण चरण उड़ा; अवरोहण चरण, झंडा और प्रयोग पीछे रहे।', 'चालक दल के स्थानांतरण के बाद आरोहण चरण चंद्र कक्षा में छोड़ा गया।'],
        ES: ['La etapa de descenso quedó como plataforma de lanzamiento; la de ascenso se liberó en órbita lunar tras el acoplamiento y nunca se rastreó su destino.', 'Primer alunizaje tripulado; el sitio conserva un retrorreflector láser que aún se usa para medir la distancia a la Luna.', 'Lanzamiento del Saturno V desde el Centro Espacial Kennedy.', 'Eagle se posa en la Base Tranquilidad; Armstrong sale horas después.', 'Despega la etapa de ascenso; quedan la de descenso, la bandera y los experimentos.', 'La etapa de ascenso se libera en órbita lunar tras el traslado de la tripulación.'],
        FR: ["L'étage de descente est resté comme plateforme de lancement ; l'étage de remontée a été largué en orbite lunaire après l'amarrage et son sort n'a jamais été suivi.", 'Premier alunissage habité ; le site abrite un rétroréflecteur laser toujours utilisé pour la télémétrie laser lunaire.', 'Lancement de la Saturn V depuis le centre spatial Kennedy.', 'Eagle se pose à la base de la Tranquillité ; Armstrong sort quelques heures plus tard.', "L'étage de remontée décolle, laissant l'étage de descente, le drapeau et les expériences.", "L'étage de remontée est largué en orbite lunaire après le transfert de l'équipage."],
        RU: ["Посадочная ступень осталась на месте как стартовая площадка; взлётную ступень после стыковки оставили на лунной орбите, и её судьба так и не отслеживалась.", "Первая пилотируемая посадка; на месте стоит лазерный отражатель, который до сих пор используется для лазерной локации Луны.", "Старт «Сатурна V» с Космического центра Кеннеди.", "«Игл» садится на базе Спокойствия; через несколько часов Армстронг выходит на поверхность.", "Взлётная ступень стартует; на месте остаются посадочная ступень, флаг и приборы.", "После перехода экипажа взлётную ступень оставляют на лунной орбите."]
      }
    },
    {
      id: 'lunokhod1', body: 'MOON', cat: 'M2', model: 'lunokhod', agency: 'USSR', nssdc: '1970-095A', wiki: 'Lunokhod_1',
      name: { RU: "Луноход-1", EN: 'Lunokhod 1', ZH: '月球车1号', HI: 'लूनोखोद 1' }, site: 'Mare Imbrium', lat: 38.32, lon: -35.00,
      launch: '1970-11-10', arrive: '1970-11-17', end: '1971-09-14', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['1970-11-10', '1970-11-17', '1971-09-14', '2010-04-22'],
      tx: {
        EN: ['Contact was lost on 14 September 1971 and never restored after a lunar night, apparently because a component failed.', 'The first remote-controlled rover on another world; it drove about 10.5 km in Mare Imbrium.', 'Luna 17 launched from Baikonur.', 'Rolled down ramps onto Mare Imbrium.', 'Last successful contact; mission ended in October.', 'Its retroreflector returned laser pulses again after being located in LRO images.'],
        TR: ["14 Eylül 1971'de temas kesildi ve bir Ay gecesinden sonra yeniden kurulamadı; nedeni muhtemelen bir bileşen arızasıydı.", "Başka bir dünyadaki ilk uzaktan kumandalı gezgin; Mare Imbrium'da yaklaşık 10,5 km yol aldı.", "Luna 17 Baykonur'dan fırlatıldı.", "Rampalardan Mare Imbrium'a indi.", 'Son başarılı temas; görev ekimde sona erdi.', 'LRO görüntülerinde yeri bulununca yansıtıcısı yeniden lazer darbelerini geri gönderdi.'],
        ZH: ['1971年9月14日失去联系，此后一个月夜过后未能恢复，原因可能是某个部件故障。', '首辆在另一个天体上遥控行驶的月球车，在雨海行驶约10.5公里。', '月球17号从拜科努尔发射。', '沿坡道驶上雨海表面。', '最后一次成功通信，任务于10月结束。', '在LRO图像中被定位后，其反射器再次返回激光脉冲。'],
        HI: ['14 सितंबर 1971 को संपर्क टूट गया और एक चंद्र रात्रि के बाद फिर नहीं जुड़ा; संभवतः किसी घटक के ख़राब होने से।', 'किसी अन्य दुनिया पर पहला दूर-नियंत्रित रोवर; इसने मेयर इम्ब्रियम में लगभग 10.5 km यात्रा की।', 'लूना 17 बैकोनूर से प्रक्षेपित।', 'रैंप से उतरकर मेयर इम्ब्रियम पर पहुँचा।', 'अंतिम सफल संपर्क; मिशन अक्टूबर में समाप्त।', 'LRO चित्रों में स्थान मिलने के बाद इसके परावर्तक ने फिर से लेज़र स्पंद लौटाए।'],
        ES: ['Se perdió el contacto el 14 de septiembre de 1971 y no se recuperó tras una noche lunar, al parecer por el fallo de un componente.', 'El primer vehículo teledirigido en otro mundo; recorrió unos 10,5 km en Mare Imbrium.', 'Luna 17 despegó desde Baikonur.', 'Bajó por rampas hasta Mare Imbrium.', 'Último contacto exitoso; la misión terminó en octubre.', 'Su retrorreflector volvió a devolver pulsos láser tras ser localizado en imágenes del LRO.'],
        FR: ["Le contact a été perdu le 14 septembre 1971 et n'a pas été rétabli après une nuit lunaire, apparemment à cause de la panne d'un composant.", 'Le premier véhicule télécommandé sur un autre monde ; il a parcouru environ 10,5 km dans Mare Imbrium.', 'Luna 17 lancée depuis Baïkonour.', 'Descente par rampes sur Mare Imbrium.', "Dernier contact réussi ; la mission s'est terminée en octobre.", 'Son rétroréflecteur a de nouveau renvoyé des impulsions laser après sa localisation sur des images LRO.'],
        RU: ["Связь прервалась 14 сентября 1971 года и не восстановилась после лунной ночи, по-видимому из-за отказа одного из узлов.", "Первый дистанционно управляемый самоходный аппарат на другом небесном теле; проехал около 10,5 км по Морю Дождей.", "«Луна-17» запущена с Байконура.", "Съехал по трапам на поверхность Моря Дождей.", "Последний успешный сеанс связи; миссия завершена в октябре.", "Его отражатель снова вернул лазерные импульсы после того, как луноход нашли на снимках LRO."]
      }
    },
    {
      id: 'apollo17', body: 'MOON', cat: 'M2', model: 'lm', variant: 'a17', agency: 'NASA', nssdc: '1972-096C', wiki: 'Apollo_17',
      name: { RU: "Аполлон-17 «Челленджер» + LRV", EN: 'Apollo 17 Challenger + LRV', TR: 'Apollo 17 Challenger + LRV', ZH: '阿波罗17号“挑战者”号与月球车', HI: 'अपोलो 17 चैलेंजर + LRV', ES: 'Apolo 17 Challenger + LRV', FR: 'Apollo 17 Challenger + LRV' }, site: 'Taurus-Littrow', lat: 20.19, lon: 30.77,
      launch: '1972-12-07', arrive: '1972-12-11', end: '1972-12-14', status: 'crewed', sim: 'edl', outcome: 'land',
      hd: ['1972-12-07', '1972-12-11', '1972-12-14'],
      tx: {
        EN: ['Left behind by design at Taurus-Littrow with the Lunar Roving Vehicle when Cernan and Schmitt departed.', 'The most recent crewed lunar landing to date (2026); Harrison Schmitt was the first professional geologist on the Moon.', 'Night launch of the final Apollo Saturn V.', 'Challenger lands in the Taurus-Littrow valley.', "Cernan's final steps; Challenger's ascent stage lifts off."],
        TR: ["Cernan ve Schmitt ayrılırken Ay Gezgin Aracı ile birlikte Taurus-Littrow'da bilinçli olarak bırakıldı.", "Bugüne kadarki (2026) son insanlı Ay inişi; Harrison Schmitt Ay'a giden ilk profesyonel jeolog oldu.", "Son Apollo Saturn V'in gece fırlatılışı.", 'Challenger, Taurus-Littrow vadisine iner.', "Cernan'ın son adımları; Challenger'ın kalkış katı havalanır."],
        ZH: ['塞尔南与施密特离开时，按计划与月球车一同留在金牛-利特罗谷。', '迄今（2026年）最后一次载人登月；哈里森·施密特是首位登上月球的专业地质学家。', '最后一枚阿波罗土星五号夜间发射。', '“挑战者”号降落在金牛-利特罗谷。', '塞尔南留下最后的足迹，“挑战者”号上升级起飞。'],
        HI: ['सर्नन और श्मिट के प्रस्थान के समय इसे चंद्र रोविंग वाहन के साथ योजनानुसार टॉरस-लिट्रो में छोड़ा गया।', 'अब तक (2026) की अंतिम मानवयुक्त चंद्र लैंडिंग; हैरिसन श्मिट चंद्रमा पर जाने वाले पहले पेशेवर भूविज्ञानी थे।', 'अंतिम अपोलो सैटर्न V का रात्रि प्रक्षेपण।', 'चैलेंजर टॉरस-लिट्रो घाटी में उतरा।', 'सर्नन के अंतिम कदम; चैलेंजर का आरोहण चरण उड़ा।'],
        ES: ['Quedó atrás de forma planificada en Taurus-Littrow junto al Vehículo Lunar cuando Cernan y Schmitt partieron.', 'El último alunizaje tripulado hasta la fecha (2026); Harrison Schmitt fue el primer geólogo profesional en la Luna.', 'Lanzamiento nocturno del último Saturno V del Apolo.', 'Challenger se posa en el valle de Taurus-Littrow.', 'Últimos pasos de Cernan; despega la etapa de ascenso del Challenger.'],
        FR: ['Laissé volontairement à Taurus-Littrow avec le véhicule lunaire lorsque Cernan et Schmitt sont repartis.', 'Le dernier alunissage habité à ce jour (2026) ; Harrison Schmitt fut le premier géologue professionnel sur la Lune.', "Lancement nocturne de la dernière Saturn V d'Apollo.", 'Challenger se pose dans la vallée de Taurus-Littrow.', "Derniers pas de Cernan ; l'étage de remontée de Challenger décolle."],
        RU: ["Оставлен по плану в долине Тавр-Литтров вместе с лунным автомобилем, когда улетели Сернан и Шмитт.", "Последняя на сегодня (2026) пилотируемая посадка на Луну; Харрисон Шмитт стал первым профессиональным геологом на Луне.", "Ночной старт последнего «Сатурна V» программы «Аполлон».", "«Челленджер» садится в долине Тавр-Литтров.", "Последние шаги Сернана; взлётная ступень «Челленджера» стартует."]
      }
    },
    {
      id: 'yutu', body: 'MOON', cat: 'M2', model: 'yutu', agency: 'CNSA', nssdc: '2013-070A', wiki: 'Yutu_(rover)',
      name: { RU: "Чанъэ-3 / Юйту", EN: "Chang'e 3 / Yutu", TR: "Chang'e 3 / Yutu", ZH: '嫦娥三号 / 玉兔号', HI: "चांग'ई 3 / युतु" }, site: 'Mare Imbrium', lat: 44.12, lon: -19.51,
      launch: '2013-12-01', arrive: '2013-12-14', end: '2016-07-31', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['2013-12-01', '2013-12-14', '2014-01-25', '2016-07-31'],
      tx: {
        EN: ['A control fault in January 2014 left it unable to drive; it kept working as a stationary station until mid-2016.', "China's first lunar rover and the first soft landing on the Moon since Luna 24 in 1976.", "Chang'e 3 launched from Xichang.", 'Lands in Mare Imbrium; Yutu rolls off the lander.', 'Mechanical control anomaly halts driving.', 'Mission ends after 31 months, far beyond the planned three.'],
        TR: ["Ocak 2014'teki bir kontrol arızası onu hareketsiz bıraktı; 2016 ortasına kadar sabit istasyon olarak çalıştı.", "Çin'in ilk Ay gezgini ve 1976'daki Luna 24'ten bu yana Ay'a yapılan ilk yumuşak iniş.", "Chang'e 3 Xichang'dan fırlatıldı.", "Mare Imbrium'a iner; Yutu iniş aracından ayrılır.", 'Mekanik kontrol arızası sürüşü durdurur.', 'Planlanan üç ayın çok ötesinde, 31 ay sonra görev sona erer.'],
        ZH: ['2014年1月发生机构控制异常，无法行驶；此后作为固定站工作至2016年年中。', '中国首辆月球车，也是自1976年月球24号以来首次在月球软着陆。', '嫦娥三号从西昌发射。', '降落在雨海，玉兔号驶离着陆器。', '机构控制异常，无法继续行驶。', '工作31个月后任务结束，远超设计的3个月。'],
        HI: ['जनवरी 2014 में नियंत्रण दोष के कारण यह चल नहीं सका; 2016 के मध्य तक स्थिर स्टेशन के रूप में काम करता रहा।', 'चीन का पहला चंद्र रोवर और 1976 में लूना 24 के बाद चंद्रमा पर पहली सॉफ्ट लैंडिंग।', "चांग'ई 3 शीचांग से प्रक्षेपित।", 'मेयर इम्ब्रियम में उतरा; युतु लैंडर से नीचे उतरा।', 'यांत्रिक नियंत्रण विसंगति से चलना बंद।', 'नियोजित तीन महीनों से कहीं अधिक, 31 महीने बाद मिशन समाप्त।'],
        ES: ['Una falla de control en enero de 2014 le impidió desplazarse; siguió funcionando como estación fija hasta mediados de 2016.', 'El primer vehículo lunar de China y el primer alunizaje suave desde el Luna 24 en 1976.', "Chang'e 3 despega desde Xichang.", 'Se posa en Mare Imbrium; Yutu desciende del módulo.', 'Una anomalía de control mecánico detiene la conducción.', 'La misión termina tras 31 meses, muy por encima de los tres previstos.'],
        FR: ["Une panne de commande en janvier 2014 l'a immobilisé ; il a continué comme station fixe jusqu'à mi-2016.", 'Le premier rover lunaire chinois et le premier atterrissage en douceur sur la Lune depuis Luna 24 en 1976.', "Chang'e 3 lancé depuis Xichang.", "Se pose dans Mare Imbrium ; Yutu descend de l'atterrisseur.", 'Une anomalie de commande mécanique stoppe les déplacements.', 'Fin de mission après 31 mois, bien au-delà des trois prévus.'],
        RU: ["Сбой управления в январе 2014 года лишил его возможности ездить; до середины 2016 года он работал как неподвижная станция.", "Первый китайский луноход и первая мягкая посадка на Луну со времён «Луны-24» в 1976 году.", "«Чанъэ-3» запущен с космодрома Сичан.", "Посадка в Море Дождей; «Юйту» съезжает с посадочной платформы.", "Сбой механического управления останавливает движение.", "Миссия завершена через 31 месяц — намного дольше запланированных трёх."]
      }
    },
    /* ============================ MARS - landers, rovers & helicopter ============================ */
    {
      id: 'viking1', body: 'MARS', cat: 'R1', model: 'viking', agency: 'NASA', nssdc: '1975-075C', wiki: 'Viking_1',
      name: { RU: "Викинг-1 (посадочный модуль)", EN: 'Viking 1 Lander', TR: 'Viking 1 İniş Aracı', ZH: '海盗1号着陆器', HI: 'वाइकिंग 1 लैंडर', ES: 'Viking 1 (módulo)', FR: 'Atterrisseur Viking 1' }, site: 'Chryse Planitia', lat: 22.27, lon: -47.95,
      launch: '1975-08-20', arrive: '1976-07-20', end: '1982-11-13', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['1975-08-20', '1976-07-20', '1982-11-13'],
      tx: {
        EN: ['A faulty command sent in November 1982 overwrote antenna-pointing software, ending communications.', 'The first US spacecraft to land on Mars and return surface images, operating for more than six years.', 'Launched on a Titan IIIE/Centaur.', 'Lands in Chryse Planitia and returns the first clear image from the Martian surface.', 'A faulty command overwrites antenna software; contact lost.'],
        TR: ['Kasım 1982\'de gönderilen hatalı bir komut anten yönlendirme yazılımının üzerine yazdı ve iletişim sona erdi.', "Mars'a inip yüzey görüntüleri gönderen ilk ABD aracı; altı yıldan fazla çalıştı.", 'Titan IIIE/Centaur ile fırlatıldı.', "Chryse Planitia'ya iner ve Mars yüzeyinden ilk net görüntüyü gönderir.", 'Hatalı bir komut anten yazılımının üzerine yazar; temas kesilir.'],
        ZH: ['1982年11月发送的错误指令覆盖了天线指向软件，导致通信终止。', '首个成功登陆火星并传回地表图像的美国航天器，运行超过六年。', '由大力神IIIE/半人马座火箭发射。', '降落在克律塞平原，传回火星表面首张清晰图像。', '错误指令覆盖天线软件，通信中断。'],
        HI: ['नवंबर 1982 में भेजे गए एक त्रुटिपूर्ण आदेश ने एंटीना-दिशा सॉफ़्टवेयर को अधिलेखित कर दिया, जिससे संचार समाप्त हो गया।', 'मंगल पर उतरकर सतह की तस्वीरें भेजने वाला पहला अमेरिकी अंतरिक्ष यान, जिसने छह वर्ष से अधिक कार्य किया।', 'टाइटन IIIE/सेंटॉर से प्रक्षेपित।', 'क्राइस प्लैनिशिया में उतरा और मंगल की सतह की पहली स्पष्ट तस्वीर भेजी।', 'त्रुटिपूर्ण आदेश ने एंटीना सॉफ़्टवेयर अधिलेखित किया; संपर्क टूटा।'],
        ES: ['Un comando erróneo enviado en noviembre de 1982 sobrescribió el software de apuntamiento de la antena y terminó las comunicaciones.', 'La primera nave estadounidense en aterrizar en Marte y enviar imágenes de su superficie, operativa durante más de seis años.', 'Lanzado en un Titan IIIE/Centaur.', 'Aterriza en Chryse Planitia y envía la primera imagen nítida de la superficie marciana.', 'Un comando erróneo sobrescribe el software de la antena; se pierde el contacto.'],
        FR: ["Une commande erronée envoyée en novembre 1982 a écrasé le logiciel de pointage de l'antenne, mettant fin aux communications.", 'Le premier engin américain à se poser sur Mars et à transmettre des images de sa surface, actif pendant plus de six ans.', 'Lancé par une Titan IIIE/Centaur.', 'Se pose dans Chryse Planitia et transmet la première image nette de la surface martienne.', "Une commande erronée écrase le logiciel d'antenne ; contact perdu."],
        RU: ["Ошибочная команда, отправленная в ноябре 1982 года, перезаписала программу наведения антенны, и связь прекратилась.", "Первый американский аппарат, севший на Марс и передавший снимки поверхности; работал более шести лет.", "Запущен ракетой «Титан IIIE/Центавр».", "Посадка на равнине Хриса и первый чёткий снимок с поверхности Марса.", "Ошибочная команда перезаписывает программу антенны; связь потеряна."]
      }
    },
    {
      id: 'viking2', body: 'MARS', cat: 'R1', model: 'viking', agency: 'NASA', nssdc: '1975-083C', wiki: 'Viking_2',
      name: { RU: "Викинг-2 (посадочный модуль)", EN: 'Viking 2 Lander', TR: 'Viking 2 İniş Aracı', ZH: '海盗2号着陆器', HI: 'वाइकिंग 2 लैंडर', ES: 'Viking 2 (módulo)', FR: 'Atterrisseur Viking 2' }, site: 'Utopia Planitia', lat: 47.64, lon: 134.29,
      launch: '1975-09-09', arrive: '1976-09-03', end: '1980-04-11', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['1975-09-09', '1976-09-03', '1980-04-11'],
      tx: {
        EN: ['Battery failure ended operations on 11 April 1980.', 'Landed in Utopia Planitia and photographed frost on the Martian surface during winter.', 'Launched on a Titan IIIE/Centaur.', 'Lands in Utopia Planitia.', 'Battery failure; last transmission.'],
        TR: ["Batarya arızası 11 Nisan 1980'de çalışmaları sona erdirdi.", "Utopia Planitia'ya indi ve kışın Mars yüzeyindeki kırağıyı fotoğrafladı.", 'Titan IIIE/Centaur ile fırlatıldı.', "Utopia Planitia'ya iner.", 'Batarya arızası; son yayın.'],
        ZH: ['电池故障于1980年4月11日终止了运行。', '降落在乌托邦平原，并在冬季拍摄到火星表面的霜。', '由大力神IIIE/半人马座火箭发射。', '降落在乌托邦平原。', '电池故障，最后一次传输。'],
        HI: ['बैटरी विफलता ने 11 अप्रैल 1980 को कार्य समाप्त कर दिया।', 'यूटोपिया प्लैनिशिया में उतरा और सर्दियों में मंगल की सतह पर पाले की तस्वीरें लीं।', 'टाइटन IIIE/सेंटॉर से प्रक्षेपित।', 'यूटोपिया प्लैनिशिया में उतरा।', 'बैटरी विफलता; अंतिम प्रसारण।'],
        ES: ['Un fallo de batería terminó sus operaciones el 11 de abril de 1980.', 'Aterrizó en Utopia Planitia y fotografió escarcha sobre la superficie marciana en invierno.', 'Lanzado en un Titan IIIE/Centaur.', 'Aterriza en Utopia Planitia.', 'Fallo de batería; última transmisión.'],
        FR: ['Une panne de batterie a mis fin aux opérations le 11 avril 1980.', 'Posé dans Utopia Planitia, il a photographié du givre à la surface de Mars en hiver.', 'Lancé par une Titan IIIE/Centaur.', 'Se pose dans Utopia Planitia.', 'Panne de batterie ; dernière transmission.'],
        RU: ["Отказ батареи прекратил работу 11 апреля 1980 года.", "Сел на равнине Утопия и сфотографировал иней на поверхности Марса зимой.", "Запущен ракетой «Титан IIIE/Центавр».", "Посадка на равнине Утопия.", "Отказ батареи; последняя передача."]
      }
    },
    {
      id: 'pathfinder', body: 'MARS', cat: 'R1', model: 'pathfinder', agency: 'NASA / JPL', nssdc: '1996-068A', wiki: 'Mars_Pathfinder',
      name: { RU: "Марс Пасфайндер + Соджорнер", EN: 'Mars Pathfinder + Sojourner', TR: 'Mars Pathfinder + Sojourner', ZH: '火星探路者号与索杰纳号', HI: 'मार्स पाथफ़ाइंडर + सोजॉर्नर', ES: 'Mars Pathfinder + Sojourner', FR: 'Mars Pathfinder + Sojourner' }, site: 'Ares Vallis', lat: 19.13, lon: -33.22,
      launch: '1996-12-04', arrive: '1997-07-04', end: '1997-09-27', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['1996-12-04', '1997-07-04', '1997-09-27'],
      tx: {
        EN: ['Contact was lost on 27 September 1997, most likely after battery depletion left the lander too cold to operate.', 'Bounced to a landing on airbags and deployed Sojourner, the first wheeled rover on Mars; the lander is named the Carl Sagan Memorial Station.', 'Launched on a Delta II.', 'Airbag landing in Ares Vallis; Sojourner rolls out two days later.', 'Final data transmission from the lander.'],
        TR: ["27 Eylül 1997'de temas kesildi; büyük olasılıkla batarya tükenince iniş aracı çalışamayacak kadar soğudu.", "Hava yastıklarıyla zıplayarak indi ve Mars'taki ilk tekerlekli gezgin Sojourner'ı bıraktı; iniş aracına Carl Sagan Anma İstasyonu adı verildi.", 'Delta II ile fırlatıldı.', "Ares Vallis'e hava yastıklı iniş; Sojourner iki gün sonra yüzeye iner.", 'İniş aracından son veri yayını.'],
        ZH: ['1997年9月27日失去联系，很可能是电池耗尽后着陆器温度过低无法工作。', '借助气囊弹跳着陆，释放了火星上第一辆轮式巡视车“索杰纳”；着陆器被命名为卡尔·萨根纪念站。', '由德尔塔二号发射。', '在阿瑞斯谷以气囊着陆，两天后索杰纳驶上地面。', '着陆器最后一次传输数据。'],
        HI: ['27 सितंबर 1997 को संपर्क टूटा, संभवतः बैटरी ख़त्म होने से लैंडर बहुत ठंडा हो गया।', 'एयरबैग से उछलकर उतरा और मंगल पर पहला पहियेदार रोवर सोजॉर्नर उतारा; लैंडर का नाम कार्ल सैगन मेमोरियल स्टेशन है।', 'डेल्टा II से प्रक्षेपित।', 'एरेस वैलिस में एयरबैग लैंडिंग; दो दिन बाद सोजॉर्नर उतरा।', 'लैंडर से अंतिम डेटा प्रसारण।'],
        ES: ['El contacto se perdió el 27 de septiembre de 1997, probablemente porque el agotamiento de la batería dejó al módulo demasiado frío para operar.', 'Aterrizó rebotando sobre bolsas de aire y desplegó Sojourner, el primer rover con ruedas en Marte; el módulo se llama Estación Memorial Carl Sagan.', 'Lanzado en un Delta II.', 'Aterrizaje con bolsas de aire en Ares Vallis; Sojourner sale dos días después.', 'Última transmisión de datos del módulo.'],
        FR: ["Le contact a été perdu le 27 septembre 1997, sans doute parce que la batterie épuisée a laissé l'atterrisseur trop froid pour fonctionner.", "Posé en rebondissant sur des airbags, il a déployé Sojourner, le premier rover à roues sur Mars ; l'atterrisseur porte le nom de Carl Sagan Memorial Station.", 'Lancé par une Delta II.', 'Atterrissage sur airbags dans Ares Vallis ; Sojourner descend deux jours plus tard.', "Dernière transmission de données de l'atterrisseur."],
        RU: ["Связь потеряна 27 сентября 1997 года, скорее всего потому, что после разряда батареи станция слишком остыла для работы.", "Сел с отскоками на надувных подушках и выпустил «Соджорнер» — первый колёсный марсоход; станция названа в честь Карла Сагана.", "Запущен ракетой «Дельта II».", "Посадка на подушках в долине Арес; через два дня «Соджорнер» съезжает на грунт.", "Последняя передача данных со станции."]
      }
    },
    {
      id: 'spirit', body: 'MARS', cat: 'R1', model: 'mer', agency: 'NASA / JPL', nssdc: '2003-027A', wiki: 'Spirit_(rover)',
      name: { RU: "Спирит (MER-A)", EN: 'Spirit (MER-A)', TR: 'Spirit (MER-A)', ZH: '勇气号火星车', HI: 'स्पिरिट (MER-A)' }, site: 'Gusev crater', lat: -14.57, lon: 175.47,
      launch: '2003-06-10', arrive: '2004-01-04', end: '2010-03-22', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['2003-06-10', '2004-01-04', '2009-05', '2010-03-22'],
      tx: {
        EN: ['Became embedded in soft soil at a site called Troy in 2009; last contact was on 22 March 2010 and the mission ended in May 2011.', 'Operated for more than six years against a 90-sol design life and found evidence of past hot water in Gusev crater.', 'Launched on a Delta II.', 'Airbag landing in Gusev crater.', 'Wheels break through crust at Troy; it becomes stuck.', 'Last communication before Martian winter.'],
        TR: ["2009'da Troy adlı bölgede yumuşak toprağa saplandı; son temas 22 Mart 2010'da kuruldu ve görev Mayıs 2011'de sona erdi.", '90 sollük tasarım ömrüne karşı altı yıldan fazla çalıştı ve Gusev kraterinde geçmişte sıcak su bulunduğuna dair kanıt buldu.', 'Delta II ile fırlatıldı.', 'Gusev kraterine hava yastıklı iniş.', "Tekerlekler Troy'da kabuğu kırar; araç saplanır.", 'Mars kışından önceki son iletişim.'],
        ZH: ['2009年陷入名为“特洛伊”的松软土壤；最后一次联系为2010年3月22日，任务于2011年5月结束。', '设计寿命90个火星日，实际运行超过六年，并在古谢夫撞击坑发现了过去存在热水的证据。', '由德尔塔二号发射。', '在古谢夫撞击坑以气囊着陆。', '车轮在“特洛伊”压破表层后陷住。', '火星冬季来临前的最后一次通信。'],
        HI: ['2009 में ट्रॉय नामक स्थान पर नरम मिट्टी में फँस गया; अंतिम संपर्क 22 मार्च 2010 को हुआ और मिशन मई 2011 में समाप्त हुआ।', '90 सोल के डिज़ाइन जीवन के मुकाबले छह वर्ष से अधिक काम किया और गुसेव क्रेटर में अतीत के गर्म जल के प्रमाण पाए।', 'डेल्टा II से प्रक्षेपित।', 'गुसेव क्रेटर में एयरबैग लैंडिंग।', 'ट्रॉय में पहिये परत तोड़कर धँस गए; रोवर फँस गया।', 'मंगल की सर्दी से पहले अंतिम संचार।'],
        ES: ['Quedó atrapado en suelo blando en un lugar llamado Troy en 2009; el último contacto fue el 22 de marzo de 2010 y la misión terminó en mayo de 2011.', 'Funcionó más de seis años frente a una vida útil prevista de 90 soles y halló indicios de agua caliente en el pasado del cráter Gusev.', 'Lanzado en un Delta II.', 'Aterrizaje con bolsas de aire en el cráter Gusev.', 'Las ruedas rompen la costra en Troy y queda atascado.', 'Última comunicación antes del invierno marciano.'],
        FR: ["S'est enlisé dans un sol meuble sur un site nommé Troy en 2009 ; le dernier contact date du 22 mars 2010 et la mission s'est achevée en mai 2011.", "A fonctionné plus de six ans pour une durée prévue de 90 sols et a trouvé des indices d'eau chaude passée dans le cratère Gusev.", 'Lancé par une Delta II.', 'Atterrissage sur airbags dans le cratère Gusev.', "Les roues percent la croûte à Troy ; il s'enlise.", "Dernière communication avant l'hiver martien."],
        RU: ["В 2009 году увяз в рыхлом грунте в месте под названием Троя; последняя связь — 22 марта 2010 года, миссия завершена в мае 2011 года.", "Проработал более шести лет при расчётном сроке 90 солов и нашёл следы древней горячей воды в кратере Гусев.", "Запущен ракетой «Дельта II».", "Посадка на подушках в кратере Гусев.", "Колёса проламывают корку в Трое; марсоход застревает.", "Последняя связь перед марсианской зимой."]
      }
    },
    {
      id: 'opportunity', body: 'MARS', cat: 'R1', model: 'mer', agency: 'NASA / JPL', nssdc: '2003-032A', wiki: 'Opportunity_(rover)',
      name: { RU: "Оппортьюнити (MER-B)", EN: 'Opportunity (MER-B)', TR: 'Opportunity (MER-B)', ZH: '机遇号火星车', HI: 'ऑपर्च्युनिटी (MER-B)' }, site: 'Meridiani Planum', lat: -1.95, lon: -5.53,
      launch: '2003-07-07', arrive: '2004-01-25', end: '2018-06-10', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['2003-07-07', '2004-01-25', '2018-06-10', '2019-02-13'],
      tx: {
        EN: ['A planet-encircling dust storm in 2018 blocked sunlight to its solar panels; it never responded again.', 'Drove more than 45 km over about 14 years, a record for off-Earth driving at the time, and found evidence of ancient water at Meridiani Planum.', 'Launched on a Delta II Heavy.', 'Lands in Eagle crater, Meridiani Planum.', 'Last contact as the global dust storm intensifies.', 'NASA declares the mission complete after more than 1,000 recovery commands.'],
        TR: ["2018'deki gezegeni saran toz fırtınası güneş panellerine ulaşan ışığı kesti; bir daha yanıt vermedi.", "Yaklaşık 14 yılda 45 km'den fazla yol aldı (döneminin rekoru) ve Meridiani Planum'da eski suyun kanıtlarını buldu.", 'Delta II Heavy ile fırlatıldı.', "Meridiani Planum'daki Eagle kraterine iner.", 'Küresel toz fırtınası şiddetlenirken son temas.', "1.000'den fazla kurtarma komutunun ardından NASA görevi tamamlanmış ilan eder."],
        ZH: ['2018年环绕全球的沙尘暴遮挡了照射太阳能板的阳光，此后再无回应。', '约14年间行驶超过45公里，创下当时的地外行驶纪录，并在子午线高原发现古代水的证据。', '由德尔塔二号重型发射。', '降落在子午线高原的鹰撞击坑。', '全球沙尘暴加剧时最后一次通信。', '发送1000多条恢复指令后，NASA宣布任务结束。'],
        HI: ['2018 में ग्रह को घेरने वाले धूल-तूफ़ान ने सौर पैनलों तक धूप रोक दी; इसने फिर कभी जवाब नहीं दिया।', 'लगभग 14 वर्षों में 45 km से अधिक चला, जो उस समय का रिकॉर्ड था, और मेरिडियानी प्लैनम में प्राचीन जल के प्रमाण पाए।', 'डेल्टा II हेवी से प्रक्षेपित।', 'मेरिडियानी प्लैनम के ईगल क्रेटर में उतरा।', 'वैश्विक धूल-तूफ़ान तेज़ होने पर अंतिम संपर्क।', '1,000 से अधिक पुनर्प्राप्ति आदेशों के बाद NASA ने मिशन पूर्ण घोषित किया।'],
        ES: ['Una tormenta de polvo que envolvió el planeta en 2018 bloqueó la luz de sus paneles solares; nunca volvió a responder.', 'Recorrió más de 45 km en unos 14 años, récord fuera de la Tierra en su momento, y halló pruebas de agua antigua en Meridiani Planum.', 'Lanzado en un Delta II Heavy.', 'Aterriza en el cráter Eagle, Meridiani Planum.', 'Último contacto mientras se intensifica la tormenta de polvo global.', 'La NASA da por concluida la misión tras más de 1.000 comandos de recuperación.'],
        FR: ["Une tempête de poussière enveloppant la planète en 2018 a privé ses panneaux solaires de lumière ; il n'a plus jamais répondu.", "A parcouru plus de 45 km en environ 14 ans, un record hors de la Terre à l'époque, et trouvé des preuves d'eau ancienne à Meridiani Planum.", 'Lancé par une Delta II Heavy.', 'Se pose dans le cratère Eagle, Meridiani Planum.', "Dernier contact alors que la tempête globale s'intensifie.", 'La NASA déclare la mission terminée après plus de 1 000 commandes de récupération.'],
        RU: ["Глобальная пылевая буря 2018 года закрыла солнце для его панелей; больше он не отвечал.", "Проехал более 45 км примерно за 14 лет — на тот момент рекорд за пределами Земли — и нашёл следы древней воды на плато Меридиана.", "Запущен ракетой «Дельта II Heavy».", "Посадка в кратере Игл на плато Меридиана.", "Последняя связь при усилении глобальной пылевой бури.", "NASA объявляет миссию завершённой после более чем 1000 команд на восстановление."]
      }
    },
    {
      id: 'phoenix', body: 'MARS', cat: 'R1', model: 'phoenix', agency: 'NASA / JPL', nssdc: '2007-034A', wiki: 'Phoenix_(spacecraft)',
      name: { RU: "Феникс", EN: 'Phoenix', TR: 'Phoenix', ZH: '凤凰号', HI: 'फ़ीनिक्स' }, site: 'Vastitas Borealis', lat: 68.22, lon: -125.75,
      launch: '2007-08-04', arrive: '2008-05-25', end: '2008-11-02', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['2007-08-04', '2008-05-25', '2008-11-02', '2010-05'],
      tx: {
        EN: ['Northern winter cut its solar power; images in 2010 showed its solar panels broken under the weight of carbon-dioxide ice.', 'Confirmed water ice just below the surface in the Martian Arctic and detected perchlorate in the soil.', 'Launched on a Delta II.', 'Lands in Vastitas Borealis using descent thrusters.', 'Last signal as autumn darkness sets in.', 'HiRISE shows ice damage to its solar arrays.'],
        TR: ['Kuzey kışı güneş enerjisini kesti; 2010 görüntüleri güneş panellerinin karbondioksit buzunun ağırlığı altında kırıldığını gösterdi.', "Mars'ın kutup bölgesinde yüzeyin hemen altında su buzu olduğunu doğruladı ve toprakta perklorat tespit etti.", 'Delta II ile fırlatıldı.', "İniş iticileriyle Vastitas Borealis'e iner.", 'Sonbahar karanlığı çökerken son sinyal.', 'HiRISE güneş panellerindeki buz hasarını gösterir.'],
        ZH: ['北半球冬季切断了太阳能供应；2010年的图像显示其太阳能板被二氧化碳冰压坏。', '证实火星北极地区地表下方存在水冰，并在土壤中检测到高氯酸盐。', '由德尔塔二号发射。', '借助下降推进器降落在北方大平原。', '秋季黑暗来临时的最后信号。', 'HiRISE显示其太阳能板遭冰压损坏。'],
        HI: ['उत्तरी सर्दी ने इसकी सौर ऊर्जा रोक दी; 2010 के चित्रों में इसके सौर पैनल कार्बन-डाइऑक्साइड बर्फ़ के भार से टूटे दिखे।', 'मंगल के आर्कटिक क्षेत्र में सतह के ठीक नीचे जल-हिम की पुष्टि की और मिट्टी में परक्लोरेट पाया।', 'डेल्टा II से प्रक्षेपित।', 'अवतरण थ्रस्टरों से वैस्टिटास बोरियलिस में उतरा।', 'शरद ऋतु का अंधकार छाने पर अंतिम संकेत।', 'HiRISE ने सौर पैनलों पर बर्फ़ से हुई क्षति दिखाई।'],
        ES: ['El invierno boreal cortó su energía solar; imágenes de 2010 mostraron sus paneles rotos bajo el peso del hielo de dióxido de carbono.', 'Confirmó hielo de agua justo bajo la superficie en el Ártico marciano y detectó perclorato en el suelo.', 'Lanzado en un Delta II.', 'Aterriza en Vastitas Borealis con propulsores de descenso.', 'Última señal al llegar la oscuridad otoñal.', 'HiRISE muestra daños por hielo en sus paneles solares.'],
        FR: ["L'hiver boréal a coupé son énergie solaire ; des images de 2010 ont montré ses panneaux brisés sous le poids de la glace carbonique.", "A confirmé la présence de glace d'eau juste sous la surface dans l'Arctique martien et détecté du perchlorate dans le sol.", 'Lancé par une Delta II.', 'Se pose dans Vastitas Borealis grâce à ses rétrofusées.', "Dernier signal à l'arrivée de l'obscurité automnale.", 'HiRISE montre les dégâts de la glace sur ses panneaux solaires.'],
        RU: ["Северная зима лишила его солнечной энергии; снимки 2010 года показали, что панели сломались под весом льда из углекислого газа.", "Подтвердил водяной лёд прямо под поверхностью в марсианской Арктике и обнаружил перхлораты в грунте.", "Запущен ракетой «Дельта II».", "Посадка на Великой Северной равнине с помощью тормозных двигателей.", "Последний сигнал с наступлением осенней темноты.", "Камера HiRISE показывает повреждение панелей льдом."]
      }
    },
    {
      id: 'insight', body: 'MARS', cat: 'R1', model: 'insight', agency: 'NASA / JPL', nssdc: '2018-042A', wiki: 'InSight',
      name: { EN: 'InSight', ZH: '洞察号', HI: 'इनसाइट' }, site: 'Elysium Planitia', lat: 4.50, lon: 135.62,
      launch: '2018-05-05', arrive: '2018-11-26', end: '2022-12-21', status: 'landed', sim: 'edl', outcome: 'land',
      hd: ['2018-05-05', '2018-11-26', '2019-04-06', '2022-12-21'],
      tx: {
        EN: ['Dust built up on its solar panels until it could no longer generate enough power; NASA ended the mission on 21 December 2022.', "Recorded more than 1,300 marsquakes and measured the size of Mars's core, crust and mantle.", 'Launched from Vandenberg on an Atlas V, the first interplanetary launch from the US West Coast.', 'Lands in Elysium Planitia.', 'Seismometer records the first confirmed marsquake.', 'Mission declared over after two missed communication passes.'],
        TR: ["Güneş panellerinde biriken toz yeterli enerji üretmesini engelledi; NASA görevi 21 Aralık 2022'de sonlandırdı.", "1.300'den fazla Mars depremi kaydetti ve Mars'ın çekirdeğinin, kabuğunun ve mantosunun boyutlarını ölçtü.", "ABD batı kıyısından yapılan ilk gezegenler arası fırlatmayla Vandenberg'den Atlas V ile fırlatıldı.", "Elysium Planitia'ya iner.", 'Sismometre doğrulanmış ilk Mars depremini kaydeder.', 'İki iletişim penceresi kaçırılınca görev sona erdirildi.'],
        ZH: ['太阳能板积尘，最终无法产生足够电力；NASA于2022年12月21日宣布任务结束。', '记录了1300多次火星地震，并测定了火星核、壳和幔的尺寸。', '由宇宙神五号从范登堡发射，是美国西海岸首次行星际发射。', '降落在埃律西昂平原。', '地震仪记录到首次确认的火星地震。', '连续两次通信未果后宣布任务结束。'],
        HI: ['सौर पैनलों पर धूल जमा होती गई जब तक वह पर्याप्त ऊर्जा नहीं बना सका; NASA ने 21 दिसंबर 2022 को मिशन समाप्त किया।', '1,300 से अधिक मंगल-भूकंप दर्ज किए और मंगल के कोर, क्रस्ट और मेंटल का आकार मापा।', 'वैंडेनबर्ग से एटलस V द्वारा प्रक्षेपित, अमेरिकी पश्चिमी तट से पहला अंतर्ग्रहीय प्रक्षेपण।', 'एलिसियम प्लैनिशिया में उतरा।', 'सिस्मोमीटर ने पहला पुष्ट मंगल-भूकंप दर्ज किया।', 'दो संचार अवसर चूकने के बाद मिशन समाप्त घोषित।'],
        ES: ['El polvo se acumuló en sus paneles solares hasta que no pudo generar suficiente energía; la NASA dio por terminada la misión el 21 de diciembre de 2022.', 'Registró más de 1.300 sismos marcianos y midió el tamaño del núcleo, la corteza y el manto de Marte.', 'Lanzado desde Vandenberg en un Atlas V, el primer lanzamiento interplanetario desde la costa oeste de EE. UU.', 'Aterriza en Elysium Planitia.', 'El sismómetro registra el primer sismo marciano confirmado.', 'Misión concluida tras dos pases de comunicación sin respuesta.'],
        FR: ["La poussière s'est accumulée sur ses panneaux solaires jusqu'à ce qu'il ne produise plus assez d'énergie ; la NASA a clos la mission le 21 décembre 2022.", 'A enregistré plus de 1 300 séismes martiens et mesuré la taille du noyau, de la croûte et du manteau de Mars.', 'Lancé depuis Vandenberg par une Atlas V, premier lancement interplanétaire depuis la côte ouest des États-Unis.', 'Se pose dans Elysium Planitia.', 'Le sismomètre enregistre le premier séisme martien confirmé.', 'Mission déclarée terminée après deux sessions de communication manquées.'],
        RU: ["Пыль на солнечных панелях копилась, пока энергии не перестало хватать; NASA завершило миссию 21 декабря 2022 года.", "Зарегистрировал более 1300 марсотрясений и измерил размеры ядра, коры и мантии Марса.", "Запущен с базы Ванденберг ракетой «Атлас V» — первый межпланетный старт с западного побережья США.", "Посадка на равнине Элизий.", "Сейсмометр регистрирует первое подтверждённое марсотрясение.", "Миссия объявлена завершённой после двух пропущенных сеансов связи."]
      }
    },
    {
      id: 'ingenuity', body: 'MARS', cat: 'R1', model: 'ingenuity', agency: 'NASA / JPL', nssdc: '2020-052A', wiki: 'Ingenuity_(helicopter)',
      name: { RU: "Индженьюити", EN: 'Ingenuity', ZH: '机智号直升机', HI: 'इंजेन्युइटी' }, site: 'Jezero crater', lat: 18.4, lon: 77.5,
      launch: '2020-07-30', arrive: '2021-02-18', end: '2024-01-18', status: 'landed', sim: 'flight',
      hd: ['2020-07-30', '2021-04-19', '2024-01-18', '2024-01-25'],
      tx: {
        EN: ['Rotor blade damage during its 72nd flight left it unable to fly; it remains on the surface as a stationary testbed.', 'The first powered, controlled flight on another planet; planned for five flights, it flew 72.', "Launched attached to the Perseverance rover's belly.", 'First flight in Jezero crater, about 39 seconds.', '72nd flight ends with rotor damage.', 'NASA announces the end of flight operations.'],
        TR: ['72. uçuşundaki pervane kanadı hasarı onu uçamaz hale getirdi; yüzeyde sabit bir test platformu olarak duruyor.', 'Başka bir gezegende ilk motorlu ve kontrollü uçuş; beş uçuş için planlandı, 72 kez uçtu.', 'Perseverance gezgininin altına bağlı olarak fırlatıldı.', 'Jezero kraterinde yaklaşık 39 saniyelik ilk uçuş.', '72. uçuş pervane hasarıyla biter.', 'NASA uçuş operasyonlarının sona erdiğini duyurur.'],
        ZH: ['第72次飞行中旋翼叶片受损，无法再飞行；它作为固定测试平台留在火星表面。', '首次在另一颗行星上实现有动力的受控飞行；原计划飞行5次，实际飞行72次。', '挂载在毅力号火星车腹部发射。', '在耶泽罗撞击坑完成约39秒的首飞。', '第72次飞行以旋翼受损告终。', 'NASA宣布飞行任务结束。'],
        HI: ['72वीं उड़ान में रोटर ब्लेड क्षतिग्रस्त होने से यह उड़ नहीं सकता; यह सतह पर स्थिर परीक्षण मंच के रूप में है।', 'किसी अन्य ग्रह पर पहली संचालित, नियंत्रित उड़ान; पाँच उड़ानों की योजना थी, इसने 72 उड़ानें भरीं।', 'पर्सिवियरेंस रोवर के नीचे जुड़ा हुआ प्रक्षेपित।', 'जेज़ेरो क्रेटर में लगभग 39 सेकंड की पहली उड़ान।', '72वीं उड़ान रोटर क्षति के साथ समाप्त।', 'NASA ने उड़ान संचालन समाप्ति की घोषणा की।'],
        ES: ['Daños en las palas del rotor durante su 72.º vuelo lo dejaron sin poder volar; permanece en la superficie como banco de pruebas fijo.', 'El primer vuelo propulsado y controlado en otro planeta; previsto para cinco vuelos, realizó 72.', 'Lanzado sujeto bajo el rover Perseverance.', 'Primer vuelo en el cráter Jezero, de unos 39 segundos.', 'El 72.º vuelo termina con daños en el rotor.', 'La NASA anuncia el fin de las operaciones de vuelo.'],
        FR: ["Des pales de rotor endommagées lors de son 72e vol l'empêchent de voler ; il reste en surface comme banc d'essai fixe.", 'Le premier vol motorisé et contrôlé sur une autre planète ; prévu pour cinq vols, il en a effectué 72.', 'Lancé fixé sous le rover Perseverance.', "Premier vol dans le cratère Jezero, d'environ 39 secondes.", 'Le 72e vol se termine avec un rotor endommagé.', 'La NASA annonce la fin des opérations de vol.'],
        RU: ["Повреждение лопастей винта в 72-м полёте лишило его способности летать; он остаётся на поверхности как неподвижный испытательный стенд.", "Первый управляемый полёт с двигателем на другой планете; планировалось пять полётов, а совершено 72.", "Доставлен на Марс под днищем марсохода «Персеверанс».", "Первый полёт в кратере Езеро, около 39 секунд.", "72-й полёт заканчивается повреждением винта.", "NASA объявляет о завершении лётных операций."]
      }
    },
    /* ============================ MARS - lost on arrival ============================ */
    {
      id: 'mars3', body: 'MARS', cat: 'R2', model: 'mars3', agency: 'USSR', nssdc: '1971-049F', wiki: 'Mars_3',
      name: { RU: "Марс-3 (посадочный модуль)", EN: 'Mars 3 Lander', TR: 'Mars 3 İniş Aracı', ZH: '火星3号着陆器', HI: 'मार्स 3 लैंडर', ES: 'Mars 3 (módulo)', FR: 'Atterrisseur Mars 3' }, site: 'Ptolemaeus crater', lat: -45, lon: -158,
      launch: '1971-05-28', arrive: '1971-12-02', end: '1971-12-02', status: 'lost', sim: 'edl', outcome: 'lost',
      hd: ['1971-05-28', '1971-12-02', '1971-12-02'],
      tx: {
        EN: ['Transmission stopped about 20 seconds after landing, possibly due to a global dust storm; the cause remains uncertain.', 'The first spacecraft to achieve a soft landing on Mars.', 'Launched from Baikonur on a Proton.', 'Lander separates and enters the atmosphere during a planet-wide dust storm.', 'Lands and begins transmitting, then falls silent within seconds.'],
        TR: ['İnişten yaklaşık 20 saniye sonra yayın kesildi; olası neden küresel toz fırtınası, kesin neden bilinmiyor.', "Mars'a yumuşak iniş yapan ilk uzay aracı.", "Baykonur'dan Proton ile fırlatıldı.", 'İniş modülü ayrılır ve gezegen çapında bir toz fırtınası sırasında atmosfere girer.', 'İner, yayına başlar ve saniyeler içinde susar.'],
        ZH: ['着陆约20秒后信号中断，可能与全球性沙尘暴有关，确切原因仍不明。', '首个在火星实现软着陆的航天器。', '由质子号火箭从拜科努尔发射。', '着陆器分离，在全球性沙尘暴期间进入大气层。', '着陆并开始传输，数秒后陷入沉寂。'],
        HI: ['लैंडिंग के लगभग 20 सेकंड बाद प्रसारण रुक गया, संभवतः वैश्विक धूल-तूफ़ान के कारण; कारण अनिश्चित है।', 'मंगल पर सॉफ्ट लैंडिंग करने वाला पहला यान।', 'बैकोनूर से प्रोटॉन द्वारा प्रक्षेपित।', 'लैंडर अलग हुआ और ग्रह-व्यापी धूल-तूफ़ान के दौरान वायुमंडल में प्रवेश किया।', 'उतरकर प्रसारण शुरू किया, फिर कुछ सेकंड में मौन हो गया।'],
        ES: ['La transmisión se detuvo unos 20 segundos tras el aterrizaje, quizá por una tormenta de polvo global; la causa sigue sin aclararse.', 'La primera nave en lograr un aterrizaje suave en Marte.', 'Lanzado desde Baikonur en un Protón.', 'El módulo se separa y entra en la atmósfera durante una tormenta de polvo planetaria.', 'Aterriza, empieza a transmitir y enmudece en segundos.'],
        FR: ["La transmission s'est arrêtée environ 20 secondes après l'atterrissage, peut-être à cause d'une tempête de poussière globale ; la cause reste incertaine.", 'Le premier engin à réussir un atterrissage en douceur sur Mars.', 'Lancé depuis Baïkonour par une Proton.', "L'atterrisseur se sépare et entre dans l'atmosphère pendant une tempête de poussière planétaire.", 'Il se pose, commence à émettre puis se tait en quelques secondes.'],
        RU: ["Передача прекратилась примерно через 20 секунд после посадки, возможно из-за глобальной пылевой бури; причина до сих пор неясна.", "Первый аппарат, совершивший мягкую посадку на Марс.", "Запущен с Байконура ракетой «Протон».", "Спускаемый аппарат отделяется и входит в атмосферу во время глобальной пылевой бури.", "Садится и начинает передачу, затем через несколько секунд замолкает."]
      }
    },
    {
      id: 'mco', body: 'MARS', cat: 'R2', model: 'mco', agency: 'NASA / JPL', nssdc: '1998-073A', wiki: 'Mars_Climate_Orbiter',
      name: { EN: 'Mars Climate Orbiter', ZH: '火星气候探测者号', HI: 'मार्स क्लाइमेट ऑर्बिटर' }, site: 'periapsis ≈ 57 km',
      approach: { peri: 57 },
      launch: '1998-12-11', arrive: '1999-09-23', end: '1999-09-23', status: 'lost', sim: 'entry',
      hd: ['1998-12-11', '1999-09-23', '1999-11'],
      tx: {
        EN: ['Navigation software on the ground produced thruster data in pound-force seconds instead of newton-seconds; the orbiter arrived far too low and was destroyed or skipped into space.', 'Became the classic case study of why engineering teams must agree on units.', 'Launched on a Delta II.', 'Orbit insertion burn; signal lost behind Mars and never regained.', 'Investigation board identifies the imperial-metric unit mismatch.'],
        TR: ['Yerdeki seyir yazılımı itici verilerini newton-saniye yerine pound-kuvvet-saniye cinsinden üretti; araç çok alçaktan geldi ve yok oldu ya da uzaya sekti.', 'Mühendislik ekiplerinin birimlerde neden uzlaşması gerektiğinin klasik örneği oldu.', 'Delta II ile fırlatıldı.', "Yörüngeye giriş ateşlemesi; sinyal Mars'ın arkasında kayboldu ve bir daha alınamadı.", 'Soruşturma kurulu emperyal-metrik birim uyuşmazlığını tespit eder.'],
        ZH: ['地面导航软件以磅力·秒而非牛顿·秒输出推力数据，导致探测器到达高度过低，被毁或弹回太空。', '成为工程团队必须统一单位的经典案例。', '由德尔塔二号发射。', '入轨点火；信号在火星背面消失后再未恢复。', '调查委员会查明英制与公制单位不匹配。'],
        HI: ['ज़मीनी नेविगेशन सॉफ़्टवेयर ने थ्रस्टर डेटा न्यूटन-सेकंड के बजाय पाउंड-बल-सेकंड में दिया; यान बहुत नीचे पहुँचा और नष्ट हो गया या अंतरिक्ष में उछल गया।', 'यह इस बात का क्लासिक उदाहरण बना कि इंजीनियरिंग टीमों को इकाइयों पर सहमत क्यों होना चाहिए।', 'डेल्टा II से प्रक्षेपित।', 'कक्षा-प्रवेश दहन; मंगल के पीछे संकेत खोया और फिर नहीं मिला।', 'जाँच बोर्ड ने इंपीरियल-मीट्रिक इकाई असंगति पहचानी।'],
        ES: ['El software de navegación en tierra entregó datos de empuje en libras-fuerza por segundo en lugar de newton-segundo; la nave llegó demasiado baja y se destruyó o rebotó al espacio.', 'Se convirtió en el caso clásico de por qué los equipos de ingeniería deben acordar las unidades.', 'Lanzado en un Delta II.', 'Maniobra de inserción orbital; la señal se perdió tras Marte y nunca regresó.', 'La junta investigadora identifica la discrepancia entre unidades imperiales y métricas.'],
        FR: ['Le logiciel de navigation au sol fournissait les données de poussée en livres-force seconde au lieu de newtons-seconde ; la sonde est arrivée bien trop bas et a été détruite ou renvoyée dans l\'espace.', "Devenu le cas d'école montrant pourquoi les équipes d'ingénierie doivent s'accorder sur les unités.", 'Lancé par une Delta II.', "Manœuvre d'insertion en orbite ; signal perdu derrière Mars, jamais retrouvé.", "La commission d'enquête identifie l'erreur entre unités impériales et métriques."],
        RU: ["Наземная навигационная программа выдавала данные о тяге в фунт-сила-секундах вместо ньютон-секунд; аппарат подошёл слишком низко и разрушился или ушёл в космос.", "Стал хрестоматийным примером того, почему инженерные команды должны договариваться о единицах измерения.", "Запущен ракетой «Дельта II».", "Манёвр выхода на орбиту; сигнал пропал за Марсом и больше не появился.", "Комиссия по расследованию выявляет путаницу имперских и метрических единиц."]
      }
    },
    {
      id: 'mpl', body: 'MARS', cat: 'R2', model: 'mpl', agency: 'NASA / JPL', nssdc: '1999-001A', wiki: 'Mars_Polar_Lander',
      name: { EN: 'Mars Polar Lander', ZH: '火星极地着陆器', HI: 'मार्स पोलर लैंडर' }, site: 'Planum Australe (target)', lat: -76.0, lon: 165.0,
      launch: '1999-01-03', arrive: '1999-12-03', end: '1999-12-03', status: 'lost', sim: 'edl', outcome: 'lost',
      hd: ['1999-01-03', '1999-12-03', '2000-03'],
      tx: {
        EN: ['Contact was lost during descent on 3 December 1999; the most probable cause was premature engine shutdown triggered by spurious landing-leg sensor signals.', "Its loss reshaped NASA's Mars program, and the lessons were applied to the Phoenix lander that reached the northern plains in 2008.", 'Launched on a Delta II with two Deep Space 2 penetrator probes.', 'Contact lost during entry, descent and landing.', 'Failure review points to spurious touchdown signals from the legs.'],
        TR: ["3 Aralık 1999'da iniş sırasında temas kesildi; en olası neden bacak sensörlerinin sahte sinyalleriyle motorun erken kapanmasıydı.", "Kaybı NASA'nın Mars programını yeniden şekillendirdi; dersleri 2008'de kuzey ovalarına inen Phoenix'e uygulandı.", 'İki Deep Space 2 delici sondası ile birlikte Delta II ile fırlatıldı.', 'Giriş, iniş ve konma sırasında temas kesildi.', 'Başarısızlık incelemesi bacaklardan gelen sahte temas sinyallerini işaret eder.'],
        ZH: ['1999年12月3日在下降过程中失联；最可能的原因是着陆腿传感器的虚假信号导致发动机过早关机。', '它的失败重塑了NASA的火星计划，经验教训被应用于2008年抵达北部平原的“凤凰”号着陆器。', '由德尔塔二号发射，携带两个深空2号穿透器。', '在进入、下降与着陆期间失去联系。', '故障调查指向着陆腿产生的虚假触地信号。'],
        HI: ['3 दिसंबर 1999 को अवतरण के दौरान संपर्क टूटा; सबसे संभावित कारण लैंडिंग-पैर सेंसर के झूठे संकेतों से इंजन का समय से पहले बंद होना था।', 'इसकी हानि ने NASA के मंगल कार्यक्रम को नया रूप दिया, और सबक 2008 में उत्तरी मैदानों में उतरे फ़ीनिक्स लैंडर में लागू किए गए।', 'दो डीप स्पेस 2 भेदक यानों के साथ डेल्टा II से प्रक्षेपित।', 'प्रवेश, अवतरण और लैंडिंग के दौरान संपर्क टूटा।', 'विफलता समीक्षा ने पैरों से मिले झूठे स्पर्श-संकेतों की ओर इशारा किया।'],
        ES: ['Se perdió el contacto durante el descenso el 3 de diciembre de 1999; la causa más probable fue el apagado prematuro del motor por señales espurias de los sensores de las patas.', 'Su pérdida transformó el programa marciano de la NASA y sus lecciones se aplicaron al módulo Phoenix, que llegó a las llanuras del norte en 2008.', 'Lanzado en un Delta II con dos penetradores Deep Space 2.', 'Se pierde el contacto durante la entrada, descenso y aterrizaje.', 'La revisión del fallo apunta a señales de contacto espurias de las patas.'],
        FR: ['Le contact a été perdu pendant la descente le 3 décembre 1999 ; la cause la plus probable est un arrêt prématuré du moteur déclenché par de faux signaux des capteurs des jambes.', "Sa perte a remodelé le programme martien de la NASA, et les leçons ont servi à l'atterrisseur Phoenix, arrivé dans les plaines du nord en 2008.", 'Lancé par une Delta II avec deux pénétrateurs Deep Space 2.', "Contact perdu pendant l'entrée, la descente et l'atterrissage.", "L'enquête désigne de faux signaux de contact provenant des jambes."],
        RU: ["Связь потеряна при спуске 3 декабря 1999 года; наиболее вероятная причина — преждевременное отключение двигателей из-за ложных сигналов датчиков посадочных опор.", "Его потеря изменила марсианскую программу NASA, а уроки были учтены в аппарате «Феникс», севшем на северных равнинах в 2008 году.", "Запущен ракетой «Дельта II» с двумя зондами-пенетраторами Deep Space 2.", "Связь потеряна при входе, спуске и посадке.", "Расследование указывает на ложные сигналы касания от опор."]
      }
    },
    {
      id: 'beagle2', body: 'MARS', cat: 'R2', model: 'beagle2', agency: 'ESA / UK', nssdc: '2003-022C', wiki: 'Beagle_2',
      name: { RU: "Бигль-2", EN: 'Beagle 2', ZH: '猎兔犬2号', HI: 'बीगल 2' }, site: 'Isidis Planitia', lat: 11.53, lon: 90.43,
      launch: '2003-06-02', arrive: '2003-12-25', end: '2003-12-25', status: 'lost', sim: 'edl', outcome: 'lost',
      hd: ['2003-06-02', '2003-12-25', '2015-01-16'],
      tx: {
        EN: ['Landed but never called home: HiRISE images show that not all of its solar panels unfolded, blocking the antenna.', "Found intact on the surface by NASA's Mars Reconnaissance Orbiter in 2015, eleven years after it was declared lost.", "Launched aboard ESA's Mars Express on a Soyuz-Fregat.", 'Separates from Mars Express and lands on Christmas Day; no signal.', 'HiRISE images reveal the lander partly deployed in Isidis Planitia.'],
        TR: ['İndi ama hiç sinyal göndermedi: HiRISE görüntüleri güneş panellerinin hepsinin açılmadığını ve antenin kapandığını gösteriyor.', "Kayıp ilan edilmesinden on bir yıl sonra, 2015'te NASA'nın Mars Keşif Yörünge Aracı tarafından yüzeyde bulundu.", "ESA'nın Mars Express aracıyla Soyuz-Fregat üzerinde fırlatıldı.", "Mars Express'ten ayrılır ve Noel günü iner; sinyal yok.", "HiRISE görüntüleri Isidis Planitia'da kısmen açılmış aracı ortaya koyar."],
        ZH: ['成功着陆却从未联系地球：HiRISE图像显示其太阳能板未全部展开，遮挡了天线。', '在被宣布失踪11年后，于2015年由NASA火星勘测轨道器在火星表面找到。', '搭载于欧空局火星快车，由联盟-弗雷加特火箭发射。', '与火星快车分离，于圣诞节着陆，但无信号。', 'HiRISE图像显示其在伊西底斯平原部分展开。'],
        HI: ['उतरा पर कभी संपर्क नहीं किया: HiRISE चित्र दिखाते हैं कि इसके सभी सौर पैनल नहीं खुले, जिससे एंटीना ढक गया।', 'खोया घोषित होने के ग्यारह वर्ष बाद, 2015 में NASA के मार्स रिकॉनिसेंस ऑर्बिटर ने इसे सतह पर खोजा।', 'ESA के मार्स एक्सप्रेस के साथ सोयुज़-फ़्रेगाट से प्रक्षेपित।', 'मार्स एक्सप्रेस से अलग होकर क्रिसमस के दिन उतरा; कोई संकेत नहीं।', 'HiRISE चित्रों में आइसिडिस प्लैनिशिया में आंशिक रूप से खुला लैंडर दिखा।'],
        ES: ['Aterrizó pero nunca llamó a casa: las imágenes de HiRISE muestran que no todos sus paneles solares se desplegaron y bloquearon la antena.', 'Fue hallado en la superficie por el Mars Reconnaissance Orbiter de la NASA en 2015, once años después de darse por perdido.', 'Lanzado a bordo del Mars Express de la ESA en un Soyuz-Fregat.', 'Se separa del Mars Express y aterriza el día de Navidad; sin señal.', 'Las imágenes de HiRISE revelan el módulo parcialmente desplegado en Isidis Planitia.'],
        FR: ["Posé mais jamais entendu : les images HiRISE montrent que tous ses panneaux solaires ne se sont pas dépliés, masquant l'antenne.", 'Retrouvé à la surface par le Mars Reconnaissance Orbiter de la NASA en 2015, onze ans après avoir été déclaré perdu.', "Lancé à bord de Mars Express de l'ESA par une Soyouz-Fregat.", 'Se sépare de Mars Express et se pose le jour de Noël ; aucun signal.', "Les images HiRISE révèlent l'atterrisseur partiellement déployé dans Isidis Planitia."],
        RU: ["Сел, но так и не вышел на связь: снимки HiRISE показывают, что раскрылись не все солнечные панели и антенна оказалась закрыта.", "Найден целым на поверхности аппаратом NASA Mars Reconnaissance Orbiter в 2015 году, через одиннадцать лет после признания потерянным.", "Запущен в составе Mars Express ЕКА ракетой «Союз-Фрегат».", "Отделяется от Mars Express и садится в Рождество; сигнала нет.", "Снимки HiRISE показывают частично раскрытый аппарат на равнине Исиды."]
      }
    },
    /* ============================ MARS - silent orbiters ============================ */
    {
      id: 'mariner9', body: 'MARS', cat: 'R3', model: 'mariner9', agency: 'NASA / JPL', nssdc: '1971-051A', wiki: 'Mariner_9',
      name: { RU: "Маринер-9", EN: 'Mariner 9', ZH: '水手9号', HI: 'मैरिनर 9' }, site: '1,650 x 16,860 km / i 64.4°',
      orbit: { rp: 1650, ra: 16860, inc: 64.4, raan: 40, argp: 30, M0: 0.4 },
      launch: '1971-05-30', arrive: '1971-11-14', end: '1972-10-27', status: 'orbit', sim: 'decay',
      hd: ['1971-05-30', '1971-11-14', '1972-10-27'],
      tx: {
        EN: ['Switched off on 27 October 1972 after its attitude-control gas ran out; left in a decaying orbit that was projected to reach the atmosphere around 2022.', 'The first spacecraft to orbit another planet; it mapped about 85% of Mars and revealed Valles Marineris and the great volcanoes.', 'Launched on an Atlas-Centaur.', 'Enters orbit as a global dust storm hides the surface.', 'Switched off after returning 7,329 images.'],
        TR: ["Yönelim kontrol gazı bitince 27 Ekim 1972'de kapatıldı; atmosfere 2022 civarında ulaşması öngörülen alçalan bir yörüngede bırakıldı.", "Başka bir gezegenin yörüngesine giren ilk uzay aracı; Mars'ın yaklaşık %85'ini haritaladı, Valles Marineris'i ve dev volkanları ortaya çıkardı.", 'Atlas-Centaur ile fırlatıldı.', 'Küresel bir toz fırtınası yüzeyi gizlerken yörüngeye girer.', '7.329 görüntü gönderdikten sonra kapatıldı.'],
        ZH: ['姿态控制气体耗尽后于1972年10月27日关机，留在逐渐衰减的轨道上，预计约2022年进入大气层。', '首个环绕另一颗行星运行的航天器，测绘了约85%的火星表面，揭示了水手号峡谷和巨型火山。', '由宇宙神-半人马座火箭发射。', '在全球沙尘暴遮蔽地表时进入轨道。', '传回7329幅图像后关机。'],
        HI: ['अभिवृत्ति-नियंत्रण गैस समाप्त होने पर 27 अक्टूबर 1972 को बंद किया गया; ऐसी घटती कक्षा में छोड़ा गया जिसके लगभग 2022 तक वायुमंडल में पहुँचने का अनुमान था।', 'किसी अन्य ग्रह की परिक्रमा करने वाला पहला यान; इसने मंगल के लगभग 85% भाग का मानचित्रण किया और वैलेस मैरिनेरिस व विशाल ज्वालामुखी दिखाए।', 'एटलस-सेंटॉर से प्रक्षेपित।', 'वैश्विक धूल-तूफ़ान के बीच कक्षा में प्रवेश।', '7,329 चित्र भेजने के बाद बंद किया गया।'],
        ES: ['Se apagó el 27 de octubre de 1972 al agotarse el gas de control de actitud; quedó en una órbita en descenso que debía alcanzar la atmósfera hacia 2022.', 'La primera nave en orbitar otro planeta; cartografió cerca del 85 % de Marte y reveló Valles Marineris y los grandes volcanes.', 'Lanzado en un Atlas-Centaur.', 'Entra en órbita mientras una tormenta de polvo global oculta la superficie.', 'Apagado tras enviar 7.329 imágenes.'],
        FR: ["Éteint le 27 octobre 1972 après épuisement de son gaz de contrôle d'attitude ; laissé sur une orbite qui devait atteindre l'atmosphère vers 2022.", "Le premier engin à orbiter autour d'une autre planète ; il a cartographié environ 85 % de Mars et révélé Valles Marineris et les grands volcans.", 'Lancé par une Atlas-Centaur.', 'Mise en orbite alors qu\'une tempête de poussière globale masque la surface.', 'Éteint après avoir transmis 7 329 images.'],
        RU: ["Выключен 27 октября 1972 года после исчерпания газа системы ориентации; оставлен на снижающейся орбите, которая, по расчётам, должна была достичь атмосферы около 2022 года.", "Первый аппарат на орбите другой планеты; картографировал около 85% Марса и открыл долины Маринер и великие вулканы.", "Запущен ракетой «Атлас-Центавр».", "Выходит на орбиту, когда глобальная пылевая буря скрывает поверхность.", "Выключен после передачи 7329 снимков."]
      }
    },
    {
      id: 'mgs', body: 'MARS', cat: 'R3', model: 'mgs', agency: 'NASA / JPL', nssdc: '1996-062A', wiki: 'Mars_Global_Surveyor',
      name: { EN: 'Mars Global Surveyor', ZH: '火星全球勘测者号', HI: 'मार्स ग्लोबल सर्वेयर' }, site: '≈ 378 km / i 92.9°',
      orbit: { rp: 370, ra: 435, inc: 92.9, raan: 200, argp: 0, M0: 2.6 },
      launch: '1996-11-07', arrive: '1997-09-12', end: '2006-11-02', status: 'orbit', sim: 'decay',
      hd: ['1996-11-07', '1997-09-12', '2006-11-02'],
      tx: {
        EN: ['An erroneous memory update months earlier caused a safe-mode orientation that overheated the battery; contact was lost on 2 November 2006.', 'Mapped Mars for nine years, including laser-altimeter topography and gully images suggesting recent fluid flow.', 'Launched on a Delta II.', 'Enters orbit and pioneers aerobraking at Mars.', 'Last contact; it remains in orbit as a silent derelict.'],
        TR: ['Aylar önceki hatalı bir bellek güncellemesi, bataryayı aşırı ısıtan bir güvenli mod yönelimine yol açtı; 2 Kasım 2006\'da temas kesildi.', "Lazer altimetre topografyası ve yakın geçmişte akışkan hareketine işaret eden oluk görüntüleri dahil, Mars'ı dokuz yıl boyunca haritaladı.", 'Delta II ile fırlatıldı.', "Yörüngeye girer ve Mars'ta aerofrenlemenin öncüsü olur.", 'Son temas; sessiz bir hurda olarak yörüngede kalır.'],
        ZH: ['数月前一次错误的内存更新导致安全模式下的姿态使电池过热，2006年11月2日失去联系。', '测绘火星长达九年，包括激光高度计地形图以及暗示近期流体活动的冲沟图像。', '由德尔塔二号发射。', '进入轨道并率先在火星使用大气制动。', '最后一次通信；作为沉寂的废弃物留在轨道上。'],
        HI: ['महीनों पहले की एक त्रुटिपूर्ण मेमोरी अपडेट से सुरक्षित-मोड में ऐसी दिशा बनी जिससे बैटरी ज़्यादा गर्म हो गई; 2 नवंबर 2006 को संपर्क टूटा।', 'नौ वर्षों तक मंगल का मानचित्रण किया, जिसमें लेज़र अल्टीमीटर स्थलाकृति और हाल के द्रव प्रवाह का संकेत देने वाली नालियों के चित्र शामिल हैं।', 'डेल्टा II से प्रक्षेपित।', 'कक्षा में प्रवेश और मंगल पर एयरोब्रेकिंग का अग्रणी उपयोग।', 'अंतिम संपर्क; मौन मलबे के रूप में कक्षा में।'],
        ES: ['Una actualización de memoria errónea meses antes provocó una orientación en modo seguro que sobrecalentó la batería; el contacto se perdió el 2 de noviembre de 2006.', 'Cartografió Marte durante nueve años, incluida la topografía por altímetro láser y barrancos que sugieren flujos recientes de fluidos.', 'Lanzado en un Delta II.', 'Entra en órbita y estrena el aerofrenado en Marte.', 'Último contacto; sigue en órbita como un objeto inactivo.'],
        FR: ['Une mise à jour mémoire erronée des mois plus tôt a provoqué une orientation en mode sûr qui a surchauffé la batterie ; contact perdu le 2 novembre 2006.', 'A cartographié Mars pendant neuf ans, dont la topographie par altimètre laser et des ravines suggérant des écoulements récents.', 'Lancé par une Delta II.', 'Mise en orbite et premier aérofreinage à Mars.', 'Dernier contact ; il reste en orbite, silencieux.'],
        RU: ["Ошибочное обновление памяти, сделанное за несколько месяцев до этого, привело к ориентации в безопасном режиме, при которой перегрелась батарея; связь потеряна 2 ноября 2006 года.", "Девять лет картографировал Марс, включая рельеф по лазерному альтиметру и снимки оврагов, указывающих на недавнее течение жидкости.", "Запущен ракетой «Дельта II».", "Выходит на орбиту и впервые применяет аэроторможение у Марса.", "Последняя связь; остаётся на орбите как безмолвный аппарат."]
      }
    }
  ];

  /* ---------- Discover dossiers: topics documented by NASA and Wikipedia ---------- */
  const DOSSIERS = [
    {
      id: 'heritage', body: 'MOON', craft: ['apollo11', 'apollo17'],
      links: [['Wikipedia', 'https://en.wikipedia.org/wiki/One_Small_Step_to_Protect_Human_Heritage_in_Space_Act'], ['Wikipedia', 'https://en.wikipedia.org/wiki/Tranquility_Base']],
      tx: {
        EN: ['Protecting Tranquility Base', 'Apollo landing sites hold bootprints, hardware and experiments that cannot be replaced. In 2011 NASA published recommendations asking future missions to keep their distance, and the 2020 One Small Step to Protect Human Heritage in Space Act tied those principles to US agency partnerships.'],
        TR: ['Sükûnet Üssü\'nü korumak', "Apollo iniş alanlarında yeri doldurulamayacak ayak izleri, donanım ve deneyler var. NASA 2011'de gelecekteki görevlerden mesafe korumalarını isteyen öneriler yayımladı; 2020'de çıkan One Small Step to Protect Human Heritage in Space Act bu ilkeleri ABD ajans ortaklıklarına bağladı."],
        ZH: ['保护静海基地', '阿波罗着陆点保存着无法替代的脚印、硬件和实验装置。NASA于2011年发布建议，要求未来任务保持距离；2020年的《保护太空人类遗产一小步法案》将这些原则纳入美国机构的合作协议。'],
        HI: ['ट्रैंक्विलिटी बेस की सुरक्षा', 'अपोलो लैंडिंग स्थलों पर ऐसे पदचिह्न, उपकरण और प्रयोग हैं जिन्हें बदला नहीं जा सकता। NASA ने 2011 में भविष्य के मिशनों से दूरी बनाए रखने की सिफ़ारिशें प्रकाशित कीं, और 2020 के One Small Step to Protect Human Heritage in Space Act ने इन सिद्धांतों को अमेरिकी एजेंसी साझेदारियों से जोड़ा।'],
        ES: ['Proteger la Base Tranquilidad', 'Los sitios de alunizaje del Apolo conservan huellas, equipos y experimentos irreemplazables. En 2011 la NASA publicó recomendaciones para que las futuras misiones guarden distancia, y la ley One Small Step to Protect Human Heritage in Space Act de 2020 vinculó esos principios a las alianzas de las agencias de EE. UU.'],
        FR: ['Protéger la base de la Tranquillité', "Les sites d'alunissage Apollo conservent des empreintes, du matériel et des expériences irremplaçables. En 2011, la NASA a publié des recommandations demandant aux futures missions de garder leurs distances, et la loi One Small Step to Protect Human Heritage in Space Act de 2020 a lié ces principes aux partenariats des agences américaines."],
        RU: ["Защита базы Спокойствия", "На местах посадок «Аполлонов» остались следы ботинок, оборудование и приборы, которые невозможно заменить. В 2011 году NASA опубликовало рекомендации, призывающие будущие миссии держаться на расстоянии, а принятый в 2020 году закон One Small Step to Protect Human Heritage in Space Act связал эти принципы с партнёрствами агентств США."]
      }
    },
    {
      id: 'laser', body: 'MOON', craft: ['apollo11', 'lunokhod1'],
      links: [['Wikipedia', 'https://en.wikipedia.org/wiki/Lunar_Laser_Ranging_experiments']],
      tx: {
        EN: ['Still working after half a century', 'Retroreflectors left by Apollo 11, 14 and 15 and by Lunokhod 1 and 2 still bounce laser pulses back to Earth. The measurements show the Moon slowly receding, by about 3.8 cm per year.'],
        TR: ['Yarım asır sonra hâlâ çalışıyor', "Apollo 11, 14, 15 ile Lunokhod 1 ve 2'nin bıraktığı yansıtıcılar lazer darbelerini hâlâ Dünya'ya geri gönderiyor. Ölçümler Ay'ın yılda yaklaşık 3,8 cm uzaklaştığını gösteriyor."],
        ZH: ['半个世纪后仍在工作', '阿波罗11、14、15号以及月球车1号和2号留下的反射器至今仍将激光脉冲反射回地球。测量显示月球正以每年约3.8厘米的速度远离地球。'],
        HI: ['आधी सदी बाद भी कार्यरत', 'अपोलो 11, 14 और 15 तथा लूनोखोद 1 और 2 द्वारा छोड़े गए परावर्तक आज भी लेज़र स्पंद पृथ्वी पर लौटाते हैं। माप दिखाते हैं कि चंद्रमा हर वर्ष लगभग 3.8 cm दूर जा रहा है।'],
        ES: ['Siguen funcionando medio siglo después', 'Los retrorreflectores dejados por el Apolo 11, 14 y 15 y por los Lunojod 1 y 2 aún devuelven pulsos láser a la Tierra. Las mediciones muestran que la Luna se aleja unos 3,8 cm por año.'],
        FR: ['Toujours actifs un demi-siècle plus tard', "Les rétroréflecteurs laissés par Apollo 11, 14 et 15 et par Lunokhod 1 et 2 renvoient toujours des impulsions laser vers la Terre. Les mesures montrent que la Lune s'éloigne d'environ 3,8 cm par an."],
        RU: ["Работают спустя полвека", "Отражатели, оставленные «Аполлонами» 11, 14 и 15 и «Луноходами» 1 и 2, до сих пор возвращают лазерные импульсы на Землю. Измерения показывают, что Луна медленно удаляется — примерно на 3,8 см в год."]
      }
    },
    {
      id: 'ice', body: 'MOON', craft: ['lcross', 'prospector'],
      links: [['Wikipedia', 'https://en.wikipedia.org/wiki/Lunar_water']],
      tx: {
        EN: ['Water in the shadows', "Craters near the lunar poles that never see sunlight can trap ice for billions of years. Lunar Prospector's hydrogen maps hinted at it, and the LCROSS impact plume confirmed water in Cabeus crater in 2009."],
        TR: ['Gölgelerdeki su', "Ay kutuplarının yakınında hiç güneş görmeyen kraterler buzu milyarlarca yıl saklayabilir. Lunar Prospector'ın hidrojen haritaları buna işaret etti; LCROSS'un çarpma bulutu 2009'da Cabeus kraterinde suyu doğruladı."],
        ZH: ['阴影中的水', '月球两极附近终年不见阳光的撞击坑可以将冰保存数十亿年。月球勘探者号的氢分布图给出了线索，LCROSS的撞击羽流于2009年证实了卡比厄斯撞击坑中有水。'],
        HI: ['छाया में जल', 'चंद्र ध्रुवों के पास जिन क्रेटरों में कभी धूप नहीं पहुँचती, वे अरबों वर्षों तक बर्फ़ सँजो सकते हैं। लूनर प्रॉस्पेक्टर के हाइड्रोजन मानचित्रों ने इसका संकेत दिया और 2009 में LCROSS के प्रभाव-गुबार ने कैबियस क्रेटर में जल की पुष्टि की।'],
        ES: ['Agua en las sombras', 'Los cráteres cercanos a los polos lunares que nunca ven la luz solar pueden atrapar hielo durante miles de millones de años. Los mapas de hidrógeno del Lunar Prospector lo sugirieron y la columna del impacto de LCROSS confirmó agua en el cráter Cabeus en 2009.'],
        FR: ["L'eau dans l'ombre", "Les cratères proches des pôles lunaires qui ne voient jamais le Soleil peuvent piéger de la glace pendant des milliards d'années. Les cartes d'hydrogène de Lunar Prospector l'ont suggéré, et le panache de l'impact LCROSS a confirmé la présence d'eau dans le cratère Cabeus en 2009."],
        RU: ["Вода в тени", "Кратеры у лунных полюсов, куда никогда не попадает солнечный свет, могут удерживать лёд миллиарды лет. Карты водорода Lunar Prospector намекали на это, а выброс от удара LCROSS в 2009 году подтвердил воду в кратере Кабеус."]
      }
    },
    {
      id: 'units', body: 'MARS', craft: ['mco'],
      links: [['Wikipedia', 'https://en.wikipedia.org/wiki/Mars_Climate_Orbiter']],
      tx: {
        EN: ['One unit, one lost orbiter', "Mars Climate Orbiter was lost in 1999 because one team's software reported thruster impulse in pound-force seconds while another expected newton-seconds. The small error accumulated over months of navigation and brought the spacecraft far too close to Mars."],
        TR: ['Bir birim, bir kayıp yörünge aracı', "Mars Climate Orbiter 1999'da kayboldu; çünkü bir ekibin yazılımı itici impulsunu pound-kuvvet-saniye olarak verirken diğeri newton-saniye bekliyordu. Küçük hata aylarca süren seyirde birikti ve aracı Mars'a çok fazla yaklaştırdı."],
        ZH: ['一个单位，一颗失踪的轨道器', '1999年火星气候探测者号失踪，原因是一个团队的软件以磅力·秒输出推力冲量，而另一个团队按牛顿·秒处理。这一小误差在数月导航中不断累积，使探测器过于接近火星。'],
        HI: ['एक इकाई, एक खोया ऑर्बिटर', 'मार्स क्लाइमेट ऑर्बिटर 1999 में खो गया क्योंकि एक टीम का सॉफ़्टवेयर थ्रस्टर आवेग पाउंड-बल-सेकंड में दे रहा था जबकि दूसरी टीम न्यूटन-सेकंड की अपेक्षा कर रही थी। यह छोटी त्रुटि महीनों के नेविगेशन में बढ़ती गई और यान मंगल के बहुत पास पहुँच गया।'],
        ES: ['Una unidad, un orbitador perdido', 'El Mars Climate Orbiter se perdió en 1999 porque el software de un equipo daba el impulso de los propulsores en libras-fuerza por segundo mientras otro esperaba newton-segundo. El pequeño error se acumuló durante meses de navegación y acercó demasiado la nave a Marte.'],
        FR: ['Une unité, un orbiteur perdu', "Mars Climate Orbiter a été perdu en 1999 parce que le logiciel d'une équipe exprimait l'impulsion des propulseurs en livres-force seconde alors qu'une autre attendait des newtons-seconde. La petite erreur s'est accumulée pendant des mois de navigation et a amené la sonde bien trop près de Mars."],
        RU: ["Одна единица — один потерянный аппарат", "Mars Climate Orbiter был потерян в 1999 году, потому что программа одной команды выдавала импульс двигателей в фунт-сила-секундах, а другая ожидала ньютон-секунды. Небольшая ошибка накапливалась месяцами навигации и подвела аппарат слишком близко к Марсу."]
      }
    },
    {
      id: 'found', body: 'MARS', craft: ['beagle2', 'phoenix', 'spirit'],
      links: [['Wikipedia', 'https://en.wikipedia.org/wiki/HiRISE'], ['Wikipedia', 'https://en.wikipedia.org/wiki/Lunar_Reconnaissance_Orbiter']],
      tx: {
        EN: ['Found from orbit', "High-resolution cameras turn lost missions into findable sites. NASA's HiRISE camera located Beagle 2 and imaged Phoenix and Spirit, while the Lunar Reconnaissance Orbiter photographed the Apollo landing sites and the Lunokhod rovers."],
        TR: ['Yörüngeden bulunanlar', "Yüksek çözünürlüklü kameralar kayıp görevleri bulunabilir alanlara dönüştürüyor. NASA'nın HiRISE kamerası Beagle 2'yi buldu, Phoenix ve Spirit'i görüntüledi; Ay Keşif Yörünge Aracı ise Apollo iniş alanlarını ve Lunokhod gezginlerini fotoğrafladı."],
        ZH: ['从轨道上找到', '高分辨率相机让失踪任务重新被找到。NASA的HiRISE相机定位了猎兔犬2号，并拍摄了凤凰号和勇气号；月球勘测轨道器则拍摄了阿波罗着陆点和月球车。'],
        HI: ['कक्षा से खोज', 'उच्च-विभेदन कैमरे खोए मिशनों को खोजने योग्य स्थलों में बदल देते हैं। NASA के HiRISE कैमरे ने बीगल 2 को खोजा तथा फ़ीनिक्स और स्पिरिट के चित्र लिए, जबकि लूनर रिकॉनिसेंस ऑर्बिटर ने अपोलो लैंडिंग स्थलों और लूनोखोद रोवरों की तस्वीरें लीं।'],
        ES: ['Hallados desde la órbita', 'Las cámaras de alta resolución convierten misiones perdidas en lugares localizables. La cámara HiRISE de la NASA encontró el Beagle 2 y fotografió Phoenix y Spirit, mientras el Lunar Reconnaissance Orbiter fotografió los sitios del Apolo y los Lunojod.'],
        FR: ["Retrouvés depuis l'orbite", "Les caméras à haute résolution transforment des missions perdues en sites repérables. La caméra HiRISE de la NASA a localisé Beagle 2 et photographié Phoenix et Spirit, tandis que le Lunar Reconnaissance Orbiter a photographié les sites Apollo et les rovers Lunokhod."],
        RU: ["Найдены с орбиты", "Камеры высокого разрешения превращают потерянные миссии в места, которые можно найти. Камера NASA HiRISE обнаружила «Бигль-2» и сфотографировала «Феникс» и «Спирит», а Lunar Reconnaissance Orbiter снял места посадок «Аполлонов» и «Луноходы»."]
      }
    },
    {
      id: 'protect', body: 'MARS', craft: ['viking1', 'viking2'],
      links: [['Wikipedia', 'https://en.wikipedia.org/wiki/Planetary_protection']],
      tx: {
        EN: ['Planetary protection', 'Spacecraft bound for Mars are cleaned, and in some cases baked, to limit Earth microbes that could confuse the search for life. The Viking landers were heat-sterilized as complete systems before launch, a standard that still shapes life-detection missions.'],
        TR: ['Gezegen koruması', "Mars'a giden araçlar, yaşam arayışını yanıltabilecek Dünya mikroplarını sınırlamak için temizlenir, bazıları fırınlanır. Viking iniş araçları fırlatma öncesinde bütün sistem olarak ısıyla sterilize edildi; bu standart yaşam arayan görevleri hâlâ şekillendiriyor."],
        ZH: ['行星保护', '前往火星的航天器需要清洁，部分甚至需要烘烤，以减少可能干扰生命探测的地球微生物。海盗号着陆器在发射前整体进行了热灭菌，这一标准至今仍影响着生命探测任务。'],
        HI: ['ग्रह संरक्षण', 'मंगल जाने वाले यानों को साफ़ किया जाता है और कुछ को तपाया भी जाता है, ताकि पृथ्वी के सूक्ष्मजीव जीवन की खोज को भ्रमित न करें। वाइकिंग लैंडरों को प्रक्षेपण से पहले पूरे तंत्र के रूप में ताप-निर्जीवित किया गया था; यह मानक आज भी जीवन-खोज मिशनों को दिशा देता है।'],
        ES: ['Protección planetaria', 'Las naves con destino a Marte se limpian, y en algunos casos se hornean, para limitar los microbios terrestres que podrían confundir la búsqueda de vida. Los módulos Viking se esterilizaron por calor como sistemas completos antes del lanzamiento, un estándar que aún guía las misiones de detección de vida.'],
        FR: ['Protection planétaire', "Les engins destinés à Mars sont nettoyés, et parfois étuvés, pour limiter les microbes terrestres qui pourraient fausser la recherche de vie. Les atterrisseurs Viking ont été stérilisés par la chaleur en tant que systèmes complets avant le lancement, une norme qui guide encore les missions de détection de vie."],
        RU: ["Планетарная защита", "Аппараты, летящие к Марсу, очищают, а иногда и прогревают, чтобы ограничить земные микробы, способные запутать поиск жизни. Посадочные модули «Викинг» перед стартом целиком прошли тепловую стерилизацию — этот стандарт до сих пор влияет на миссии по поиску жизни."]
      }
    },
    {
      id: 'mass', body: 'MOON', craft: ['luna2', 'apollo17'],
      links: [['Wikipedia', 'https://en.wikipedia.org/wiki/List_of_artificial_objects_on_the_Moon'], ['Wikipedia', 'https://en.wikipedia.org/wiki/List_of_artificial_objects_on_Mars']],
      tx: {
        EN: ['How much have we left behind?', "Wikipedia's lists of artificial objects record more than 187 tonnes of human-made material on the Moon and a growing field of landers, rovers, heat shields and crash sites on Mars. Every object is also a dated record of a nation's technology."],
        TR: ['Geride ne kadar bıraktık?', "Wikipedia'nın yapay nesne listeleri Ay'da 187 tonu aşan insan yapımı malzeme ve Mars'ta giderek büyüyen iniş aracı, gezgin, ısı kalkanı ve çarpma alanı kaydediyor. Her nesne aynı zamanda bir ülkenin teknolojisinin tarihli bir kaydı."],
        ZH: ['我们留下了多少？', '维基百科的人造物体列表记录了月球上超过187吨的人造材料，以及火星上越来越多的着陆器、巡视车、隔热罩和坠毁点。每件物体也是一个国家技术水平的时间记录。'],
        HI: ['हमने कितना पीछे छोड़ा है?', 'विकिपीडिया की कृत्रिम वस्तुओं की सूचियाँ चंद्रमा पर 187 टन से अधिक मानव-निर्मित सामग्री और मंगल पर लैंडरों, रोवरों, ताप-कवचों और दुर्घटना स्थलों की बढ़ती संख्या दर्ज करती हैं। हर वस्तु किसी राष्ट्र की तकनीक का दिनांकित अभिलेख भी है।'],
        ES: ['¿Cuánto hemos dejado atrás?', 'Las listas de objetos artificiales de Wikipedia registran más de 187 toneladas de material humano en la Luna y un número creciente de módulos, rovers, escudos térmicos y sitios de impacto en Marte. Cada objeto es también un registro fechado de la tecnología de un país.'],
        FR: ['Combien avons-nous laissé derrière nous ?', "Les listes d'objets artificiels de Wikipédia recensent plus de 187 tonnes de matériel humain sur la Lune et un nombre croissant d'atterrisseurs, de rovers, de boucliers thermiques et de sites d'impact sur Mars. Chaque objet est aussi une trace datée de la technologie d'un pays."],
        RU: ["Сколько мы оставили?", "Списки искусственных объектов в Википедии насчитывают более 187 тонн созданных человеком материалов на Луне и растущее число посадочных модулей, марсоходов, теплозащитных экранов и мест падения на Марсе. Каждый объект — ещё и датированная запись технологий своей страны."]
      }
    }
  ];

  return { BODIES, CATEGORIES, CRAFT, DOSSIERS };
})();
